# Starting clock speed on load (night pace)
time of minecraft:overworld rate 0.75
