# Gliders can't be boosted
execute as @a[predicate=tweaks:gliding] at @s run kill @e[type=minecraft:firework_rocket,distance=..3]
