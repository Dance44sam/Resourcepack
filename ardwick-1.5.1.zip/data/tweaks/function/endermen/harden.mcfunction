attribute @s minecraft:max_health base set 80
data modify entity @s Health set value 80.0f
tag @s add tweaks.ender_checked
tag @s add tweaks.hp2
