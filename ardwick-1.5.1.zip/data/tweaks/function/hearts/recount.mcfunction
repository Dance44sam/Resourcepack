# The heart floor is worked out afresh from milestones reached, so it is right in any
scoreboard players set @s tweaks.floor 8
execute if entity @s[advancements={tweaks:twice_fired=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:ghasts_grief=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:brewing/glowstone=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:withering=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:no_template_required=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:peace_at_last=true}] run scoreboard players remove @s tweaks.floor 1
execute if entity @s[advancements={tweaks:the_long_way_back=true}] run scoreboard players remove @s tweaks.floor 1
execute if score @s tweaks.floor matches ..0 run scoreboard players set @s tweaks.floor 1
execute if score @s tweaks.hearts matches 1.. if score @s tweaks.hearts < @s tweaks.floor run function tweaks:hearts/lift
