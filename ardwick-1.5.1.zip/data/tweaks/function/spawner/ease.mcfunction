execute if score @s tweaks.sp_hard matches 1 run attribute @s minecraft:block_break_speed modifier remove tweaks:spawner
scoreboard players set @s tweaks.sp_hard 0
