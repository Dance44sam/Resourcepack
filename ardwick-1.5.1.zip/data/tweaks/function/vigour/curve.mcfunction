# Straight line: a tenth of a percent per point, capped at 30% either way.
scoreboard players operation #m tweaks.calc2 = @s tweaks.vigour
execute if score #m tweaks.calc2 matches 301.. run scoreboard players set #m tweaks.calc2 300
execute if score #m tweaks.calc2 matches ..-301 run scoreboard players set #m tweaks.calc2 -300
scoreboard players set #dmg tweaks.calc2 0
execute if score #m tweaks.calc2 matches 1.. run scoreboard players operation #dmg tweaks.calc2 = #m tweaks.calc2
scoreboard players operation #dmg tweaks.calc2 *= #k20 tweaks.const
scoreboard players add #m tweaks.calc2 1000
