# Run as a leather item fresh off a campfire; credit whoever is tending it
advancement grant @a[distance=..16] only tweaks:waste_not
item modify entity @s contents tweaks:leather_unmark
