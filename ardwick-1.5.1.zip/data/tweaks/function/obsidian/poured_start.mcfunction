scoreboard players set #ray tweaks.calc2 50
function tweaks:obsidian/poured
