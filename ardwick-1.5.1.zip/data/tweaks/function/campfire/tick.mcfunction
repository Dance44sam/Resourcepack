# Refreshed every 60 ticks with a 4 second effect, so the 20 tick overlap keeps
scoreboard players add #campfire tweaks.timer 1
execute if score #campfire tweaks.timer matches 60.. run function tweaks:campfire/scan_all
scoreboard players add #burnclock tweaks.timer 1
execute if score #burnclock tweaks.timer matches 20.. run function tweaks:campfire/burn_clock
