# Food just eaten: add its healing to any already running
execute as @a[predicate=tweaks:has_luck] run function tweaks:food/regen
execute as @a[predicate=tweaks:has_unluck] run function tweaks:food/slow

