function tweaks:portal/row with storage tweaks:portal
execute if score #rowbad tweaks.calc2 matches 1 run return fail
scoreboard players remove #prow tweaks.calc2 1
execute if score #prow tweaks.calc2 matches ..0 run return 1
execute positioned ~ ~1 ~ run return run function tweaks:portal/rows_ok
