# Horse and nautilus armour already worn by a mount (never in a player's inventory) gets
execute as @e[type=#minecraft:can_wear_horse_armor] if items entity @s armor.body #tweaks:body_armor[!minecraft:custom_data~{tweaks_body:1b}] run item modify entity @s armor.body tweaks:armor/body_weight
execute as @e[type=#minecraft:can_wear_nautilus_armor] if items entity @s armor.body #tweaks:body_armor[!minecraft:custom_data~{tweaks_body:1b}] run item modify entity @s armor.body tweaks:armor/body_weight
