execute if score #days tweaks.year >= @s tweaks.due run return run function tweaks:breed/grow
# Feeding a baby knocks time off its vanilla timer; putting it back undoes that
data modify entity @s Age set value -2000000000
