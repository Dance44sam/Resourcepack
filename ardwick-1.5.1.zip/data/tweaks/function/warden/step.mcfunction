# The sweep covers 512 x 512 blocks and 64 high, centred on where the Warden died
execute store result storage tweaks:quiet dx int 16 run scoreboard players get @s tweaks.qprog
execute store result score #dx tweaks.calc2 run data get storage tweaks:quiet dx
scoreboard players remove #dx tweaks.calc2 256
execute store result storage tweaks:quiet dx int 1 run scoreboard players get #dx tweaks.calc2
function tweaks:warden/strip with storage tweaks:quiet
scoreboard players add @s tweaks.qprog 1
execute if score @s tweaks.qprog matches 32.. run kill @s
