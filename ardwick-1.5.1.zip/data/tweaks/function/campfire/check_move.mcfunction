# Squared horizontal distance from the last announced camp
scoreboard players operation @s tweaks.dx = @s tweaks.px
scoreboard players operation @s tweaks.dx -= @s tweaks.sx
scoreboard players operation @s tweaks.dx *= @s tweaks.dx
scoreboard players operation @s tweaks.dz = @s tweaks.pz
scoreboard players operation @s tweaks.dz -= @s tweaks.sz
scoreboard players operation @s tweaks.dz *= @s tweaks.dz
scoreboard players operation @s tweaks.dx += @s tweaks.dz
execute if score @s tweaks.dx matches 144.. run function tweaks:campfire/announce
