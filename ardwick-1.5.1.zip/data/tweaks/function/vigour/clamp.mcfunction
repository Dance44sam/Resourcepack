scoreboard players set #c tweaks.calc2 300
scoreboard players operation #c tweaks.calc2 -= @s tweaks.frost
execute if score @s tweaks.vigour > #c tweaks.calc2 run scoreboard players operation @s tweaks.vigour = #c tweaks.calc2
