# Mobs drop what they carry and wear 17% of the time (tridents always)
execute as @e[type=#tweaks:equipped,tag=!tweaks.equip_checked] run function tweaks:equipment/set
