# Points inside the current level, plus every point it took to reach that level
execute store result score @s tweaks.xp run xp query @s points
execute store result score @s tweaks.xplv run xp query @s levels
execute if score @s tweaks.xplv matches 1.. run function tweaks:xp/levels
execute if score @s tweaks.xp matches 1.. run function tweaks:xp/gain
