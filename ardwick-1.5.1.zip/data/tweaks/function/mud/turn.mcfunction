data modify entity @s Item.id set value "minecraft:mud"
particle minecraft:splash ~ ~0.2 ~ 0.2 0.1 0.2 0.05 8
playsound minecraft:block.mud.place block @a ~ ~ ~ 0.8 0.9
tag @s remove tweaks.conv
