$attribute @s minecraft:attack_damage modifier add tweaks:vigour $(dmg) add_value
