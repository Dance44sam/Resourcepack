# Once a second (cold/second)
scoreboard players set #lo tweaks.calc2 0
scoreboard players set #hi tweaks.calc2 23999
scoreboard players set #iter tweaks.calc2 0
function tweaks:climate/halve
scoreboard players operation #tod tweaks.calc2 = #lo tweaks.calc2
scoreboard players operation #ts tweaks.calc2 = #tod tweaks.calc2
scoreboard players remove #ts tweaks.calc2 4000
execute if score #ts tweaks.calc2 matches ..-1 run scoreboard players add #ts tweaks.calc2 24000
scoreboard players set #htime tweaks.heat 0
execute if score #ts tweaks.calc2 matches ..12000 run function tweaks:climate/heat_curve
scoreboard players set #ctime tweaks.cold 100
execute if score #ts tweaks.calc2 matches 12001.. run function tweaks:climate/cold_curve
scoreboard players operation #d tweaks.calc2 = #day tweaks.year
function tweaks:climate/season_of
scoreboard players operation #ct tweaks.calc2 = #cv tweaks.calc2
scoreboard players operation #ht tweaks.calc2 = #hv tweaks.calc2
scoreboard players add #d tweaks.calc2 1
execute if score #d tweaks.calc2 matches 28.. run scoreboard players set #d tweaks.calc2 0
function tweaks:climate/season_of
scoreboard players operation #cv tweaks.calc2 -= #ct tweaks.calc2
scoreboard players operation #cv tweaks.calc2 *= #tod tweaks.calc2
scoreboard players operation #cv tweaks.calc2 /= #k24000 tweaks.calc2
scoreboard players operation #cv tweaks.calc2 += #ct tweaks.calc2
scoreboard players operation #season tweaks.cold = #cv tweaks.calc2
scoreboard players operation #hv tweaks.calc2 -= #ht tweaks.calc2
scoreboard players operation #hv tweaks.calc2 *= #tod tweaks.calc2
scoreboard players operation #hv tweaks.calc2 /= #k24000 tweaks.calc2
scoreboard players operation #hv tweaks.calc2 += #ht tweaks.calc2
scoreboard players operation #hseason tweaks.heat = #hv tweaks.calc2
