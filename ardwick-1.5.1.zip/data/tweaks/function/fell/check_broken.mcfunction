execute store result storage tweaks:fell x int 1 run scoreboard players get @s tweaks.fell_x
execute store result storage tweaks:fell y int 1 run scoreboard players get @s tweaks.fell_y
execute store result storage tweaks:fell z int 1 run scoreboard players get @s tweaks.fell_z
function tweaks:fell/check_at with storage tweaks:fell
