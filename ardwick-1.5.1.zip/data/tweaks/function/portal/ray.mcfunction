execute if block ~ ~ ~ minecraft:fire align xyz positioned ~0.5 ~0.5 ~0.5 run return run function tweaks:portal/found
execute unless block ~ ~ ~ #tweaks:ray_through run return 0
scoreboard players remove #pray tweaks.calc2 1
execute if score #pray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:portal/ray
