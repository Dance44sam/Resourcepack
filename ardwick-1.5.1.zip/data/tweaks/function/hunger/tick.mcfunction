# Lock every player's hunger at exactly 8 (4 shanks).
execute as @a[scores={tweaks.food=0}] run effect give @s minecraft:saturation 1 7 true
execute as @a[scores={tweaks.food=1}] run effect give @s minecraft:saturation 1 6 true
execute as @a[scores={tweaks.food=2}] run effect give @s minecraft:saturation 1 5 true
execute as @a[scores={tweaks.food=3}] run effect give @s minecraft:saturation 1 4 true
execute as @a[scores={tweaks.food=4}] run effect give @s minecraft:saturation 1 3 true
execute as @a[scores={tweaks.food=5}] run effect give @s minecraft:saturation 1 2 true
execute as @a[scores={tweaks.food=6}] run effect give @s minecraft:saturation 1 1 true
execute as @a[scores={tweaks.food=7}] run effect give @s minecraft:saturation 1 0 true
execute as @a[scores={tweaks.food=9..}] run function tweaks:hunger/drain
execute as @a[tag=tweaks.draining,scores={tweaks.food=..8}] run function tweaks:hunger/stop_drain
