# TNT lights the moment it's placed in the Nether
setblock ~ ~ ~ minecraft:air
summon minecraft:tnt ~0.5 ~ ~0.5 {fuse:80s}
playsound minecraft:entity.tnt.primed block @a ~0.5 ~0.5 ~0.5 1 1
