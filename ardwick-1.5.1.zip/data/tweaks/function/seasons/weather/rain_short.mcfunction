weather rain 120s
scoreboard players set #wtimer tweaks.year 120
