# On its own: removing a modifier that is absent is an error, and it stops whichever
attribute @s minecraft:movement_speed modifier remove tweaks:shulker_weight
