summon minecraft:item ~ ~ ~ {Tags:["tweaks.split_new"],Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=minecraft:item,tag=tweaks.split_new,limit=1,sort=nearest] Item set from entity @s Item
execute as @e[type=minecraft:item,tag=tweaks.split_new,limit=1,sort=nearest] run function tweaks:split/hold
tag @e[type=minecraft:item,tag=tweaks.split_new] remove tweaks.split_new
scoreboard players remove #sc tweaks.calc2 1
execute if score #sc tweaks.calc2 matches 1.. run function tweaks:split/copy
