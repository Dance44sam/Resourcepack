# Under open sky the weather works on you; underground it neither builds nor clears
execute if predicate tweaks:open_sky run function tweaks:cold/build
