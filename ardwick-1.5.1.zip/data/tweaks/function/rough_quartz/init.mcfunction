scoreboard objectives add tweaks.rough_quartz minecraft.mined:minecraft.nether_quartz_ore
scoreboard objectives add tweaks.flint_mined minecraft.mined:minecraft.lapis_ore
