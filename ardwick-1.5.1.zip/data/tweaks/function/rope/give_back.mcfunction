summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:lead",count:1}}
kill @s
