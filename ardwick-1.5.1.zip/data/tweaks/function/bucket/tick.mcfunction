# Buckets can't hold lava: the bucket survives, the lava stays where it was
execute as @a[gamemode=!creative,gamemode=!spectator,scores={tweaks.bkt_used=1..}] at @s as @e[type=minecraft:marker,tag=tweaks.bkt,distance=..8] at @s run function tweaks:bucket/put
scoreboard players reset @a tweaks.bkt_used
execute as @a[gamemode=!creative,gamemode=!spectator] if items entity @s container.* minecraft:lava_bucket run function tweaks:bucket/empty
execute as @a[gamemode=!creative,gamemode=!spectator] if items entity @s weapon.offhand minecraft:lava_bucket run function tweaks:bucket/empty
execute as @a[gamemode=!creative,gamemode=!spectator] if items entity @s player.cursor minecraft:lava_bucket run function tweaks:bucket/empty
scoreboard players add @e[type=minecraft:marker,tag=tweaks.bkt] tweaks.bkt_age 1
kill @e[type=minecraft:marker,tag=tweaks.bkt,scores={tweaks.bkt_age=8..}]
execute as @a[gamemode=!creative,gamemode=!spectator] if items entity @s hotbar.* minecraft:bucket at @s anchored eyes positioned ^ ^ ^ run function tweaks:bucket/aim
execute as @a[gamemode=!creative,gamemode=!spectator] unless items entity @s hotbar.* minecraft:bucket if items entity @s weapon.offhand minecraft:bucket at @s anchored eyes positioned ^ ^ ^ run function tweaks:bucket/aim
