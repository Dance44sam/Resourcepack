# Concrete powder in water sets into concrete, as it would if placed
execute if items entity @s contents minecraft:white_concrete_powder run data modify entity @s Item.id set value "minecraft:white_concrete"
execute if items entity @s contents minecraft:orange_concrete_powder run data modify entity @s Item.id set value "minecraft:orange_concrete"
execute if items entity @s contents minecraft:magenta_concrete_powder run data modify entity @s Item.id set value "minecraft:magenta_concrete"
execute if items entity @s contents minecraft:light_blue_concrete_powder run data modify entity @s Item.id set value "minecraft:light_blue_concrete"
execute if items entity @s contents minecraft:yellow_concrete_powder run data modify entity @s Item.id set value "minecraft:yellow_concrete"
execute if items entity @s contents minecraft:lime_concrete_powder run data modify entity @s Item.id set value "minecraft:lime_concrete"
execute if items entity @s contents minecraft:pink_concrete_powder run data modify entity @s Item.id set value "minecraft:pink_concrete"
execute if items entity @s contents minecraft:gray_concrete_powder run data modify entity @s Item.id set value "minecraft:gray_concrete"
execute if items entity @s contents minecraft:light_gray_concrete_powder run data modify entity @s Item.id set value "minecraft:light_gray_concrete"
execute if items entity @s contents minecraft:cyan_concrete_powder run data modify entity @s Item.id set value "minecraft:cyan_concrete"
execute if items entity @s contents minecraft:purple_concrete_powder run data modify entity @s Item.id set value "minecraft:purple_concrete"
execute if items entity @s contents minecraft:blue_concrete_powder run data modify entity @s Item.id set value "minecraft:blue_concrete"
execute if items entity @s contents minecraft:brown_concrete_powder run data modify entity @s Item.id set value "minecraft:brown_concrete"
execute if items entity @s contents minecraft:green_concrete_powder run data modify entity @s Item.id set value "minecraft:green_concrete"
execute if items entity @s contents minecraft:red_concrete_powder run data modify entity @s Item.id set value "minecraft:red_concrete"
execute if items entity @s contents minecraft:black_concrete_powder run data modify entity @s Item.id set value "minecraft:black_concrete"
particle minecraft:splash ~ ~0.2 ~ 0.2 0.1 0.2 0.05 8
playsound minecraft:block.sand.place block @a ~ ~ ~ 0.8 0.9
advancement grant @a[distance=..8] only tweaks:concrete made
tag @s remove tweaks.conv
