$execute store result score #ovn tweaks.calc2 run data get entity @s Inventory[{Slot:$(slot)b}].count
execute if score #ovn tweaks.calc2 matches ..1 run return 0
$execute store result storage tweaks:oversize pend.s$(slot) int 1 run scoreboard players get #ovn tweaks.calc2
$item modify entity @s container.$(slot) tweaks:oversize/one
