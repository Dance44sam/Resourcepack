execute as @a[tag=tweaks.bred] at @s as @e[type=#tweaks:breedable,distance=..16] run function tweaks:breed/age
tag @a remove tweaks.bred
