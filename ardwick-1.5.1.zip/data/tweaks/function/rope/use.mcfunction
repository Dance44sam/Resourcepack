# The player is holding a lead down (a click on a fence with nobody on the lead falls
advancement revoke @s only tweaks:rope/use
scoreboard players set @s tweaks.rope_t 0
execute if entity @s[tag=tweaks.rope_busy] run return 0
tag @s add tweaks.rope_busy
scoreboard players set #rp tweaks.calc2 110
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:rope/ray
