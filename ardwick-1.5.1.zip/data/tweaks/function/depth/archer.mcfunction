# Skeletons, strays and bogged
execute unless items entity @s weapon.mainhand minecraft:bow run return 0
execute if score #dm tweaks.calc2 matches 96.. run return run item modify entity @s weapon.mainhand tweaks:depth/power_2
execute if score #dm tweaks.calc2 matches 32.. run item modify entity @s weapon.mainhand tweaks:depth/power_1
