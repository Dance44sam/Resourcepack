scoreboard players operation @s tweaks.fprev = @s tweaks.frost
scoreboard players operation @s tweaks.ftgt = #t tweaks.calc2
scoreboard players set @s tweaks.fph 0
