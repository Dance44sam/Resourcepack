$attribute @s minecraft:movement_speed modifier add tweaks:vitality $(amount) add_multiplied_base
