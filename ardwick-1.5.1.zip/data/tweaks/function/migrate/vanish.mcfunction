# A summoned skeleton carries nothing, so give the newcomer the bow its kind is born with
item replace entity @e[tag=tweaks.mig_new,distance=..1] weapon.mainhand with minecraft:bow
tag @e[tag=tweaks.mig_new,distance=..1] remove tweaks.mig_new
data merge entity @s {DeathLootTable:"minecraft:empty"}
tp @s ~ -400 ~
kill @s
