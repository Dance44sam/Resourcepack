# Herobrine: about once a week, at random, he waits in the dark for someone to notice him
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb] run function tweaks:herobrine/watch
scoreboard players add #hbclock tweaks.timer 1
execute if score #hbclock tweaks.timer matches 100.. run function tweaks:herobrine/clock
