# Rough Quartz and Flint Deposits drop experience in code; take it away again, only orbs just made, so others keep theirs
execute as @a[scores={tweaks.rough_quartz=1..}] at @s run kill @e[type=minecraft:experience_orb,distance=..7,nbt={Age:0s}]
execute as @a[scores={tweaks.rough_quartz=1..}] at @s run kill @e[type=minecraft:experience_orb,distance=..7,nbt={Age:1s}]
execute as @a[scores={tweaks.flint_mined=1..}] at @s run kill @e[type=minecraft:experience_orb,distance=..7,nbt={Age:0s}]
execute as @a[scores={tweaks.flint_mined=1..}] at @s run kill @e[type=minecraft:experience_orb,distance=..7,nbt={Age:1s}]
scoreboard players reset @a[scores={tweaks.rough_quartz=1..}] tweaks.rough_quartz
scoreboard players reset @a[scores={tweaks.flint_mined=1..}] tweaks.flint_mined
