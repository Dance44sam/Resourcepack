summon minecraft:marker ~ ~ ~ {Tags:["tweaks.ob_watch"]}
scoreboard players add #obn tweaks.calc2 1
