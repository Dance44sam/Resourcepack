# Day of the year, straight from the world clock
execute if predicate tweaks:year/day_0 run scoreboard players set #day tweaks.year 0
execute if predicate tweaks:year/day_1 run scoreboard players set #day tweaks.year 1
execute if predicate tweaks:year/day_2 run scoreboard players set #day tweaks.year 2
execute if predicate tweaks:year/day_3 run scoreboard players set #day tweaks.year 3
execute if predicate tweaks:year/day_4 run scoreboard players set #day tweaks.year 4
execute if predicate tweaks:year/day_5 run scoreboard players set #day tweaks.year 5
execute if predicate tweaks:year/day_6 run scoreboard players set #day tweaks.year 6
execute if predicate tweaks:year/day_7 run scoreboard players set #day tweaks.year 7
execute if predicate tweaks:year/day_8 run scoreboard players set #day tweaks.year 8
execute if predicate tweaks:year/day_9 run scoreboard players set #day tweaks.year 9
execute if predicate tweaks:year/day_10 run scoreboard players set #day tweaks.year 10
execute if predicate tweaks:year/day_11 run scoreboard players set #day tweaks.year 11
execute if predicate tweaks:year/day_12 run scoreboard players set #day tweaks.year 12
execute if predicate tweaks:year/day_13 run scoreboard players set #day tweaks.year 13
execute if predicate tweaks:year/day_14 run scoreboard players set #day tweaks.year 14
execute if predicate tweaks:year/day_15 run scoreboard players set #day tweaks.year 15
execute if predicate tweaks:year/day_16 run scoreboard players set #day tweaks.year 16
execute if predicate tweaks:year/day_17 run scoreboard players set #day tweaks.year 17
execute if predicate tweaks:year/day_18 run scoreboard players set #day tweaks.year 18
execute if predicate tweaks:year/day_19 run scoreboard players set #day tweaks.year 19
execute if predicate tweaks:year/day_20 run scoreboard players set #day tweaks.year 20
execute if predicate tweaks:year/day_21 run scoreboard players set #day tweaks.year 21
execute if predicate tweaks:year/day_22 run scoreboard players set #day tweaks.year 22
execute if predicate tweaks:year/day_23 run scoreboard players set #day tweaks.year 23
execute if predicate tweaks:year/day_24 run scoreboard players set #day tweaks.year 24
execute if predicate tweaks:year/day_25 run scoreboard players set #day tweaks.year 25
execute if predicate tweaks:year/day_26 run scoreboard players set #day tweaks.year 26
execute if predicate tweaks:year/day_27 run scoreboard players set #day tweaks.year 27
execute unless score #prevday tweaks.year matches 0..27 run scoreboard players operation #prevday tweaks.year = #day tweaks.year
scoreboard players operation #dd tweaks.year = #day tweaks.year
scoreboard players operation #dd tweaks.year -= #prevday tweaks.year
scoreboard players operation #dd tweaks.year += #28 tweaks.year
scoreboard players operation #dd tweaks.year %= #28 tweaks.year
scoreboard players operation #days tweaks.year += #dd tweaks.year
scoreboard players operation #prevday tweaks.year = #day tweaks.year
