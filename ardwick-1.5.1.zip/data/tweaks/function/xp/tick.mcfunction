execute as @a run function tweaks:xp/measure
