advancement revoke @s only tweaks:feather/drink_1
# Stacks: each potion adds its time to whatever is left
scoreboard players add @s tweaks.ff 3600
function tweaks:feather/on
