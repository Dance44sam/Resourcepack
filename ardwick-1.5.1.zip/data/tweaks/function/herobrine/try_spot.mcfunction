execute store result storage tweaks:hb yaw int 1 run random value 120..240
execute store result storage tweaks:hb dist int 1 run random value 48..64
function tweaks:herobrine/aim with storage tweaks:hb
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb] run return 0
scoreboard players remove #hbtries tweaks.calc2 1
execute if score #hbtries tweaks.calc2 matches 1.. run function tweaks:herobrine/try_spot
