# Winter, rolled out of 10000: rain 2.13% per spell
execute if score #roll tweaks.year matches 1..9787 run function tweaks:seasons/weather/clear_short
execute if score #roll tweaks.year matches 9788..10000 run function tweaks:seasons/weather/rain_long
