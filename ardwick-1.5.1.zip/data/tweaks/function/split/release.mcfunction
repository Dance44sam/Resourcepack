data modify entity @s Age set value 0s
tag @s remove tweaks.split
scoreboard players reset @s tweaks.split_t
