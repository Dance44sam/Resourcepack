summon minecraft:stray ~ ~ ~ {Tags:["tweaks.mig","tweaks.mig_new","tweaks.seen"]}
function tweaks:migrate/vanish
