# Count down through the open faces to the randomly chosen one
$execute store result score #nbp tweaks.calc2 run random value 0..$(max)
execute if block ~ ~1 ~ #minecraft:air if score #nbp tweaks.calc2 matches 0 run return run setblock ~ ~1 ~ minecraft:fire
execute if block ~ ~1 ~ #minecraft:air run scoreboard players remove #nbp tweaks.calc2 1
execute if block ~1 ~ ~ #minecraft:air if score #nbp tweaks.calc2 matches 0 run return run setblock ~1 ~ ~ minecraft:fire
execute if block ~1 ~ ~ #minecraft:air run scoreboard players remove #nbp tweaks.calc2 1
execute if block ~-1 ~ ~ #minecraft:air if score #nbp tweaks.calc2 matches 0 run return run setblock ~-1 ~ ~ minecraft:fire
execute if block ~-1 ~ ~ #minecraft:air run scoreboard players remove #nbp tweaks.calc2 1
execute if block ~ ~ ~1 #minecraft:air if score #nbp tweaks.calc2 matches 0 run return run setblock ~ ~ ~1 minecraft:fire
execute if block ~ ~ ~1 #minecraft:air run scoreboard players remove #nbp tweaks.calc2 1
execute if block ~ ~ ~-1 #minecraft:air if score #nbp tweaks.calc2 matches 0 run return run setblock ~ ~ ~-1 minecraft:fire
execute if block ~ ~ ~-1 #minecraft:air run scoreboard players remove #nbp tweaks.calc2 1
execute if block ~ ~-1 ~ #minecraft:air if score #nbp tweaks.calc2 matches 0 run setblock ~ ~-1 ~ minecraft:fire
