execute unless block ~ ~ ~ #tweaks:portal_space run scoreboard players set #rowbad tweaks.calc2 1
execute unless block ~-1 ~ ~ minecraft:obsidian run scoreboard players set #rowbad tweaks.calc2 1
execute unless block ~1 ~ ~ minecraft:obsidian run scoreboard players set #rowbad tweaks.calc2 1
execute if score #prow tweaks.calc2 = #ph tweaks.calc2 unless block ~ ~-1 ~ minecraft:obsidian run scoreboard players set #rowbad tweaks.calc2 1
execute if score #prow tweaks.calc2 matches 1 unless block ~ ~1 ~ minecraft:obsidian run scoreboard players set #rowbad tweaks.calc2 1
