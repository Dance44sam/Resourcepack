# Heal the pet by 4, never past its own maximum
execute store result score #h tweaks.calc2 run data get entity @s Health 1
scoreboard players add #h tweaks.calc2 4
execute store result score #max tweaks.calc2 run attribute @s minecraft:max_health get 1
execute if score #h tweaks.calc2 > #max tweaks.calc2 run scoreboard players operation #h tweaks.calc2 = #max tweaks.calc2
execute store result entity @s Health float 1 run scoreboard players get #h tweaks.calc2
