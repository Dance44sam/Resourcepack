attribute @s minecraft:fall_damage_multiplier modifier remove tweaks:feather_falling
scoreboard players reset @s tweaks.ff
