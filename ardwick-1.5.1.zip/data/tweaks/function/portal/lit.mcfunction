# Fire lit on obsidian
advancement revoke @s only tweaks:portal/lit
scoreboard players set #pray tweaks.calc2 60
execute anchored eyes positioned ^ ^ ^ run function tweaks:portal/ray
