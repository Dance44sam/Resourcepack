tag @s add tweaks.seen
data merge entity @s {Fuse:39}
