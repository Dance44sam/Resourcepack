# Survive an eclipse: be alive and present while it lasts, without dying, until it ends
scoreboard players add @a tweaks.deaths 0
execute unless predicate tweaks:is_eclipse run scoreboard players set @a tweaks.deaths 0
execute if predicate tweaks:is_eclipse as @a[scores={tweaks.deaths=1..}] run function tweaks:eclipse/died
execute if predicate tweaks:is_eclipse run tag @a[tag=!tweaks.eclipse_out,scores={tweaks.deaths=0}] add tweaks.eclipse_in
execute unless predicate tweaks:is_eclipse if score #eclipse tweaks.year matches 1 run function tweaks:eclipse/ended
execute store success score #eclipse tweaks.year if predicate tweaks:is_eclipse
