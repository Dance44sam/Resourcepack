# Follow the line of sight to the first solid block
execute unless block ~ ~ ~ #tweaks:ray_through unless block ~ ~ ~ minecraft:obsidian run return 0
execute if block ~ ~ ~ minecraft:obsidian align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.ob_watch,distance=..0.4] run return run function tweaks:obsidian/formed_here
scoreboard players remove #ray tweaks.calc2 1
execute if score #ray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:obsidian/poured
