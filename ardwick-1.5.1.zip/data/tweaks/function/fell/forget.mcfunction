function tweaks:fell/clear
scoreboard players set @s tweaks.fell_n 0
scoreboard players reset @s tweaks.fell_x
scoreboard players reset @s tweaks.fell_y
scoreboard players reset @s tweaks.fell_z
