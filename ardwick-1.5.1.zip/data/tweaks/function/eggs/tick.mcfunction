# Every chicken lays an ordinary egg
execute as @e[type=minecraft:chicken,tag=!tweaks.chick_seen] at @s run function tweaks:eggs/new_chicken
kill @e[type=minecraft:marker,tag=tweaks.egg_trace]
execute at @e[type=minecraft:egg] run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.egg_trace"]}
