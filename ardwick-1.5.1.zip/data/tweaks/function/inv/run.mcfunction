advancement revoke @s only tweaks:inv/changed
function tweaks:inv/convert
