scoreboard players set #hit tweaks.calc2 1
execute unless block ~ ~ ~ #tweaks:tree_logs run return run function tweaks:fell/forget
execute align xyz run function tweaks:fell/target
