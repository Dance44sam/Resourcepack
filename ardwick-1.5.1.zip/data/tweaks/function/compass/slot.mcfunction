# One slot: a plain compass points north (a lodestone tracker aimed at the far north edge
$execute if items entity @s $(s) minecraft:compass[!minecraft:lodestone_tracker,!minecraft:custom_name] run return run item modify entity @s $(s) tweaks:compass/north
$execute if items entity @s $(s) minecraft:compass[!minecraft:lodestone_tracker,minecraft:custom_name] run return run item modify entity @s $(s) tweaks:compass/north_named
$execute if items entity @s $(s) minecraft:compass[minecraft:custom_data~{tweaks_north:1b},!minecraft:lodestone_tracker={target:{pos:[I;0,64,-29999984],dimension:"minecraft:overworld"},tracked:false}] run item modify entity @s $(s) tweaks:compass/lodestone
$execute if items entity @s $(s) minecraft:compass[minecraft:custom_data~{tweaks_north:0b},minecraft:custom_name={translate:"item.minecraft.compass",italic:false}] run item modify entity @s $(s) tweaks:compass/unname
