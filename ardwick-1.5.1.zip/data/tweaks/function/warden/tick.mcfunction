# Any Warden that dies, however it dies, silences the shriekers around where it fell, so
execute as @e[type=minecraft:warden,tag=!tweaks.w_fallen] at @s run function tweaks:warden/check
execute as @e[type=minecraft:marker,tag=tweaks.quiet] at @s run function tweaks:warden/step
