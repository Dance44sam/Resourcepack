# One point of wear; shears worn through break
item modify entity @s weapon.mainhand tweaks:shears_wear
scoreboard players set #d tweaks.calc2 0
execute store result score #d tweaks.calc2 run data get entity @s SelectedItem.components."minecraft:damage"
execute if score #d tweaks.calc2 matches 238.. run function tweaks:frames/snap
