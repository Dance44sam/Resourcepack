# Trace the player's line of sight as a bucket does (stopping at the first block or fluid
scoreboard players set #bkt tweaks.calc2 45
function tweaks:bucket/ray
