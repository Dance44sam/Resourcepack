# Milk washes Feather Falling away, as it does any potion
advancement revoke @s only tweaks:feather/milk
execute if score @s tweaks.ff matches 1.. run function tweaks:feather/off
