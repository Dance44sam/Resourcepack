# A Cornish miner's lunch: three minutes of doubled tin
advancement revoke @s only tweaks:pasty/eaten
scoreboard players set @s tweaks.pasty 3600
