# One shard, one allay
item modify entity @s contents {type:"minecraft:set_count",count:-1,add:true}
summon minecraft:allay ~ ~0.6 ~
effect give @e[type=minecraft:allay,distance=..2,sort=nearest,limit=1] minecraft:fire_resistance infinite 0 true
particle minecraft:soul ~ ~0.6 ~ 0.2 0.3 0.2 0.02 12
playsound minecraft:block.amethyst_block.resonate neutral @a ~ ~ ~ 1 1
advancement grant @a[distance=..8] only tweaks:allay made
