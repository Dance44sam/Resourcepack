$item replace entity @s $(slot) with minecraft:glow_ink_sac $(n)
