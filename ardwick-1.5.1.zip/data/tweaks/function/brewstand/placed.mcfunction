advancement revoke @s only tweaks:brewing/stand_placed
scoreboard players set #bray tweaks.calc2 60
execute anchored eyes positioned ^ ^ ^ run function tweaks:brewstand/ray
