# Somewhere behind or beside the player, 48 to 64 blocks away
tag @s add tweaks.hb_target
scoreboard players set #hbtries tweaks.calc2 8
function tweaks:herobrine/try_spot
execute unless entity @e[type=minecraft:mannequin,tag=tweaks.hb] run tag @s remove tweaks.hb_target
