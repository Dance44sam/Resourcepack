scoreboard players set #sz tweaks.calc2 13
function tweaks:obsidian/sz
scoreboard players remove #sy tweaks.calc2 1
execute if score #sy tweaks.calc2 matches 1.. positioned ~ ~1 ~ run function tweaks:obsidian/sy
