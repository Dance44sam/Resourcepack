scoreboard players operation #x tweaks.calc2 = #ts tweaks.calc2
scoreboard players remove #x tweaks.calc2 6000
scoreboard players operation #x tweaks.calc2 *= #x tweaks.calc2
scoreboard players operation #x tweaks.calc2 /= #k180000 tweaks.calc2
scoreboard players set #htime tweaks.heat 200
scoreboard players operation #htime tweaks.heat -= #x tweaks.calc2
execute if score #htime tweaks.heat matches ..-1 run scoreboard players set #htime tweaks.heat 0
