# Chickens, cows and pigs have temperate, warm and cold variants
execute unless entity @s[tag=tweaks.var_temperate] unless entity @s[tag=tweaks.var_warm] unless entity @s[tag=tweaks.var_cold] if data entity @s {variant:"minecraft:temperate"} run tag @s add tweaks.var_temperate
execute unless entity @s[tag=tweaks.var_temperate] unless entity @s[tag=tweaks.var_warm] unless entity @s[tag=tweaks.var_cold] if data entity @s {variant:"minecraft:warm"} run tag @s add tweaks.var_warm
execute unless entity @s[tag=tweaks.var_temperate] unless entity @s[tag=tweaks.var_warm] unless entity @s[tag=tweaks.var_cold] if data entity @s {variant:"minecraft:cold"} run tag @s add tweaks.var_cold
