scoreboard players add #bsclock tweaks.timer 1
execute if score #bsclock tweaks.timer matches 20.. as @e[type=minecraft:marker,tag=tweaks.brewstand] at @s run function tweaks:brewstand/check
execute if score #bsclock tweaks.timer matches 20.. run scoreboard players set #bsclock tweaks.timer 0
