scoreboard players set #hbclock tweaks.timer 0
# A new day: one chance in seven that he comes
execute unless score #hbday tweaks.year = #days tweaks.year run function tweaks:herobrine/new_day
execute if score #hbdue tweaks.year matches 1 if predicate tweaks:herobrine_chance unless entity @e[type=minecraft:mannequin,tag=tweaks.hb] as @a[gamemode=!spectator,limit=1,sort=random] at @s if dimension minecraft:overworld unless predicate tweaks:is_daytime run function tweaks:herobrine/try
execute if score #hbdue tweaks.year matches 1 if predicate tweaks:herobrine_chance unless entity @e[type=minecraft:mannequin,tag=tweaks.hb] as @a[gamemode=!spectator,limit=1,sort=random] at @s if dimension minecraft:overworld unless predicate tweaks:open_sky run function tweaks:herobrine/try
