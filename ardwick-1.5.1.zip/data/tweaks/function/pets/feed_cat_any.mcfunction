advancement revoke @s only tweaks:pets/cat_any
execute at @s as @e[type=#tweaks:pets,distance=..6,sort=nearest,limit=1] run function tweaks:pets/heal_2
