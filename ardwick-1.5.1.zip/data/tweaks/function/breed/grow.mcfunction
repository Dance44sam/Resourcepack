data modify entity @s Age set value 0
execute if entity @s[type=#tweaks:variant_animals] run function tweaks:breed/keep_variant
tag @s remove tweaks.wait_baby
scoreboard players reset @s tweaks.due
