tag @s add tweaks.rope4
attribute @s minecraft:scale base set 1
execute align xyz run tp @s ~0.5 ~0.125 ~0.3 0 0
execute at @s align xyz positioned ~0.5 ~0.55 ~0.5 unless entity @e[type=minecraft:leash_knot,distance=..0.5] run summon minecraft:leash_knot ~ ~ ~
