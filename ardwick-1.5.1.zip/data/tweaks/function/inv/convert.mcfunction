# Every inventory conversion, for one player
execute if score #inv_busy tweaks.calc2 matches 1 run return 0
scoreboard players set #inv_busy tweaks.calc2 1
function tweaks:oversize/pre
execute if items entity @s container.* #tweaks:inert_eggs[minecraft:entity_data] run function tweaks:dough/strip
execute if items entity @s weapon.offhand #tweaks:inert_eggs[minecraft:entity_data] run function tweaks:dough/strip
execute if items entity @s container.* minecraft:blue_dye[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:green_dye[minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:blue_dye[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:green_dye[minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:ravager_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:elder_guardian_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:vindicator_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:skeleton_horse_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* minecraft:piglin_brute_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:ravager_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:elder_guardian_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:vindicator_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:skeleton_horse_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s weapon.offhand minecraft:piglin_brute_spawn_egg[!minecraft:provides_trim_material] run function tweaks:dye/convert
execute if items entity @s container.* #tweaks:weapons[!minecraft:custom_data~{tweaks_weapon:4b}] run function tweaks:weapons/convert_inventory
execute if items entity @s weapon.offhand #tweaks:weapons[!minecraft:custom_data~{tweaks_weapon:4b}] run function tweaks:weapons/convert_inventory
execute if items entity @s container.* #tweaks:food[!minecraft:custom_data~{ardwick_food_v16:1b},!minecraft:custom_data~{tweaks_pasty:1b},!minecraft:custom_data~{tweaks_cooked_carrot:1b}] run function tweaks:food/convert_inventory
execute if items entity @s weapon.offhand #tweaks:food[!minecraft:custom_data~{ardwick_food_v16:1b},!minecraft:custom_data~{tweaks_pasty:1b},!minecraft:custom_data~{tweaks_cooked_carrot:1b}] run function tweaks:food/convert_inventory
execute if items entity @s container.* minecraft:beetroot[minecraft:custom_data~{tweaks_cooked_carrot:1b},!minecraft:custom_data~{ardwick_food_v16:1b}] run function tweaks:food/cooked_carrot_inventory
execute if items entity @s weapon.offhand minecraft:beetroot[minecraft:custom_data~{tweaks_cooked_carrot:1b},!minecraft:custom_data~{ardwick_food_v16:1b}] run function tweaks:food/cooked_carrot_inventory
execute if items entity @s container.* minecraft:compass[!minecraft:lodestone_tracker] run function tweaks:compass/convert_inventory
execute if items entity @s weapon.offhand minecraft:compass[!minecraft:lodestone_tracker] run function tweaks:compass/convert_inventory
execute if items entity @s player.cursor minecraft:compass[!minecraft:lodestone_tracker] run function tweaks:compass/convert_inventory
execute if items entity @s container.* minecraft:compass[minecraft:custom_data~{tweaks_north:1b},!minecraft:lodestone_tracker={target:{pos:[I;0,64,-29999984],dimension:"minecraft:overworld"},tracked:false}] run function tweaks:compass/convert_inventory
execute if items entity @s weapon.offhand minecraft:compass[minecraft:custom_data~{tweaks_north:1b},!minecraft:lodestone_tracker={target:{pos:[I;0,64,-29999984],dimension:"minecraft:overworld"},tracked:false}] run function tweaks:compass/convert_inventory
execute if items entity @s container.* minecraft:lead[!minecraft:custom_data~{tweaks_rope:1b}] run function tweaks:rope/convert_inventory
execute if items entity @s weapon.offhand minecraft:lead[!minecraft:custom_data~{tweaks_rope:1b}] run function tweaks:rope/convert_inventory
execute if items entity @s container.* #tweaks:disguises[!minecraft:custom_data~{tweaks_disguise:1b}] run function tweaks:disguise/convert_inventory
execute if items entity @s weapon.offhand #tweaks:disguises[!minecraft:custom_data~{tweaks_disguise:1b}] run function tweaks:disguise/convert_inventory
execute if items entity @s armor.head #tweaks:disguises[!minecraft:custom_data~{tweaks_disguise:1b}] run function tweaks:disguise/convert_inventory
execute if items entity @s container.* minecraft:leather[minecraft:custom_data] run function tweaks:leather/carried
execute if items entity @s weapon.offhand minecraft:leather[minecraft:custom_data] run function tweaks:leather/carried
execute if items entity @s container.* #tweaks:armor[!minecraft:custom_data~{tweaks_armor:13b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"bronze"}] run function tweaks:armor/convert_inventory
execute if items entity @s armor.* #tweaks:armor[!minecraft:custom_data~{tweaks_armor:13b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"bronze"}] run function tweaks:armor/convert_inventory
execute if items entity @s weapon.offhand #tweaks:armor[!minecraft:custom_data~{tweaks_armor:13b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"bronze"}] run function tweaks:armor/convert_inventory
execute if items entity @s container.* #tweaks:gold_tools[!minecraft:enchantments~[{enchantments:"minecraft:silk_touch"}]|!minecraft:enchantment_glint_override|minecraft:tooltip_display|!minecraft:custom_data~{tweaks_gold:2b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"silver"},!minecraft:custom_data~{tweaks_alloy:"shibuichi"}] run function tweaks:gold_tools/convert_inventory
execute if items entity @s weapon.offhand #tweaks:gold_tools[!minecraft:enchantments~[{enchantments:"minecraft:silk_touch"}]|!minecraft:enchantment_glint_override|minecraft:tooltip_display|!minecraft:custom_data~{tweaks_gold:2b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"silver"},!minecraft:custom_data~{tweaks_alloy:"shibuichi"}] run function tweaks:gold_tools/convert_inventory
execute if items entity @s container.* #tweaks:pickaxes[!minecraft:custom_data~{tweaks_pick:3b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"bronze"}] run function tweaks:pickaxes/convert_inventory
execute if items entity @s weapon.offhand #tweaks:pickaxes[!minecraft:custom_data~{tweaks_pick:3b},!minecraft:custom_data~{tweaks_alloy:"rose_gold"},!minecraft:custom_data~{tweaks_alloy:"bronze"}] run function tweaks:pickaxes/convert_inventory
execute if items entity @s container.* #tweaks:bows[!minecraft:custom_data~{tweaks_bow:2b}] run function tweaks:bows/convert_inventory
execute if items entity @s weapon.offhand #tweaks:bows[!minecraft:custom_data~{tweaks_bow:2b}] run function tweaks:bows/convert_inventory
execute if items entity @s armor.* #tweaks:copper_armor run function tweaks:copper/player
execute if entity @s[advancements={tweaks:peace_at_last=true}] if items entity @s container.* #minecraft:leg_armor[!minecraft:custom_data~{tweaks_swift:1b}] run function tweaks:warden/reward
execute if entity @s[advancements={tweaks:peace_at_last=true}] if items entity @s armor.legs #minecraft:leg_armor[!minecraft:custom_data~{tweaks_swift:1b}] run function tweaks:warden/reward
execute if entity @s[advancements={tweaks:peace_at_last=true}] if items entity @s weapon.offhand #minecraft:leg_armor[!minecraft:custom_data~{tweaks_swift:1b}] run function tweaks:warden/reward
execute if items entity @s container.* *[minecraft:enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s container.* *[minecraft:stored_enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s container.* #tweaks:glints[!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s armor.* *[minecraft:enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s armor.* *[minecraft:stored_enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s armor.* #tweaks:glints[!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s weapon.offhand *[minecraft:enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s weapon.offhand *[minecraft:stored_enchantments~[{}],!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s weapon.offhand #tweaks:glints[!minecraft:enchantment_glint_override=false] run function tweaks:glint/player
execute if items entity @s container.0 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.0"}
execute if items entity @s container.1 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.1"}
execute if items entity @s container.2 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.2"}
execute if items entity @s container.3 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.3"}
execute if items entity @s container.4 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.4"}
execute if items entity @s container.5 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.5"}
execute if items entity @s container.6 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.6"}
execute if items entity @s container.7 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.7"}
execute if items entity @s container.8 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.8"}
execute if items entity @s container.9 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.9"}
execute if items entity @s container.10 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.10"}
execute if items entity @s container.11 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.11"}
execute if items entity @s container.12 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.12"}
execute if items entity @s container.13 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.13"}
execute if items entity @s container.14 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.14"}
execute if items entity @s container.15 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.15"}
execute if items entity @s container.16 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.16"}
execute if items entity @s container.17 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.17"}
execute if items entity @s container.18 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.18"}
execute if items entity @s container.19 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.19"}
execute if items entity @s container.20 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.20"}
execute if items entity @s container.21 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.21"}
execute if items entity @s container.22 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.22"}
execute if items entity @s container.23 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.23"}
execute if items entity @s container.24 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.24"}
execute if items entity @s container.25 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.25"}
execute if items entity @s container.26 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.26"}
execute if items entity @s container.27 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.27"}
execute if items entity @s container.28 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.28"}
execute if items entity @s container.29 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.29"}
execute if items entity @s container.30 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.30"}
execute if items entity @s container.31 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.31"}
execute if items entity @s container.32 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.32"}
execute if items entity @s container.33 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.33"}
execute if items entity @s container.34 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.34"}
execute if items entity @s container.35 #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"container.35"}
execute if items entity @s weapon.offhand #tweaks:coloured_eggs run function tweaks:eggs/swap {slot:"weapon.offhand"}
execute if items entity @s container.0 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.0"}
execute if items entity @s container.1 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.1"}
execute if items entity @s container.2 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.2"}
execute if items entity @s container.3 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.3"}
execute if items entity @s container.4 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.4"}
execute if items entity @s container.5 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.5"}
execute if items entity @s container.6 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.6"}
execute if items entity @s container.7 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.7"}
execute if items entity @s container.8 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.8"}
execute if items entity @s container.9 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.9"}
execute if items entity @s container.10 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.10"}
execute if items entity @s container.11 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.11"}
execute if items entity @s container.12 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.12"}
execute if items entity @s container.13 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.13"}
execute if items entity @s container.14 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.14"}
execute if items entity @s container.15 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.15"}
execute if items entity @s container.16 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.16"}
execute if items entity @s container.17 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.17"}
execute if items entity @s container.18 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.18"}
execute if items entity @s container.19 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.19"}
execute if items entity @s container.20 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.20"}
execute if items entity @s container.21 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.21"}
execute if items entity @s container.22 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.22"}
execute if items entity @s container.23 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.23"}
execute if items entity @s container.24 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.24"}
execute if items entity @s container.25 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.25"}
execute if items entity @s container.26 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.26"}
execute if items entity @s container.27 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.27"}
execute if items entity @s container.28 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.28"}
execute if items entity @s container.29 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.29"}
execute if items entity @s container.30 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.30"}
execute if items entity @s container.31 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.31"}
execute if items entity @s container.32 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.32"}
execute if items entity @s container.33 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.33"}
execute if items entity @s container.34 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.34"}
execute if items entity @s container.35 minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"container.35"}
execute if items entity @s weapon.offhand minecraft:glowstone_dust run function tweaks:glowdust/swap {slot:"weapon.offhand"}
execute if items entity @s container.0 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.0 tweaks:trident/convert
execute if items entity @s container.1 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.1 tweaks:trident/convert
execute if items entity @s container.2 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.2 tweaks:trident/convert
execute if items entity @s container.3 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.3 tweaks:trident/convert
execute if items entity @s container.4 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.4 tweaks:trident/convert
execute if items entity @s container.5 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.5 tweaks:trident/convert
execute if items entity @s container.6 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.6 tweaks:trident/convert
execute if items entity @s container.7 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.7 tweaks:trident/convert
execute if items entity @s container.8 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.8 tweaks:trident/convert
execute if items entity @s container.9 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.9 tweaks:trident/convert
execute if items entity @s container.10 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.10 tweaks:trident/convert
execute if items entity @s container.11 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.11 tweaks:trident/convert
execute if items entity @s container.12 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.12 tweaks:trident/convert
execute if items entity @s container.13 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.13 tweaks:trident/convert
execute if items entity @s container.14 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.14 tweaks:trident/convert
execute if items entity @s container.15 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.15 tweaks:trident/convert
execute if items entity @s container.16 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.16 tweaks:trident/convert
execute if items entity @s container.17 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.17 tweaks:trident/convert
execute if items entity @s container.18 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.18 tweaks:trident/convert
execute if items entity @s container.19 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.19 tweaks:trident/convert
execute if items entity @s container.20 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.20 tweaks:trident/convert
execute if items entity @s container.21 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.21 tweaks:trident/convert
execute if items entity @s container.22 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.22 tweaks:trident/convert
execute if items entity @s container.23 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.23 tweaks:trident/convert
execute if items entity @s container.24 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.24 tweaks:trident/convert
execute if items entity @s container.25 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.25 tweaks:trident/convert
execute if items entity @s container.26 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.26 tweaks:trident/convert
execute if items entity @s container.27 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.27 tweaks:trident/convert
execute if items entity @s container.28 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.28 tweaks:trident/convert
execute if items entity @s container.29 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.29 tweaks:trident/convert
execute if items entity @s container.30 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.30 tweaks:trident/convert
execute if items entity @s container.31 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.31 tweaks:trident/convert
execute if items entity @s container.32 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.32 tweaks:trident/convert
execute if items entity @s container.33 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.33 tweaks:trident/convert
execute if items entity @s container.34 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.34 tweaks:trident/convert
execute if items entity @s container.35 minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s container.35 tweaks:trident/convert
execute if items entity @s weapon.offhand minecraft:trident[!minecraft:custom_data~{tweaks_trident:1b}] run item modify entity @s weapon.offhand tweaks:trident/convert
execute if items entity @s container.0 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.0 tweaks:potion/stack
execute if items entity @s container.1 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.1 tweaks:potion/stack
execute if items entity @s container.2 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.2 tweaks:potion/stack
execute if items entity @s container.3 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.3 tweaks:potion/stack
execute if items entity @s container.4 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.4 tweaks:potion/stack
execute if items entity @s container.5 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.5 tweaks:potion/stack
execute if items entity @s container.6 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.6 tweaks:potion/stack
execute if items entity @s container.7 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.7 tweaks:potion/stack
execute if items entity @s container.8 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.8 tweaks:potion/stack
execute if items entity @s container.9 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.9 tweaks:potion/stack
execute if items entity @s container.10 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.10 tweaks:potion/stack
execute if items entity @s container.11 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.11 tweaks:potion/stack
execute if items entity @s container.12 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.12 tweaks:potion/stack
execute if items entity @s container.13 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.13 tweaks:potion/stack
execute if items entity @s container.14 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.14 tweaks:potion/stack
execute if items entity @s container.15 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.15 tweaks:potion/stack
execute if items entity @s container.16 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.16 tweaks:potion/stack
execute if items entity @s container.17 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.17 tweaks:potion/stack
execute if items entity @s container.18 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.18 tweaks:potion/stack
execute if items entity @s container.19 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.19 tweaks:potion/stack
execute if items entity @s container.20 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.20 tweaks:potion/stack
execute if items entity @s container.21 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.21 tweaks:potion/stack
execute if items entity @s container.22 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.22 tweaks:potion/stack
execute if items entity @s container.23 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.23 tweaks:potion/stack
execute if items entity @s container.24 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.24 tweaks:potion/stack
execute if items entity @s container.25 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.25 tweaks:potion/stack
execute if items entity @s container.26 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.26 tweaks:potion/stack
execute if items entity @s container.27 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.27 tweaks:potion/stack
execute if items entity @s container.28 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.28 tweaks:potion/stack
execute if items entity @s container.29 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.29 tweaks:potion/stack
execute if items entity @s container.30 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.30 tweaks:potion/stack
execute if items entity @s container.31 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.31 tweaks:potion/stack
execute if items entity @s container.32 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.32 tweaks:potion/stack
execute if items entity @s container.33 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.33 tweaks:potion/stack
execute if items entity @s container.34 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.34 tweaks:potion/stack
execute if items entity @s container.35 #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s container.35 tweaks:potion/stack
execute if items entity @s weapon.offhand #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s weapon.offhand tweaks:potion/stack
execute if items entity @s container.0 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.0 tweaks:seeds/stack
execute if items entity @s container.1 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.1 tweaks:seeds/stack
execute if items entity @s container.2 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.2 tweaks:seeds/stack
execute if items entity @s container.3 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.3 tweaks:seeds/stack
execute if items entity @s container.4 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.4 tweaks:seeds/stack
execute if items entity @s container.5 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.5 tweaks:seeds/stack
execute if items entity @s container.6 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.6 tweaks:seeds/stack
execute if items entity @s container.7 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.7 tweaks:seeds/stack
execute if items entity @s container.8 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.8 tweaks:seeds/stack
execute if items entity @s container.9 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.9 tweaks:seeds/stack
execute if items entity @s container.10 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.10 tweaks:seeds/stack
execute if items entity @s container.11 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.11 tweaks:seeds/stack
execute if items entity @s container.12 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.12 tweaks:seeds/stack
execute if items entity @s container.13 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.13 tweaks:seeds/stack
execute if items entity @s container.14 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.14 tweaks:seeds/stack
execute if items entity @s container.15 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.15 tweaks:seeds/stack
execute if items entity @s container.16 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.16 tweaks:seeds/stack
execute if items entity @s container.17 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.17 tweaks:seeds/stack
execute if items entity @s container.18 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.18 tweaks:seeds/stack
execute if items entity @s container.19 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.19 tweaks:seeds/stack
execute if items entity @s container.20 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.20 tweaks:seeds/stack
execute if items entity @s container.21 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.21 tweaks:seeds/stack
execute if items entity @s container.22 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.22 tweaks:seeds/stack
execute if items entity @s container.23 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.23 tweaks:seeds/stack
execute if items entity @s container.24 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.24 tweaks:seeds/stack
execute if items entity @s container.25 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.25 tweaks:seeds/stack
execute if items entity @s container.26 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.26 tweaks:seeds/stack
execute if items entity @s container.27 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.27 tweaks:seeds/stack
execute if items entity @s container.28 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.28 tweaks:seeds/stack
execute if items entity @s container.29 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.29 tweaks:seeds/stack
execute if items entity @s container.30 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.30 tweaks:seeds/stack
execute if items entity @s container.31 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.31 tweaks:seeds/stack
execute if items entity @s container.32 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.32 tweaks:seeds/stack
execute if items entity @s container.33 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.33 tweaks:seeds/stack
execute if items entity @s container.34 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.34 tweaks:seeds/stack
execute if items entity @s container.35 #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s container.35 tweaks:seeds/stack
execute if items entity @s weapon.offhand #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s weapon.offhand tweaks:seeds/stack
execute if items entity @s container.0 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.0 tweaks:glint/restore
execute if items entity @s container.1 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.1 tweaks:glint/restore
execute if items entity @s container.2 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.2 tweaks:glint/restore
execute if items entity @s container.3 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.3 tweaks:glint/restore
execute if items entity @s container.4 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.4 tweaks:glint/restore
execute if items entity @s container.5 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.5 tweaks:glint/restore
execute if items entity @s container.6 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.6 tweaks:glint/restore
execute if items entity @s container.7 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.7 tweaks:glint/restore
execute if items entity @s container.8 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.8 tweaks:glint/restore
execute if items entity @s container.9 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.9 tweaks:glint/restore
execute if items entity @s container.10 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.10 tweaks:glint/restore
execute if items entity @s container.11 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.11 tweaks:glint/restore
execute if items entity @s container.12 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.12 tweaks:glint/restore
execute if items entity @s container.13 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.13 tweaks:glint/restore
execute if items entity @s container.14 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.14 tweaks:glint/restore
execute if items entity @s container.15 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.15 tweaks:glint/restore
execute if items entity @s container.16 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.16 tweaks:glint/restore
execute if items entity @s container.17 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.17 tweaks:glint/restore
execute if items entity @s container.18 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.18 tweaks:glint/restore
execute if items entity @s container.19 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.19 tweaks:glint/restore
execute if items entity @s container.20 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.20 tweaks:glint/restore
execute if items entity @s container.21 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.21 tweaks:glint/restore
execute if items entity @s container.22 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.22 tweaks:glint/restore
execute if items entity @s container.23 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.23 tweaks:glint/restore
execute if items entity @s container.24 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.24 tweaks:glint/restore
execute if items entity @s container.25 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.25 tweaks:glint/restore
execute if items entity @s container.26 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.26 tweaks:glint/restore
execute if items entity @s container.27 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.27 tweaks:glint/restore
execute if items entity @s container.28 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.28 tweaks:glint/restore
execute if items entity @s container.29 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.29 tweaks:glint/restore
execute if items entity @s container.30 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.30 tweaks:glint/restore
execute if items entity @s container.31 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.31 tweaks:glint/restore
execute if items entity @s container.32 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.32 tweaks:glint/restore
execute if items entity @s container.33 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.33 tweaks:glint/restore
execute if items entity @s container.34 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.34 tweaks:glint/restore
execute if items entity @s container.35 #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s container.35 tweaks:glint/restore
execute if items entity @s weapon.offhand #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s weapon.offhand tweaks:glint/restore
execute if items entity @s container.0 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.0 tweaks:stack/one
execute if items entity @s container.1 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.1 tweaks:stack/one
execute if items entity @s container.2 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.2 tweaks:stack/one
execute if items entity @s container.3 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.3 tweaks:stack/one
execute if items entity @s container.4 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.4 tweaks:stack/one
execute if items entity @s container.5 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.5 tweaks:stack/one
execute if items entity @s container.6 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.6 tweaks:stack/one
execute if items entity @s container.7 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.7 tweaks:stack/one
execute if items entity @s container.8 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.8 tweaks:stack/one
execute if items entity @s container.9 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.9 tweaks:stack/one
execute if items entity @s container.10 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.10 tweaks:stack/one
execute if items entity @s container.11 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.11 tweaks:stack/one
execute if items entity @s container.12 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.12 tweaks:stack/one
execute if items entity @s container.13 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.13 tweaks:stack/one
execute if items entity @s container.14 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.14 tweaks:stack/one
execute if items entity @s container.15 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.15 tweaks:stack/one
execute if items entity @s container.16 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.16 tweaks:stack/one
execute if items entity @s container.17 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.17 tweaks:stack/one
execute if items entity @s container.18 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.18 tweaks:stack/one
execute if items entity @s container.19 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.19 tweaks:stack/one
execute if items entity @s container.20 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.20 tweaks:stack/one
execute if items entity @s container.21 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.21 tweaks:stack/one
execute if items entity @s container.22 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.22 tweaks:stack/one
execute if items entity @s container.23 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.23 tweaks:stack/one
execute if items entity @s container.24 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.24 tweaks:stack/one
execute if items entity @s container.25 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.25 tweaks:stack/one
execute if items entity @s container.26 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.26 tweaks:stack/one
execute if items entity @s container.27 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.27 tweaks:stack/one
execute if items entity @s container.28 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.28 tweaks:stack/one
execute if items entity @s container.29 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.29 tweaks:stack/one
execute if items entity @s container.30 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.30 tweaks:stack/one
execute if items entity @s container.31 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.31 tweaks:stack/one
execute if items entity @s container.32 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.32 tweaks:stack/one
execute if items entity @s container.33 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.33 tweaks:stack/one
execute if items entity @s container.34 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.34 tweaks:stack/one
execute if items entity @s container.35 #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s container.35 tweaks:stack/one
execute if items entity @s weapon.offhand #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s weapon.offhand tweaks:stack/one
execute if items entity @s container.* #tweaks:body_armor[!minecraft:custom_data~{tweaks_body:1b}] run function tweaks:body/convert_inventory
execute if items entity @s weapon.offhand #tweaks:body_armor[!minecraft:custom_data~{tweaks_body:1b}] run function tweaks:body/convert_inventory
execute if items entity @s container.0 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.0 tweaks:armor/specialty
execute if items entity @s container.1 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.1 tweaks:armor/specialty
execute if items entity @s container.2 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.2 tweaks:armor/specialty
execute if items entity @s container.3 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.3 tweaks:armor/specialty
execute if items entity @s container.4 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.4 tweaks:armor/specialty
execute if items entity @s container.5 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.5 tweaks:armor/specialty
execute if items entity @s container.6 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.6 tweaks:armor/specialty
execute if items entity @s container.7 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.7 tweaks:armor/specialty
execute if items entity @s container.8 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.8 tweaks:armor/specialty
execute if items entity @s container.9 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.9 tweaks:armor/specialty
execute if items entity @s container.10 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.10 tweaks:armor/specialty
execute if items entity @s container.11 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.11 tweaks:armor/specialty
execute if items entity @s container.12 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.12 tweaks:armor/specialty
execute if items entity @s container.13 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.13 tweaks:armor/specialty
execute if items entity @s container.14 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.14 tweaks:armor/specialty
execute if items entity @s container.15 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.15 tweaks:armor/specialty
execute if items entity @s container.16 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.16 tweaks:armor/specialty
execute if items entity @s container.17 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.17 tweaks:armor/specialty
execute if items entity @s container.18 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.18 tweaks:armor/specialty
execute if items entity @s container.19 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.19 tweaks:armor/specialty
execute if items entity @s container.20 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.20 tweaks:armor/specialty
execute if items entity @s container.21 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.21 tweaks:armor/specialty
execute if items entity @s container.22 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.22 tweaks:armor/specialty
execute if items entity @s container.23 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.23 tweaks:armor/specialty
execute if items entity @s container.24 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.24 tweaks:armor/specialty
execute if items entity @s container.25 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.25 tweaks:armor/specialty
execute if items entity @s container.26 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.26 tweaks:armor/specialty
execute if items entity @s container.27 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.27 tweaks:armor/specialty
execute if items entity @s container.28 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.28 tweaks:armor/specialty
execute if items entity @s container.29 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.29 tweaks:armor/specialty
execute if items entity @s container.30 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.30 tweaks:armor/specialty
execute if items entity @s container.31 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.31 tweaks:armor/specialty
execute if items entity @s container.32 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.32 tweaks:armor/specialty
execute if items entity @s container.33 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.33 tweaks:armor/specialty
execute if items entity @s container.34 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.34 tweaks:armor/specialty
execute if items entity @s container.35 #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s container.35 tweaks:armor/specialty
execute if items entity @s weapon.offhand #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s weapon.offhand tweaks:armor/specialty
execute if items entity @s armor.head #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.head tweaks:armor/specialty
execute if items entity @s armor.chest #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.chest tweaks:armor/specialty
execute if items entity @s armor.legs #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.legs tweaks:armor/specialty
execute if items entity @s armor.feet #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.feet tweaks:armor/specialty
execute if items entity @s container.0 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.0 tweaks:armor/labels
execute if items entity @s container.1 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.1 tweaks:armor/labels
execute if items entity @s container.2 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.2 tweaks:armor/labels
execute if items entity @s container.3 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.3 tweaks:armor/labels
execute if items entity @s container.4 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.4 tweaks:armor/labels
execute if items entity @s container.5 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.5 tweaks:armor/labels
execute if items entity @s container.6 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.6 tweaks:armor/labels
execute if items entity @s container.7 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.7 tweaks:armor/labels
execute if items entity @s container.8 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.8 tweaks:armor/labels
execute if items entity @s container.9 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.9 tweaks:armor/labels
execute if items entity @s container.10 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.10 tweaks:armor/labels
execute if items entity @s container.11 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.11 tweaks:armor/labels
execute if items entity @s container.12 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.12 tweaks:armor/labels
execute if items entity @s container.13 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.13 tweaks:armor/labels
execute if items entity @s container.14 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.14 tweaks:armor/labels
execute if items entity @s container.15 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.15 tweaks:armor/labels
execute if items entity @s container.16 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.16 tweaks:armor/labels
execute if items entity @s container.17 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.17 tweaks:armor/labels
execute if items entity @s container.18 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.18 tweaks:armor/labels
execute if items entity @s container.19 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.19 tweaks:armor/labels
execute if items entity @s container.20 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.20 tweaks:armor/labels
execute if items entity @s container.21 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.21 tweaks:armor/labels
execute if items entity @s container.22 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.22 tweaks:armor/labels
execute if items entity @s container.23 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.23 tweaks:armor/labels
execute if items entity @s container.24 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.24 tweaks:armor/labels
execute if items entity @s container.25 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.25 tweaks:armor/labels
execute if items entity @s container.26 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.26 tweaks:armor/labels
execute if items entity @s container.27 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.27 tweaks:armor/labels
execute if items entity @s container.28 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.28 tweaks:armor/labels
execute if items entity @s container.29 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.29 tweaks:armor/labels
execute if items entity @s container.30 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.30 tweaks:armor/labels
execute if items entity @s container.31 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.31 tweaks:armor/labels
execute if items entity @s container.32 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.32 tweaks:armor/labels
execute if items entity @s container.33 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.33 tweaks:armor/labels
execute if items entity @s container.34 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.34 tweaks:armor/labels
execute if items entity @s container.35 #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s container.35 tweaks:armor/labels
execute if items entity @s weapon.offhand #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s weapon.offhand tweaks:armor/labels
execute if items entity @s armor.head #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s armor.head tweaks:armor/labels
execute if items entity @s armor.chest #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s armor.chest tweaks:armor/labels
execute if items entity @s armor.legs #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s armor.legs tweaks:armor/labels
execute if items entity @s armor.feet #tweaks:armor[!minecraft:custom_data~{tweaks_label:11b}] run item modify entity @s armor.feet tweaks:armor/labels
function tweaks:oversize/post
function tweaks:shulker/weigh
scoreboard players set #inv_busy tweaks.calc2 0
execute if items entity @s container.0 #tweaks:spears run item modify entity @s container.0 tweaks:spears/throwable
execute if items entity @s container.1 #tweaks:spears run item modify entity @s container.1 tweaks:spears/throwable
execute if items entity @s container.2 #tweaks:spears run item modify entity @s container.2 tweaks:spears/throwable
execute if items entity @s container.3 #tweaks:spears run item modify entity @s container.3 tweaks:spears/throwable
execute if items entity @s container.4 #tweaks:spears run item modify entity @s container.4 tweaks:spears/throwable
execute if items entity @s container.5 #tweaks:spears run item modify entity @s container.5 tweaks:spears/throwable
execute if items entity @s container.6 #tweaks:spears run item modify entity @s container.6 tweaks:spears/throwable
execute if items entity @s container.7 #tweaks:spears run item modify entity @s container.7 tweaks:spears/throwable
execute if items entity @s container.8 #tweaks:spears run item modify entity @s container.8 tweaks:spears/throwable
execute if items entity @s container.9 #tweaks:spears run item modify entity @s container.9 tweaks:spears/throwable
execute if items entity @s container.10 #tweaks:spears run item modify entity @s container.10 tweaks:spears/throwable
execute if items entity @s container.11 #tweaks:spears run item modify entity @s container.11 tweaks:spears/throwable
execute if items entity @s container.12 #tweaks:spears run item modify entity @s container.12 tweaks:spears/throwable
execute if items entity @s container.13 #tweaks:spears run item modify entity @s container.13 tweaks:spears/throwable
execute if items entity @s container.14 #tweaks:spears run item modify entity @s container.14 tweaks:spears/throwable
execute if items entity @s container.15 #tweaks:spears run item modify entity @s container.15 tweaks:spears/throwable
execute if items entity @s container.16 #tweaks:spears run item modify entity @s container.16 tweaks:spears/throwable
execute if items entity @s container.17 #tweaks:spears run item modify entity @s container.17 tweaks:spears/throwable
execute if items entity @s container.18 #tweaks:spears run item modify entity @s container.18 tweaks:spears/throwable
execute if items entity @s container.19 #tweaks:spears run item modify entity @s container.19 tweaks:spears/throwable
execute if items entity @s container.20 #tweaks:spears run item modify entity @s container.20 tweaks:spears/throwable
execute if items entity @s container.21 #tweaks:spears run item modify entity @s container.21 tweaks:spears/throwable
execute if items entity @s container.22 #tweaks:spears run item modify entity @s container.22 tweaks:spears/throwable
execute if items entity @s container.23 #tweaks:spears run item modify entity @s container.23 tweaks:spears/throwable
execute if items entity @s container.24 #tweaks:spears run item modify entity @s container.24 tweaks:spears/throwable
execute if items entity @s container.25 #tweaks:spears run item modify entity @s container.25 tweaks:spears/throwable
execute if items entity @s container.26 #tweaks:spears run item modify entity @s container.26 tweaks:spears/throwable
execute if items entity @s container.27 #tweaks:spears run item modify entity @s container.27 tweaks:spears/throwable
execute if items entity @s container.28 #tweaks:spears run item modify entity @s container.28 tweaks:spears/throwable
execute if items entity @s container.29 #tweaks:spears run item modify entity @s container.29 tweaks:spears/throwable
execute if items entity @s container.30 #tweaks:spears run item modify entity @s container.30 tweaks:spears/throwable
execute if items entity @s container.31 #tweaks:spears run item modify entity @s container.31 tweaks:spears/throwable
execute if items entity @s container.32 #tweaks:spears run item modify entity @s container.32 tweaks:spears/throwable
execute if items entity @s container.33 #tweaks:spears run item modify entity @s container.33 tweaks:spears/throwable
execute if items entity @s container.34 #tweaks:spears run item modify entity @s container.34 tweaks:spears/throwable
execute if items entity @s container.35 #tweaks:spears run item modify entity @s container.35 tweaks:spears/throwable
execute if items entity @s weapon.offhand #tweaks:spears run item modify entity @s weapon.offhand tweaks:spears/throwable
execute if items entity @s container.0 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.0 tweaks:spears/durability
execute if items entity @s container.1 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.1 tweaks:spears/durability
execute if items entity @s container.2 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.2 tweaks:spears/durability
execute if items entity @s container.3 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.3 tweaks:spears/durability
execute if items entity @s container.4 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.4 tweaks:spears/durability
execute if items entity @s container.5 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.5 tweaks:spears/durability
execute if items entity @s container.6 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.6 tweaks:spears/durability
execute if items entity @s container.7 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.7 tweaks:spears/durability
execute if items entity @s container.8 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.8 tweaks:spears/durability
execute if items entity @s container.9 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.9 tweaks:spears/durability
execute if items entity @s container.10 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.10 tweaks:spears/durability
execute if items entity @s container.11 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.11 tweaks:spears/durability
execute if items entity @s container.12 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.12 tweaks:spears/durability
execute if items entity @s container.13 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.13 tweaks:spears/durability
execute if items entity @s container.14 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.14 tweaks:spears/durability
execute if items entity @s container.15 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.15 tweaks:spears/durability
execute if items entity @s container.16 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.16 tweaks:spears/durability
execute if items entity @s container.17 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.17 tweaks:spears/durability
execute if items entity @s container.18 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.18 tweaks:spears/durability
execute if items entity @s container.19 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.19 tweaks:spears/durability
execute if items entity @s container.20 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.20 tweaks:spears/durability
execute if items entity @s container.21 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.21 tweaks:spears/durability
execute if items entity @s container.22 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.22 tweaks:spears/durability
execute if items entity @s container.23 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.23 tweaks:spears/durability
execute if items entity @s container.24 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.24 tweaks:spears/durability
execute if items entity @s container.25 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.25 tweaks:spears/durability
execute if items entity @s container.26 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.26 tweaks:spears/durability
execute if items entity @s container.27 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.27 tweaks:spears/durability
execute if items entity @s container.28 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.28 tweaks:spears/durability
execute if items entity @s container.29 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.29 tweaks:spears/durability
execute if items entity @s container.30 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.30 tweaks:spears/durability
execute if items entity @s container.31 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.31 tweaks:spears/durability
execute if items entity @s container.32 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.32 tweaks:spears/durability
execute if items entity @s container.33 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.33 tweaks:spears/durability
execute if items entity @s container.34 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.34 tweaks:spears/durability
execute if items entity @s container.35 minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s container.35 tweaks:spears/durability
execute if items entity @s weapon.offhand minecraft:trident[minecraft:custom_data~{tweaks_trident:1b},!minecraft:custom_data~{tweaks_spdur:2b}] run item modify entity @s weapon.offhand tweaks:spears/durability
# Leather armour lasts as long as copper armour (v0.759; mark tweaks_ldur)
execute if items entity @s container.0 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.0 tweaks:armor/leather_durability
execute if items entity @s container.1 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.1 tweaks:armor/leather_durability
execute if items entity @s container.2 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.2 tweaks:armor/leather_durability
execute if items entity @s container.3 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.3 tweaks:armor/leather_durability
execute if items entity @s container.4 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.4 tweaks:armor/leather_durability
execute if items entity @s container.5 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.5 tweaks:armor/leather_durability
execute if items entity @s container.6 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.6 tweaks:armor/leather_durability
execute if items entity @s container.7 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.7 tweaks:armor/leather_durability
execute if items entity @s container.8 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.8 tweaks:armor/leather_durability
execute if items entity @s container.9 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.9 tweaks:armor/leather_durability
execute if items entity @s container.10 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.10 tweaks:armor/leather_durability
execute if items entity @s container.11 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.11 tweaks:armor/leather_durability
execute if items entity @s container.12 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.12 tweaks:armor/leather_durability
execute if items entity @s container.13 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.13 tweaks:armor/leather_durability
execute if items entity @s container.14 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.14 tweaks:armor/leather_durability
execute if items entity @s container.15 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.15 tweaks:armor/leather_durability
execute if items entity @s container.16 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.16 tweaks:armor/leather_durability
execute if items entity @s container.17 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.17 tweaks:armor/leather_durability
execute if items entity @s container.18 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.18 tweaks:armor/leather_durability
execute if items entity @s container.19 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.19 tweaks:armor/leather_durability
execute if items entity @s container.20 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.20 tweaks:armor/leather_durability
execute if items entity @s container.21 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.21 tweaks:armor/leather_durability
execute if items entity @s container.22 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.22 tweaks:armor/leather_durability
execute if items entity @s container.23 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.23 tweaks:armor/leather_durability
execute if items entity @s container.24 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.24 tweaks:armor/leather_durability
execute if items entity @s container.25 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.25 tweaks:armor/leather_durability
execute if items entity @s container.26 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.26 tweaks:armor/leather_durability
execute if items entity @s container.27 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.27 tweaks:armor/leather_durability
execute if items entity @s container.28 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.28 tweaks:armor/leather_durability
execute if items entity @s container.29 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.29 tweaks:armor/leather_durability
execute if items entity @s container.30 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.30 tweaks:armor/leather_durability
execute if items entity @s container.31 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.31 tweaks:armor/leather_durability
execute if items entity @s container.32 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.32 tweaks:armor/leather_durability
execute if items entity @s container.33 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.33 tweaks:armor/leather_durability
execute if items entity @s container.34 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.34 tweaks:armor/leather_durability
execute if items entity @s container.35 #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s container.35 tweaks:armor/leather_durability
execute if items entity @s armor.head #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s armor.head tweaks:armor/leather_durability
execute if items entity @s armor.chest #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s armor.chest tweaks:armor/leather_durability
execute if items entity @s armor.legs #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s armor.legs tweaks:armor/leather_durability
execute if items entity @s armor.feet #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s armor.feet tweaks:armor/leather_durability
execute if items entity @s weapon.offhand #tweaks:leather_armor[!minecraft:custom_data~{tweaks_ldur:1b}] run item modify entity @s weapon.offhand tweaks:armor/leather_durability
