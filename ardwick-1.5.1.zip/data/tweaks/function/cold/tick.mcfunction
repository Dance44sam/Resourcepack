scoreboard players add #coldtimer tweaks.cold 1
execute if score #coldtimer tweaks.cold matches 20.. run function tweaks:cold/second
