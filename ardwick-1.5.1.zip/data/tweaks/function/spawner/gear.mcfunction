# A mob from an upgraded spawner is dressed slot by slot
loot replace entity @s armor.head loot tweaks:spawner_gear/head
loot replace entity @s armor.chest loot tweaks:spawner_gear/chest
loot replace entity @s armor.legs loot tweaks:spawner_gear/legs
loot replace entity @s armor.feet loot tweaks:spawner_gear/feet
execute if entity @s[type=#tweaks:spawner_melee] run loot replace entity @s weapon.mainhand loot tweaks:spawner_gear/hand
