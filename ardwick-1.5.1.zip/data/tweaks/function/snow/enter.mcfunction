attribute @s minecraft:movement_speed modifier remove tweaks:snow
attribute @s minecraft:movement_speed modifier add tweaks:snow -0.05 add_multiplied_total
tag @s add tweaks.on_snow
