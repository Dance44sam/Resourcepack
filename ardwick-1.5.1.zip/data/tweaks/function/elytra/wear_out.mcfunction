item replace entity @s armor.chest with air
playsound minecraft:entity.item.break player @s ~ ~ ~ 1 1
tellraw @s {"text":"The wings come apart.","color":"gray","italic":true}
