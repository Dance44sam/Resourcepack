# Chance in % of a stray
scoreboard players set #mc tweaks.calc2 0
execute if predicate tweaks:cold/b113 run scoreboard players set #mc tweaks.calc2 43
execute if predicate tweaks:cold/b117 run scoreboard players set #mc tweaks.calc2 56
execute if predicate tweaks:cold/b120 run scoreboard players set #mc tweaks.calc2 66
execute if predicate tweaks:cold/b130 run scoreboard players set #mc tweaks.calc2 100
execute if predicate tweaks:cold/b133 run scoreboard players set #mc tweaks.calc2 100
execute if predicate tweaks:cold/b147 run scoreboard players set #mc tweaks.calc2 100
execute if predicate tweaks:cold/b153 run scoreboard players set #mc tweaks.calc2 100
execute if predicate tweaks:cold/b167 run scoreboard players set #mc tweaks.calc2 100
execute if predicate tweaks:cold/b180 run scoreboard players set #mc tweaks.calc2 100
scoreboard players operation #wf tweaks.calc2 = #season tweaks.cold
scoreboard players remove #wf tweaks.calc2 300
scoreboard players operation #mc tweaks.calc2 *= #wf tweaks.calc2
scoreboard players operation #mc tweaks.calc2 /= #k700 tweaks.calc2
