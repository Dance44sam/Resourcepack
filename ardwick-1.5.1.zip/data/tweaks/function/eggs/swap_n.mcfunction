$item replace entity @s $(slot) with minecraft:egg $(n)
