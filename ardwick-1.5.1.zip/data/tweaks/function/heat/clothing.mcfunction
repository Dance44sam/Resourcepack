scoreboard players set #wear tweaks.heat 8
execute if items entity @s armor.head minecraft:golden_helmet[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 2
execute if items entity @s armor.head minecraft:golden_helmet[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 1
execute if items entity @s armor.head minecraft:leather_helmet run scoreboard players add #wear tweaks.heat 2
execute if items entity @s armor.chest minecraft:golden_chestplate[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 2
execute if items entity @s armor.chest minecraft:golden_chestplate[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 1
execute if items entity @s armor.chest minecraft:leather_chestplate run scoreboard players add #wear tweaks.heat 2
execute if items entity @s armor.legs minecraft:golden_leggings[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 2
execute if items entity @s armor.legs minecraft:golden_leggings[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 1
execute if items entity @s armor.legs minecraft:leather_leggings run scoreboard players add #wear tweaks.heat 2
execute if items entity @s armor.feet minecraft:golden_boots[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 2
execute if items entity @s armor.feet minecraft:golden_boots[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players remove #wear tweaks.heat 1
execute if items entity @s armor.feet minecraft:leather_boots run scoreboard players add #wear tweaks.heat 2
execute if score #gain tweaks.heat matches ..0 run return 0
scoreboard players operation #gain tweaks.heat *= #wear tweaks.heat
scoreboard players operation #gain tweaks.heat /= #eight tweaks.heat
