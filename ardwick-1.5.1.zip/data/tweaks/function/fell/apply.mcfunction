# Break speed on this log becomes one over the size of the tree
execute if score @s tweaks.fell_n matches ..1 run return run function tweaks:fell/clear
scoreboard players set #a tweaks.calc2 10000
scoreboard players operation #a tweaks.calc2 /= @s tweaks.fell_n
scoreboard players remove #a tweaks.calc2 10000
execute store result storage tweaks:fell amount double 0.0001 run scoreboard players get #a tweaks.calc2
attribute @s minecraft:block_break_speed modifier remove tweaks:fell
function tweaks:fell/set_mod with storage tweaks:fell
scoreboard players set @s tweaks.fell_on 1
