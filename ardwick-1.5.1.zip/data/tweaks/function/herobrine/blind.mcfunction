effect give @a[tag=tweaks.hb_target] minecraft:blindness 1 0 true
function tweaks:herobrine/vanish
# Driven off by a blinding
scoreboard players set #hbdue tweaks.year 1
