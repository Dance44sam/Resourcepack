tag @s add tweaks.warmed
effect give @s minecraft:regeneration 4 0 true
# A camp is only made once the cold is out of you
execute if score @s tweaks.cold matches ..2099 run function tweaks:campfire/rest
