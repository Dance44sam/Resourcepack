# Ore is worth the effort: twenty vigour, and three seconds before it starts to ease off
scoreboard players add @s tweaks.vigour 20
scoreboard players set @s tweaks.hold 60
scoreboard players reset @s tweaks.ore_coal_ore
scoreboard players reset @s tweaks.ore_deepslate_coal_ore
scoreboard players reset @s tweaks.ore_iron_ore
scoreboard players reset @s tweaks.ore_deepslate_iron_ore
scoreboard players reset @s tweaks.ore_copper_ore
scoreboard players reset @s tweaks.ore_deepslate_copper_ore
scoreboard players reset @s tweaks.ore_gold_ore
scoreboard players reset @s tweaks.ore_deepslate_gold_ore
scoreboard players reset @s tweaks.ore_redstone_ore
scoreboard players reset @s tweaks.ore_deepslate_redstone_ore
scoreboard players reset @s tweaks.ore_lapis_ore
scoreboard players reset @s tweaks.ore_deepslate_lapis_ore
scoreboard players reset @s tweaks.ore_diamond_ore
scoreboard players reset @s tweaks.ore_deepslate_diamond_ore
scoreboard players reset @s tweaks.ore_emerald_ore
scoreboard players reset @s tweaks.ore_deepslate_emerald_ore
scoreboard players reset @s tweaks.ore_nether_gold_ore
scoreboard players reset @s tweaks.ore_ancient_debris
