execute if block ~ ~ ~ minecraft:smoker align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.bloomery,distance=..0.5] run return run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.bloomery"]}
execute if block ~ ~ ~ minecraft:smoker run return 0
scoreboard players remove #bray tweaks.calc2 1
execute if score #bray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:bloomery/ray
