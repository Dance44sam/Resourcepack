function tweaks:heat/gross
# Nowhere hot at this moment (heat here couldn't beat the drift bare
execute if score #gross tweaks.heat <= #hdrift tweaks.heat run return run function tweaks:heat/drain
execute if predicate tweaks:open_sky run return run function tweaks:heat/build
scoreboard players remove @s tweaks.heat 4
