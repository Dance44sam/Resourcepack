$effect give @s minecraft:slowness $(s) 0 true
