# Spawners are made dangerous the first time one wakes
execute as @e[type=#tweaks:spawner_mobs,tag=!tweaks.sp_checked] at @s if entity @s[y=-64,dy=128] run function tweaks:spawner/find
execute as @e[type=minecraft:spider,tag=!tweaks.sp_checked] at @s if entity @e[type=minecraft:marker,tag=tweaks.spawner,distance=..6] run function tweaks:spawner/spider
tag @e[type=#tweaks:spawner_mobs,tag=!tweaks.sp_checked] add tweaks.sp_checked
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function tweaks:spawner/aim
scoreboard players add #spclock tweaks.timer 1
execute if score #spclock tweaks.timer matches 20.. as @e[type=minecraft:marker,tag=tweaks.spawner] at @s unless block ~ ~ ~ minecraft:spawner run function tweaks:spawner/broken
execute if score #spclock tweaks.timer matches 20.. run scoreboard players set #spclock tweaks.timer 0
