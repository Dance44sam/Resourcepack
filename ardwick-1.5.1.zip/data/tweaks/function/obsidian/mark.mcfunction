# Every lava source within 6 blocks, up to 200 at once
scoreboard players set #obn tweaks.calc2 0
scoreboard players set #sx tweaks.calc2 13
execute align xyz positioned ~-6 ~-6 ~-6 run function tweaks:obsidian/sx
