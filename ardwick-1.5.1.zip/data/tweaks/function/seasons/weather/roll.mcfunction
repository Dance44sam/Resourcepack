# Pick the next stretch of weather for the current season
execute store result score #roll tweaks.year run random value 1..10000
execute if score #day tweaks.year matches 0..6 run function tweaks:seasons/weather/summer
execute if score #day tweaks.year matches 7..13 run function tweaks:seasons/weather/autumn
execute if score #day tweaks.year matches 14..20 run function tweaks:seasons/weather/winter
execute if score #day tweaks.year matches 21..27 run function tweaks:seasons/weather/spring
