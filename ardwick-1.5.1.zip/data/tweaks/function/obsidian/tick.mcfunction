# A bucket emptied near lava: watch the lava sources nearby, and see which become obsidian
execute as @a[scores={tweaks.ob_water=1..}] at @s run function tweaks:obsidian/mark
execute as @a[scores={tweaks.ob_lava=1..}] at @s run function tweaks:obsidian/mark
execute as @a[scores={tweaks.ob_lava=1..}] at @s anchored eyes positioned ^ ^ ^ run function tweaks:obsidian/poured_start
scoreboard players reset @a tweaks.ob_water
scoreboard players reset @a tweaks.ob_lava
execute as @e[type=minecraft:marker,tag=tweaks.ob_watch] at @s run function tweaks:obsidian/watch
execute as @e[type=minecraft:blaze] at @s if block ~ ~ ~ minecraft:water run effect give @s minecraft:regeneration 2 3 true
execute as @e[type=minecraft:blaze] at @s if block ~ ~1 ~ minecraft:water run effect give @s minecraft:regeneration 2 3 true
