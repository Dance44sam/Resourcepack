# Which twelfth of the day we are in, read through time checks rather than a query
scoreboard players operation #was tweaks.sum = #bucket tweaks.sum
execute if predicate tweaks:twelfth_0 run scoreboard players set #bucket tweaks.sum 0
execute if predicate tweaks:twelfth_1 run scoreboard players set #bucket tweaks.sum 1
execute if predicate tweaks:twelfth_2 run scoreboard players set #bucket tweaks.sum 2
execute if predicate tweaks:twelfth_3 run scoreboard players set #bucket tweaks.sum 3
execute if predicate tweaks:twelfth_4 run scoreboard players set #bucket tweaks.sum 4
execute if predicate tweaks:twelfth_5 run scoreboard players set #bucket tweaks.sum 5
execute if predicate tweaks:twelfth_6 run scoreboard players set #bucket tweaks.sum 6
execute if predicate tweaks:twelfth_7 run scoreboard players set #bucket tweaks.sum 7
execute if predicate tweaks:twelfth_8 run scoreboard players set #bucket tweaks.sum 8
execute if predicate tweaks:twelfth_9 run scoreboard players set #bucket tweaks.sum 9
execute if predicate tweaks:twelfth_10 run scoreboard players set #bucket tweaks.sum 10
execute if predicate tweaks:twelfth_11 run scoreboard players set #bucket tweaks.sum 11
scoreboard players operation #diff tweaks.sum = #bucket tweaks.sum
scoreboard players operation #diff tweaks.sum -= #was tweaks.sum
execute if score #diff tweaks.sum matches 1 run function tweaks:sleep/clear_one
execute if score #diff tweaks.sum matches -11 run function tweaks:sleep/clear_one
execute if score #diff tweaks.sum matches 2..10 run function tweaks:sleep/clear_all
execute if score #diff tweaks.sum matches -10..-1 run function tweaks:sleep/clear_all
