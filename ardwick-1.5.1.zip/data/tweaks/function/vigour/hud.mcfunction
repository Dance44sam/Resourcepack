# Vigour drawn in the XP bar's place, at a quarter-pixel
scoreboard players operation #f tweaks.calc2 = @s tweaks.vigour
execute if score #f tweaks.calc2 matches ..-1 run scoreboard players operation #f tweaks.calc2 *= #neg1 tweaks.const
execute if score #f tweaks.calc2 matches 301.. run scoreboard players set #f tweaks.calc2 300
scoreboard players operation #f tweaks.calc2 *= #k356 tweaks.const
scoreboard players operation #f tweaks.calc2 += #k150 tweaks.const
scoreboard players operation #f tweaks.calc2 /= #k300 tweaks.const
scoreboard players operation #s tweaks.calc2 = #f tweaks.calc2
execute if score @s tweaks.vigour matches ..-1 run scoreboard players operation #s tweaks.calc2 *= #neg1 tweaks.const
scoreboard players operation #fr tweaks.calc2 = @s tweaks.frost
execute if score #fr tweaks.calc2 matches 301.. run scoreboard players set #fr tweaks.calc2 300
scoreboard players operation #fl tweaks.calc2 = @s tweaks.frost
scoreboard players operation #fl tweaks.calc2 -= #fr tweaks.calc2
execute if score #fl tweaks.calc2 matches 301.. run scoreboard players set #fl tweaks.calc2 300
scoreboard players operation #fr tweaks.calc2 *= #k356 tweaks.const
scoreboard players operation #fr tweaks.calc2 += #k150 tweaks.const
scoreboard players operation #fr tweaks.calc2 /= #k300 tweaks.const
scoreboard players operation #fl tweaks.calc2 *= #k356 tweaks.const
scoreboard players operation #fl tweaks.calc2 += #k150 tweaks.const
scoreboard players operation #fl tweaks.calc2 /= #k300 tweaks.const
scoreboard players operation #fk tweaks.calc2 = #fr tweaks.calc2
scoreboard players operation #fk tweaks.calc2 += #fl tweaks.calc2
scoreboard players remove @s tweaks.hud_t 1
execute unless score #s tweaks.calc2 = @s tweaks.hud_step run scoreboard players set @s tweaks.hud_t 0
execute unless score #fk tweaks.calc2 = @s tweaks.hud_fk run scoreboard players set @s tweaks.hud_t 0
scoreboard players operation @s tweaks.hud_step = #s tweaks.calc2
scoreboard players operation @s tweaks.hud_fk = #fk tweaks.calc2
execute if score @s tweaks.hud_t matches ..0 run function tweaks:vigour/hud_show
