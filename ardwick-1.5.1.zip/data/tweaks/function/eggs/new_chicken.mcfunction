tag @s add tweaks.chick_seen
execute unless predicate tweaks:baby run return 0
execute unless entity @e[type=minecraft:marker,tag=tweaks.egg_trace,distance=..3] run return 0
# The variant is also remembered as a tag, decided here rather than read back, so growing
tag @s remove tweaks.var_temperate
tag @s remove tweaks.var_warm
tag @s remove tweaks.var_cold
data modify entity @s variant set value "minecraft:temperate"
execute if predicate tweaks:biome_warm run data modify entity @s variant set value "minecraft:warm"
execute if predicate tweaks:biome_warm run tag @s add tweaks.var_warm
execute if predicate tweaks:biome_cold run data modify entity @s variant set value "minecraft:cold"
execute if predicate tweaks:biome_cold run tag @s add tweaks.var_cold
execute unless entity @s[tag=tweaks.var_warm] unless entity @s[tag=tweaks.var_cold] run tag @s add tweaks.var_temperate
