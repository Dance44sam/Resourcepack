# Every 5 ticks: a lit Bloomery shows flames at its mouth, as a lit Mud Kiln does
scoreboard players add #bclock tweaks.timer 1
execute if score #bclock tweaks.timer matches 5.. as @e[type=minecraft:marker,tag=tweaks.bloomery] at @s run function tweaks:bloomery/check
execute if score #bclock tweaks.timer matches 5.. run scoreboard players set #bclock tweaks.timer 0
