execute store result score #r tweaks.calc2 run data get entity @s ItemRotation
scoreboard players add #r tweaks.calc2 7
scoreboard players operation #r tweaks.calc2 %= #k8 tweaks.const
execute store result entity @s ItemRotation byte 1 run scoreboard players get #r tweaks.calc2
