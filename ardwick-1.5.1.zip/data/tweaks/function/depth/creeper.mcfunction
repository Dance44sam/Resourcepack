# Creepers: the fuse (39 ticks, set by mobs/creeper_seen) shortens to half, 20 ticks, at
scoreboard players operation #df tweaks.calc2 = #dm tweaks.calc2
scoreboard players operation #df tweaks.calc2 *= #19 tweaks.calc2
scoreboard players add #df tweaks.calc2 63
scoreboard players operation #df tweaks.calc2 /= #127 tweaks.calc2
scoreboard players set #dfu tweaks.calc2 39
scoreboard players operation #dfu tweaks.calc2 -= #df tweaks.calc2
execute store result entity @s Fuse short 1 run scoreboard players get #dfu tweaks.calc2
