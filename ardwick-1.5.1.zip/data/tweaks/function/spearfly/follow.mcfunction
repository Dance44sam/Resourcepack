scoreboard players operation #id tweaks.sfid = @s tweaks.sfid
tag @s add tweaks.sf_cur
execute as @e[type=minecraft:item_display,tag=tweaks.sf_disp] if score @s tweaks.sfid = #id tweaks.sfid run function tweaks:spearfly/place
tag @s remove tweaks.sf_cur
