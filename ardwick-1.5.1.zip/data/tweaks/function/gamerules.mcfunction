# Enforced on every world load and /reload
gamerule show_advancement_messages false
gamerule raids false
gamerule spawn_phantoms false
gamerule spawn_patrols false
gamerule spawn_wandering_traders false
gamerule keep_inventory true
gamerule natural_health_regeneration false
gamerule reduced_debug_info true
gamerule advance_weather false
gamerule players_sleeping_percentage 101
function tweaks:minecart_speed
