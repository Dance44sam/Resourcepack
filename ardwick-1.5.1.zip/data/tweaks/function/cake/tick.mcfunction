# A slice of cake heals 2 HP, through the same hidden healing (and matching slowness) as
execute as @a[scores={tweaks.cake=1..}] run function tweaks:cake/eat
