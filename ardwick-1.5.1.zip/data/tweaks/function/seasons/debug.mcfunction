function tweaks:seasons/update
tellraw @s ["Day of year: ",{"score":{"name":"#day","objective":"tweaks.year"}}," of 28"]
execute if predicate tweaks:is_daytime run tellraw @s "Phase: daytime"
execute unless predicate tweaks:is_daytime run tellraw @s "Phase: night"
tellraw @s ["Weather timer: ",{"score":{"name":"#wtimer","objective":"tweaks.year"}}," seconds"]
