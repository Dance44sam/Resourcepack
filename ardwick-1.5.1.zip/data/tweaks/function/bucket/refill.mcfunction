$setblock ~ ~ ~ $(block)
playsound minecraft:block.lava.extinguish block @a ~ ~ ~ 0.6 1.2
particle minecraft:large_smoke ~ ~0.4 ~ 0.2 0.15 0.2 0.01 6
