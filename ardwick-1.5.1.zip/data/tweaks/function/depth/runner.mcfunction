# Zombies (babies too), zombie villagers, husks, drowned, spiders and cave spiders
scoreboard players operation #ds tweaks.calc2 = #dm tweaks.calc2
scoreboard players operation #ds tweaks.calc2 *= #300 tweaks.calc2
scoreboard players operation #ds tweaks.calc2 /= #127 tweaks.calc2
execute store result storage tweaks:depth s double 0.001 run scoreboard players get #ds tweaks.calc2
function tweaks:depth/speed with storage tweaks:depth
