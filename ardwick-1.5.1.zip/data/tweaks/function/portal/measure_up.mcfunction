scoreboard players add #ph tweaks.calc2 1
execute if block ~ ~1 ~ minecraft:obsidian run return 1
execute unless block ~ ~1 ~ #tweaks:portal_space run return run scoreboard players set #ph tweaks.calc2 0
execute if score #ph tweaks.calc2 matches 22.. run return run scoreboard players set #ph tweaks.calc2 0
execute positioned ~ ~1 ~ run function tweaks:portal/measure_up
