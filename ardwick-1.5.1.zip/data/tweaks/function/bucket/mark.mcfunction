# Remember this block for 8 ticks with a marker at its centre (tagged lava source or lava
$execute unless entity @e[type=minecraft:marker,tag=tweaks.bkt,distance=..0.1] run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.bkt","tweaks.bkt_$(t)"]}
scoreboard players set @e[type=minecraft:marker,tag=tweaks.bkt,distance=..0.1] tweaks.bkt_age 0
