tag @s remove tweaks.eclipse_in
tag @s add tweaks.eclipse_out
scoreboard players set @s tweaks.deaths 0
