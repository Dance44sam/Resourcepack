advancement revoke @s only tweaks:feather/drink_2
# Stacks: each potion adds its time to whatever is left
scoreboard players add @s tweaks.ff 9600
function tweaks:feather/on
