# Grown up: put back the variant it was born with
execute if entity @s[tag=tweaks.var_temperate] run data modify entity @s variant set value "minecraft:temperate"
execute if entity @s[tag=tweaks.var_warm] run data modify entity @s variant set value "minecraft:warm"
execute if entity @s[tag=tweaks.var_cold] run data modify entity @s variant set value "minecraft:cold"
