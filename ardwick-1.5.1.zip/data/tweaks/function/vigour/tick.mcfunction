execute as @a unless score @s tweaks.vigour matches -2147483648..2147483647 run scoreboard players set @s tweaks.vigour 0
# The hold score must exist, or the decay below never matches anyone
scoreboard players add @a tweaks.hold 0
scoreboard players remove @a[scores={tweaks.hold=1..}] tweaks.hold 1
execute as @a run function tweaks:vigour/wear
scoreboard players add #vpar tweaks.timer 1
execute if score #vpar tweaks.timer matches 2.. run scoreboard players set #vpar tweaks.timer 0
execute if score #vpar tweaks.timer matches 0 run scoreboard players remove @a[predicate=tweaks:sprinting] tweaks.vigour 1
execute as @a run function tweaks:vigour/moved
execute as @a[scores={tweaks.hold=..0,tweaks.moved=1..}] unless predicate tweaks:sprinting run function tweaks:vigour/settle
execute as @a run function tweaks:vigour/cap
execute as @a[scores={tweaks.vigour=301..}] run scoreboard players set @s tweaks.vigour 300
execute as @a[scores={tweaks.vigour=..-301}] run scoreboard players set @s tweaks.vigour -300
execute as @a run function tweaks:vigour/apply
tag @a remove tweaks.jumpmount
execute as @a on vehicle if entity @s[type=#tweaks:jump_mounts] on passengers if entity @s[type=minecraft:player] run tag @s add tweaks.jumpmount
execute as @a[tag=tweaks.jumpmount] unless score @s tweaks.hud_t matches -1000 run function tweaks:vigour/hud_hide
execute as @a[gamemode=!creative,gamemode=!spectator,tag=!tweaks.jumpmount] run function tweaks:vigour/hud
# Every second, apply vigour and vitality afresh in case their modifiers were lost (respawn, dimension change, commands)
scoreboard players add #perf tweaks.timer 1
execute if score #perf tweaks.timer matches 20.. run scoreboard players reset @a tweaks.v_m
execute if score #perf tweaks.timer matches 20.. run scoreboard players reset @a tweaks.hp_prev
execute if score #perf tweaks.timer matches 20.. run scoreboard players set #perf tweaks.timer 0
