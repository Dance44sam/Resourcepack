# As a remembered marker
execute if entity @s[tag=tweaks.bkt_lava] if block ~ ~ ~ #minecraft:air run return run function tweaks:bucket/refill {block:"minecraft:lava"}
execute if entity @s[tag=tweaks.bkt_cauldron] if block ~ ~ ~ minecraft:cauldron run function tweaks:bucket/refill {block:"minecraft:lava_cauldron"}
