execute if block ~ ~ ~ #minecraft:fences align xyz positioned ~0.5 ~0.55 ~0.5 run return run function tweaks:rope/tie
execute unless block ~ ~ ~ #tweaks:place_through run return 0
scoreboard players remove #rp tweaks.calc2 1
execute if score #rp tweaks.calc2 matches 1.. positioned ^ ^ ^0.05 run function tweaks:rope/ray
