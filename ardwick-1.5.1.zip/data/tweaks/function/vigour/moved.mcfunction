# Distance covered this tick, by any way of moving on foot, in water or gliding
scoreboard players set @s tweaks.moved 0
scoreboard players operation @s tweaks.moved += @s tweaks.mv_walk
scoreboard players operation @s tweaks.moved += @s tweaks.mv_sprint
scoreboard players operation @s tweaks.moved += @s tweaks.mv_crouch
scoreboard players operation @s tweaks.moved += @s tweaks.mv_swim
scoreboard players operation @s tweaks.moved += @s tweaks.mv_wade
scoreboard players operation @s tweaks.moved += @s tweaks.mv_under
scoreboard players operation @s tweaks.moved += @s tweaks.mv_glide
scoreboard players set @s tweaks.mv_walk 0
scoreboard players set @s tweaks.mv_sprint 0
scoreboard players set @s tweaks.mv_crouch 0
scoreboard players set @s tweaks.mv_swim 0
scoreboard players set @s tweaks.mv_wade 0
scoreboard players set @s tweaks.mv_under 0
scoreboard players set @s tweaks.mv_glide 0
