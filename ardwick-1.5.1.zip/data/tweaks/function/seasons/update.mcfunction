scoreboard players set #seasontimer tweaks.year 0
# Read the day of the year from the world clock
function tweaks:seasons/read_day
execute if score #day tweaks.year matches 0..6 run gamerule random_tick_speed 3
execute if score #day tweaks.year matches 7..13 run gamerule random_tick_speed 2
execute if score #day tweaks.year matches 14..20 run gamerule random_tick_speed 1
execute if score #day tweaks.year matches 21..27 run gamerule random_tick_speed 2
execute if predicate tweaks:is_daytime run function tweaks:seasons/rate_day
execute unless predicate tweaks:is_daytime if predicate tweaks:is_twilight run function tweaks:seasons/rate_twilight
execute unless predicate tweaks:is_daytime unless predicate tweaks:is_twilight run function tweaks:seasons/rate_night
scoreboard players remove #wtimer tweaks.year 1
execute if score #wtimer tweaks.year matches ..0 run function tweaks:seasons/weather/roll
function tweaks:eclipse/watch
function tweaks:gilded/update
