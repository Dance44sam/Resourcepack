scoreboard players add #seasontimer tweaks.year 1
execute if score #seasontimer tweaks.year matches 20.. run function tweaks:seasons/update
# A player whose leave count no longer matches their stored copy has just joined
execute as @a unless score @s tweaks.online = @s tweaks.leaves run function tweaks:seasons/greet
