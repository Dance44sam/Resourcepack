tag @s add tweaks.egg_checked
# Only an egg the chicken laid: one a player dropped records its thrower and waits
execute if entity @s[nbt={Age:0s}] unless data entity @s Thrower unless entity @s[nbt={PickupDelay:40s}] if entity @e[type=minecraft:chicken,distance=..2] run function tweaks:eggs/maybe_feather
