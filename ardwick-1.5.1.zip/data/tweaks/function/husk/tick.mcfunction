# Husks poison instead of starving
execute as @a[tag=tweaks.husk_hit] run function tweaks:husk/poison
