# Check again here
execute unless block ~ ~ ~ #tweaks:crop_room run return 0
$setblock ~ ~ ~ $(crop)
execute store result score #n tweaks.calc2 run data get entity @s Item.count
execute if score #n tweaks.calc2 matches ..1 run return run kill @s
execute store result entity @s Item.count int 1 run scoreboard players remove #n tweaks.calc2 1
