# Chance in % of a warm swap
scoreboard players set #mw tweaks.calc2 0
execute if predicate tweaks:heat/b50 run scoreboard players set #mw tweaks.calc2 50
execute if predicate tweaks:heat/b100 run scoreboard players set #mw tweaks.calc2 75
scoreboard players operation #mw tweaks.calc2 *= #hseason tweaks.heat
scoreboard players operation #mw tweaks.calc2 /= #k1000 tweaks.calc2
