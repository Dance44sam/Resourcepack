spawnpoint @s ~ ~ ~
execute store result score @s tweaks.px run data get entity @s Pos[0] 1
execute store result score @s tweaks.pz run data get entity @s Pos[2] 1
# Where a Pearl of Returning sends you
execute store result score @s tweaks.spx run data get entity @s Pos[0] 1
execute store result score @s tweaks.spy run data get entity @s Pos[1] 1
execute store result score @s tweaks.spz run data get entity @s Pos[2] 1
scoreboard players set @s tweaks.sdim 0
execute if dimension minecraft:the_nether run scoreboard players set @s tweaks.sdim 1
execute if dimension minecraft:the_end run scoreboard players set @s tweaks.sdim 2
execute unless score @s tweaks.sx matches -2147483648..2147483647 run function tweaks:campfire/announce
execute if score @s tweaks.sx matches -2147483648..2147483647 run function tweaks:campfire/check_move
