# One thermometer: no cold builds while any heat remains
execute if score @s tweaks.heat matches 1.. run return 0
scoreboard players set #band tweaks.cold 100
execute if predicate tweaks:cold/b0 run scoreboard players set #band tweaks.cold 0
execute if predicate tweaks:cold/b67 run scoreboard players set #band tweaks.cold 67
execute if predicate tweaks:cold/b70 run scoreboard players set #band tweaks.cold 70
execute if predicate tweaks:cold/b73 run scoreboard players set #band tweaks.cold 73
execute if predicate tweaks:cold/b80 run scoreboard players set #band tweaks.cold 80
execute if predicate tweaks:cold/b87 run scoreboard players set #band tweaks.cold 87
execute if predicate tweaks:cold/b93 run scoreboard players set #band tweaks.cold 93
execute if predicate tweaks:cold/b100 run scoreboard players set #band tweaks.cold 100
execute if predicate tweaks:cold/b113 run scoreboard players set #band tweaks.cold 113
execute if predicate tweaks:cold/b117 run scoreboard players set #band tweaks.cold 117
execute if predicate tweaks:cold/b120 run scoreboard players set #band tweaks.cold 120
execute if predicate tweaks:cold/b130 run scoreboard players set #band tweaks.cold 130
execute if predicate tweaks:cold/b133 run scoreboard players set #band tweaks.cold 133
execute if predicate tweaks:cold/b147 run scoreboard players set #band tweaks.cold 147
execute if predicate tweaks:cold/b153 run scoreboard players set #band tweaks.cold 153
execute if predicate tweaks:cold/b167 run scoreboard players set #band tweaks.cold 167
execute if predicate tweaks:cold/b180 run scoreboard players set #band tweaks.cold 180
scoreboard players operation #gain tweaks.cold = #band tweaks.cold
scoreboard players operation #gain tweaks.cold *= #season tweaks.cold
scoreboard players operation #gain tweaks.cold *= #ctime tweaks.cold
scoreboard players operation #gain tweaks.cold /= #k100000 tweaks.calc2
execute if score @s tweaks.wet matches 1.. run scoreboard players operation #gain tweaks.cold *= #two tweaks.cold
function tweaks:cold/clothing
scoreboard players operation #gain tweaks.cold -= #drift tweaks.cold
execute if entity @s[tag=tweaks.abed] run scoreboard players operation #gain tweaks.cold *= #sleeprate tweaks.cold
scoreboard players operation @s tweaks.crem += #gain tweaks.cold
scoreboard players operation #q tweaks.calc2 = @s tweaks.crem
scoreboard players operation #q tweaks.calc2 /= #k10 tweaks.calc2
scoreboard players operation @s tweaks.cold += #q tweaks.calc2
scoreboard players operation @s tweaks.crem %= #k10 tweaks.calc2
