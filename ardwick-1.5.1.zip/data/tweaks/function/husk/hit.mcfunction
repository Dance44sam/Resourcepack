# A husk hit a player
advancement revoke @s only tweaks:husk/hit
tag @s add tweaks.husk_hit
