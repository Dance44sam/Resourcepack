$execute positioned $(x).0 $(y).0 $(z).0 unless block ~ ~ ~ #tweaks:tree_logs positioned ~0.5 ~0.5 ~0.5 run function tweaks:fell/fell
