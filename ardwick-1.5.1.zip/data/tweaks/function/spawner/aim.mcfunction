# A spawner is hard to break
execute unless items entity @s weapon.mainhand #minecraft:pickaxes run return run function tweaks:spawner/ease
scoreboard players set #sray tweaks.calc2 45
scoreboard players set #shit tweaks.calc2 0
execute anchored eyes positioned ^ ^ ^ run function tweaks:spawner/ray
execute if score #shit tweaks.calc2 matches 1 unless score @s tweaks.sp_hard matches 1 run function tweaks:spawner/harden
execute if score #shit tweaks.calc2 matches 0 run function tweaks:spawner/ease
