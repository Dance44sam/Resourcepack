# Ready to breed again after a span that suits the animal
data modify entity @s Age set value 2000000000
scoreboard players set #span tweaks.calc2 14
execute if entity @s[type=minecraft:chicken] run scoreboard players set #span tweaks.calc2 4
execute if entity @s[type=minecraft:rabbit] run scoreboard players set #span tweaks.calc2 4
execute if entity @s[type=minecraft:cow] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:mooshroom] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:sheep] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:pig] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:turtle] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:sniffer] run scoreboard players set #span tweaks.calc2 28
execute if entity @s[type=minecraft:frog] run scoreboard players set #span tweaks.calc2 4
execute if entity @s[type=minecraft:nautilus] run scoreboard players set #span tweaks.calc2 28
scoreboard players operation @s tweaks.due = #days tweaks.year
scoreboard players operation @s tweaks.due += #span tweaks.calc2
tag @s add tweaks.wait_parent
