# Bait: rotten flesh or a feather in the off hand gives the main-hand fishing rod a hidden
execute as @a[scores={tweaks.fished=1..}] if items entity @s weapon.offhand #tweaks:bait run item modify entity @s weapon.offhand tweaks:bait/consume
scoreboard players reset @a tweaks.fished
execute as @a if items entity @s weapon.mainhand minecraft:fishing_rod[!minecraft:custom_data~{tweaks_bait:1b}] if items entity @s weapon.offhand #tweaks:bait run item modify entity @s weapon.mainhand tweaks:bait/on
execute as @a if items entity @s container.* minecraft:fishing_rod[minecraft:custom_data~{tweaks_bait:1b}] unless function tweaks:bait/baiting run function tweaks:bait/off_all
execute as @a if items entity @s weapon.offhand minecraft:fishing_rod[minecraft:custom_data~{tweaks_bait:1b}] unless function tweaks:bait/baiting run function tweaks:bait/off_all
execute as @a if items entity @s player.cursor minecraft:fishing_rod[minecraft:custom_data~{tweaks_bait:1b}] unless function tweaks:bait/baiting run function tweaks:bait/off_all
