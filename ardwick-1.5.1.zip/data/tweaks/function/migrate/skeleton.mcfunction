tag @s add tweaks.mig
execute unless dimension minecraft:overworld run return 0
execute if entity @e[type=minecraft:marker,tag=tweaks.spawner,distance=..6] run return 0
function tweaks:migrate/warm_chance
function tweaks:migrate/cold_chance
execute store result score #r tweaks.calc2 run random value 0..99
execute if score #r tweaks.calc2 < #mw tweaks.calc2 run return run function tweaks:migrate/to_parched
execute if score #r tweaks.calc2 < #mc tweaks.calc2 run function tweaks:migrate/to_stray
