# How hot this place and moment are, before clothing and the drift
scoreboard players set #band tweaks.heat 0
execute if predicate tweaks:heat/b13 run scoreboard players set #band tweaks.heat 13
execute if predicate tweaks:heat/b25 run scoreboard players set #band tweaks.heat 25
execute if predicate tweaks:heat/b40 run scoreboard players set #band tweaks.heat 40
execute if predicate tweaks:heat/b45 run scoreboard players set #band tweaks.heat 45
execute if predicate tweaks:heat/b50 run scoreboard players set #band tweaks.heat 50
execute if predicate tweaks:heat/b100 run scoreboard players set #band tweaks.heat 100
scoreboard players operation #gross tweaks.heat = #band tweaks.heat
scoreboard players operation #gross tweaks.heat *= #hseason tweaks.heat
scoreboard players operation #gross tweaks.heat *= #htime tweaks.heat
scoreboard players operation #gross tweaks.heat /= #k100000 tweaks.calc2
