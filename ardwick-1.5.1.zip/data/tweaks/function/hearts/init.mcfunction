# Hearts system: current max hearts, deaths, enchanted golden apples eaten
scoreboard objectives add tweaks.hearts dummy
scoreboard objectives add tweaks.deaths deathCount
scoreboard objectives add tweaks.ega minecraft.used:minecraft.enchanted_golden_apple
scoreboard objectives add tweaks.ga minecraft.used:minecraft.golden_apple
scoreboard objectives add tweaks.floor dummy
scoreboard objectives add tweaks.calc dummy
scoreboard objectives add tweaks.vit dummy
