execute if block ~ ~ ~ minecraft:spawner run return run scoreboard players set #shit tweaks.calc2 1
execute unless block ~ ~ ~ #tweaks:ray_through run return 0
scoreboard players remove #sray tweaks.calc2 1
execute if score #sray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:spawner/ray
