execute unless data storage tweaks:stack work[0] run return 0
data modify storage tweaks:stack e set from storage tweaks:stack work[0]
data modify storage tweaks:stack e.pid set from storage tweaks:stack id
# Plain whole numbers for the template below (a missing strength reads as 0, level I)
execute store result storage tweaks:stack e.amplifier int 1 run data get storage tweaks:stack e.amplifier
execute if data storage tweaks:stack e.duration store result storage tweaks:stack e.duration int 1 run data get storage tweaks:stack e.duration
execute if data storage tweaks:stack e.duration run function tweaks:stack/add with storage tweaks:stack e
data remove storage tweaks:stack work[0]
function tweaks:stack/each
