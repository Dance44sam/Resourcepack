tag @s add tweaks.sf
# No glint on the flying trident: it would draw the hidden model's outline
data modify entity @s item.components."minecraft:enchantment_glint_override" set value 0b
# A spear (not a drowned's trident) counts towards To the Point
execute if data entity @s item.components."minecraft:custom_data".tweaks_spear run function tweaks:spearfly/credit
execute if data entity @s item.components."minecraft:custom_data"{tweaks_spear:"stone"} run playsound minecraft:item.spear_wood.attack player @a ~ ~ ~ 1 0.9
execute if data entity @s item.components."minecraft:custom_data".tweaks_spear unless data entity @s item.components."minecraft:custom_data"{tweaks_spear:"stone"} run playsound minecraft:item.spear.attack player @a ~ ~ ~ 1 0.9
execute unless data entity @s item.components."minecraft:custom_data".tweaks_spear run playsound tweaks:trident_throw player @a ~ ~ ~ 1 1
scoreboard players add #sf_next tweaks.sfid 1
scoreboard players operation @s tweaks.sfid = #sf_next tweaks.sfid
summon minecraft:item_display ~ ~ ~ {Tags:["tweaks.sf_disp","tweaks.sf_new"],item_display:"none",teleport_duration:1}
data modify entity @n[type=minecraft:item_display,tag=tweaks.sf_new] item set from entity @s item
data merge entity @n[type=minecraft:item_display,tag=tweaks.sf_new] {transformation:{left_rotation:[0.6532815f,-0.2705981f,0.2705981f,0.6532815f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.5f],scale:[1f,1f,1f]}}
scoreboard players operation @n[type=minecraft:item_display,tag=tweaks.sf_new] tweaks.sfid = @s tweaks.sfid
tag @e[type=minecraft:item_display,tag=tweaks.sf_new] remove tweaks.sf_new
