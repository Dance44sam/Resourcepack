execute as @e[type=minecraft:ender_pearl,tag=!tweaks.seen] at @s run function tweaks:pearl/check
