# Every five seconds, only animals still waiting
execute as @e[type=#tweaks:breedable,tag=!tweaks.wait_baby] if predicate tweaks:baby run function tweaks:breed/stamp_baby
execute as @e[tag=tweaks.wait_baby] run function tweaks:breed/baby
execute as @e[tag=tweaks.wait_parent] if score #days tweaks.year >= @s tweaks.due run function tweaks:breed/ready
execute as @e[type=minecraft:tadpole,tag=!tweaks.wait_tadpole] run function tweaks:breed/stamp_tadpole
execute as @e[type=minecraft:tadpole,tag=tweaks.wait_tadpole] run function tweaks:breed/tadpole
schedule function tweaks:breed/check 100t replace
