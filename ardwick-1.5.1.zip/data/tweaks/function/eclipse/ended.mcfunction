advancement grant @a[tag=tweaks.eclipse_in] only tweaks:eclipse
tag @a remove tweaks.eclipse_in
tag @a remove tweaks.eclipse_out
