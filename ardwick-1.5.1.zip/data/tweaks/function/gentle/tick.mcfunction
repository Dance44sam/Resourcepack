# Easy is gentle: every hostile or semi-hostile mob (#tweaks:gentle_mobs
execute store result score #diff tweaks.calc2 run difficulty
execute if score #diff tweaks.calc2 matches 1 as @e[type=#tweaks:gentle_mobs,tag=!tweaks.gentle2] run function tweaks:gentle/on
execute unless score #diff tweaks.calc2 matches 1 as @e[type=#tweaks:gentle_mobs,tag=tweaks.gentle2] run function tweaks:gentle/off
execute unless score #diff tweaks.calc2 matches 1 as @e[type=#tweaks:gentle_mobs,tag=tweaks.gentle] run function tweaks:gentle/off
