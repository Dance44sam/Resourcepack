scoreboard players set @s tweaks.sum 0
scoreboard players operation @s tweaks.sum += @s tweaks.b0
scoreboard players operation @s tweaks.sum += @s tweaks.b1
scoreboard players operation @s tweaks.sum += @s tweaks.b2
scoreboard players operation @s tweaks.sum += @s tweaks.b3
scoreboard players operation @s tweaks.sum += @s tweaks.b4
scoreboard players operation @s tweaks.sum += @s tweaks.b5
scoreboard players operation @s tweaks.sum += @s tweaks.b6
scoreboard players operation @s tweaks.sum += @s tweaks.b7
scoreboard players operation @s tweaks.sum += @s tweaks.b8
scoreboard players operation @s tweaks.sum += @s tweaks.b9
scoreboard players operation @s tweaks.sum += @s tweaks.b10
scoreboard players operation @s tweaks.sum += @s tweaks.b11
