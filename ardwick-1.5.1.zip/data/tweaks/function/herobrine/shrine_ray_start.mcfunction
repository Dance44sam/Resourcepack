scoreboard players set #ray tweaks.calc2 60
function tweaks:herobrine/shrine_ray
