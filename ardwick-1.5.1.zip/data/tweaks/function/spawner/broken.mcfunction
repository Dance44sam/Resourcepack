# This spawner is gone: a ghast tear where it stood, if it was one that earns one
execute if entity @s[tag=tweaks.spawner_tear] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:ghast_tear",count:1}}
kill @s
