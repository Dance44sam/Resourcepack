# In tenths: 20 a second at the edge of hot (gross = drift, 60), plus 2 for each tenth
scoreboard players operation #dr tweaks.calc2 = #hdrift tweaks.heat
scoreboard players operation #dr tweaks.calc2 -= #gross tweaks.heat
scoreboard players operation #dr tweaks.calc2 *= #two tweaks.cold
scoreboard players add #dr tweaks.calc2 20
execute if score #dr tweaks.calc2 matches 141.. run scoreboard players set #dr tweaks.calc2 140
scoreboard players operation @s tweaks.heat -= #dr tweaks.calc2
