# L*L + 6L
scoreboard players operation @s tweaks.calc3 = @s tweaks.xplv
scoreboard players operation @s tweaks.calc3 *= #6 tweaks.const
scoreboard players operation @s tweaks.calc2 += @s tweaks.calc3
