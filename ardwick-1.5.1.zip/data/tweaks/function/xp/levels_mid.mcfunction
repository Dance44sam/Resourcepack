# (5L*L - 81L + 720) / 2
scoreboard players operation @s tweaks.calc2 *= #5 tweaks.const
scoreboard players operation @s tweaks.calc3 = @s tweaks.xplv
scoreboard players operation @s tweaks.calc3 *= #81 tweaks.const
scoreboard players operation @s tweaks.calc2 -= @s tweaks.calc3
scoreboard players operation @s tweaks.calc2 += #720 tweaks.const
scoreboard players operation @s tweaks.calc2 /= #2 tweaks.const
