scoreboard objectives add tweaks.xp dummy
scoreboard objectives add tweaks.xplv dummy
scoreboard objectives add tweaks.calc2 dummy
scoreboard objectives add tweaks.calc3 dummy
scoreboard objectives add tweaks.const dummy
scoreboard players set #2 tweaks.const 2
scoreboard players set #5 tweaks.const 5
scoreboard players set #6 tweaks.const 6
scoreboard players set #9 tweaks.const 9
scoreboard players set #20 tweaks.const 20
scoreboard players set #81 tweaks.const 81
scoreboard players set #325 tweaks.const 325
scoreboard players set #720 tweaks.const 720
scoreboard players set #4440 tweaks.const 4440
