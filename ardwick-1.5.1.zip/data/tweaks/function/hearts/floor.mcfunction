# Everyone starts able to fall no further than 8 hearts
execute unless score @s tweaks.floor matches -2147483648..2147483647 run scoreboard players set @s tweaks.floor 8
