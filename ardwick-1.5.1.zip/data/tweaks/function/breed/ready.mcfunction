data modify entity @s Age set value 0
tag @s remove tweaks.wait_parent
scoreboard players reset @s tweaks.due
