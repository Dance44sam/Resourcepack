# Base max health = 2 HP per heart (the game only sends an update when the value actually
execute if score @s tweaks.hearts matches 10.. run attribute @s minecraft:max_health base set 20
execute if score @s tweaks.hearts matches 9 run attribute @s minecraft:max_health base set 18
execute if score @s tweaks.hearts matches 8 run attribute @s minecraft:max_health base set 16
execute if score @s tweaks.hearts matches 7 run attribute @s minecraft:max_health base set 14
execute if score @s tweaks.hearts matches 6 run attribute @s minecraft:max_health base set 12
execute if score @s tweaks.hearts matches 5 run attribute @s minecraft:max_health base set 10
execute if score @s tweaks.hearts matches 4 run attribute @s minecraft:max_health base set 8
execute if score @s tweaks.hearts matches 3 run attribute @s minecraft:max_health base set 6
execute if score @s tweaks.hearts matches 2 run attribute @s minecraft:max_health base set 4
execute if score @s tweaks.hearts matches ..1 run attribute @s minecraft:max_health base set 2
