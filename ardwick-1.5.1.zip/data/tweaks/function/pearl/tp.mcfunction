$execute in $(dim) positioned $(x).0 $(y).0 $(z).0 run tp @s ~0.5 ~ ~0.5
