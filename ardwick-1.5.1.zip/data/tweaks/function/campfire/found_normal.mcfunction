# Here, at the campfire: start its burn if it has none, then warm the player as before
function tweaks:campfire/burn_mark
execute at @s run function tweaks:campfire/apply_normal
