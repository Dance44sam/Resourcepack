# One pass over dropped items near players (a 48-block square, 3x3 chunks, around each)
execute as @a at @s positioned ~-24 ~-32 ~-24 run tag @e[type=minecraft:item,dx=48,dy=64,dz=48] add tweaks.near
execute as @e[type=minecraft:item,tag=tweaks.near] at @s run function tweaks:items/check
tag @e[type=minecraft:item,tag=tweaks.near,tag=!tweaks.seen] add tweaks.seen
tag @e[type=minecraft:item,tag=tweaks.near] remove tweaks.near
