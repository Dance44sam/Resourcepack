# Look down for open space to stand in, with ground beneath
execute if block ~ ~ ~ #tweaks:spawn_air if block ~ ~1 ~ #tweaks:spawn_air unless block ~ ~-1 ~ #tweaks:ray_through run return run function tweaks:herobrine/place
scoreboard players remove #hbcol tweaks.calc2 1
execute if score #hbcol tweaks.calc2 matches 1.. positioned ~ ~-1 ~ run function tweaks:herobrine/column
