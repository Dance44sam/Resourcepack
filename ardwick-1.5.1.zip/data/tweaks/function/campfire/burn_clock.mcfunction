scoreboard players set #burnclock tweaks.timer 0
function tweaks:campfire/burn_tick
