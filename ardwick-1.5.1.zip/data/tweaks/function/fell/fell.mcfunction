# The first log is down: take the rest of the trunk with it
scoreboard players set #count tweaks.calc2 0
scoreboard players set #natural tweaks.calc2 1
function tweaks:fell/visit
execute at @e[type=minecraft:marker,tag=tweaks.fell] run setblock ~ ~ ~ minecraft:air destroy
scoreboard players set #leaves tweaks.calc2 0
function tweaks:fell/leaf_seed
execute at @e[type=minecraft:marker,tag=tweaks.fell] run function tweaks:fell/leaf_seed
kill @e[type=minecraft:marker,tag=tweaks.fell]
playsound minecraft:block.wood.break block @a ~ ~ ~ 1.0 0.7
function tweaks:fell/wear
function tweaks:fell/forget
