execute if entity @s[nbt={IsBaby:1b}] run summon minecraft:husk ~ ~ ~ {IsBaby:1b,Tags:["tweaks.mig"]}
execute unless entity @s[nbt={IsBaby:1b}] run summon minecraft:husk ~ ~ ~ {Tags:["tweaks.mig"]}
function tweaks:migrate/vanish
