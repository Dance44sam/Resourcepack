scoreboard players set #campfire tweaks.timer 0
tag @a remove tweaks.warmed
tag @a remove tweaks.soulcamp
# Soul campfires belong to the Nether, ordinary ones to the Overworld
execute as @a at @s if dimension minecraft:the_nether run function tweaks:campfire/scan_soul
execute as @a[tag=!tweaks.warmed] at @s if dimension minecraft:overworld run function tweaks:campfire/scan_normal
# Allays heal like a campfire: Regeneration I for anyone within 4 blocks
execute as @e[type=minecraft:allay] at @s run effect give @a[distance=..4,gamemode=!spectator] minecraft:regeneration 4 0 true
