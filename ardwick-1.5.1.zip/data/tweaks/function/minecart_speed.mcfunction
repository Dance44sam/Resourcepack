# Kept alone: this gamerule needs the Minecart Improvements experiment, and an unknown
gamerule minecart_max_speed 60
