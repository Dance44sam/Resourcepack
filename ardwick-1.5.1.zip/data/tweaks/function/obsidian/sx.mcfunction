scoreboard players set #sy tweaks.calc2 13
function tweaks:obsidian/sy
scoreboard players remove #sx tweaks.calc2 1
execute if score #sx tweaks.calc2 matches 1.. positioned ~1 ~ ~ run function tweaks:obsidian/sx
