execute as @a at @s if items entity @s armor.chest minecraft:elytra[minecraft:damage~{damage:{min:431}}] run function tweaks:elytra/wear_out
