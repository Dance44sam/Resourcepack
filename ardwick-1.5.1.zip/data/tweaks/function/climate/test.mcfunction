$execute if predicate {type:"minecraft:time_check",clock:"minecraft:overworld",value:{min:$(lo),max:$(m)},period:24000} run return run scoreboard players operation #hi tweaks.calc2 = #mid tweaks.calc2
scoreboard players operation #lo tweaks.calc2 = #mid tweaks.calc2
scoreboard players add #lo tweaks.calc2 1
