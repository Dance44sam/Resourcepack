scoreboard players set #rowbad tweaks.calc2 0
$function tweaks:portal/row_$(ax)_$(w)
