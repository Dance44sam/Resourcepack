# Which block, exactly
summon minecraft:marker ~ ~ ~ {Tags:["tweaks.probe"]}
execute store result score #x tweaks.calc2 run data get entity @e[type=minecraft:marker,tag=tweaks.probe,limit=1] Pos[0]
execute store result score #y tweaks.calc2 run data get entity @e[type=minecraft:marker,tag=tweaks.probe,limit=1] Pos[1]
execute store result score #z tweaks.calc2 run data get entity @e[type=minecraft:marker,tag=tweaks.probe,limit=1] Pos[2]
kill @e[type=minecraft:marker,tag=tweaks.probe]
execute if score #x tweaks.calc2 = @s tweaks.fell_x if score #y tweaks.calc2 = @s tweaks.fell_y if score #z tweaks.calc2 = @s tweaks.fell_z run return 0
scoreboard players operation @s tweaks.fell_x = #x tweaks.calc2
scoreboard players operation @s tweaks.fell_y = #y tweaks.calc2
scoreboard players operation @s tweaks.fell_z = #z tweaks.calc2
execute positioned ~0.5 ~0.5 ~0.5 run function tweaks:fell/measure
function tweaks:fell/apply
