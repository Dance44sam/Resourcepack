scoreboard players remove @a[scores={tweaks.ff=1..}] tweaks.ff 1
execute as @a[scores={tweaks.ff=0}] run function tweaks:feather/off
# While it lasts, faint swirls in the potion's colour drift up around the feet
scoreboard players add #ffclock tweaks.timer 1
execute if score #ffclock tweaks.timer matches 4.. as @a[scores={tweaks.ff=1..}] at @s run particle minecraft:entity_effect{color:[0.922,0.902,0.875,1.0]} ~ ~0.15 ~ 0.25 0.05 0.25 0 1
execute if score #ffclock tweaks.timer matches 4.. run scoreboard players set #ffclock tweaks.timer 0
