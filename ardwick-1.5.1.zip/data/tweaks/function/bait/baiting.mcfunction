# Succeeds while the player holds a baited rod in the main hand and bait in the off hand
execute if items entity @s weapon.mainhand minecraft:fishing_rod[minecraft:custom_data~{tweaks_bait:1b}] if items entity @s weapon.offhand #tweaks:bait run return 1
return fail
