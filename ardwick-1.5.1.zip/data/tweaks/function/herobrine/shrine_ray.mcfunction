# Mark the fire the player just lit, so it can burn out once he has moved
execute if block ~ ~ ~ minecraft:fire if block ~ ~-1 ~ minecraft:netherrack align xyz positioned ~0.5 ~0.5 ~0.5 run return run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.hb_shrine"]}
scoreboard players remove #ray tweaks.calc2 1
execute if score #ray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:herobrine/shrine_ray
