# Bank the new points and clear them: twenty vigour per point
xp set @s 0 levels
xp set @s 0 points
scoreboard players operation @s tweaks.xp *= #20 tweaks.const
scoreboard players operation @s tweaks.vigour += @s tweaks.xp
scoreboard players set @s tweaks.hold 100
