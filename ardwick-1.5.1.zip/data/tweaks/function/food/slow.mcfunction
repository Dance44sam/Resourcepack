# Food applies a one-tick unluck effect whose length is its slowness. Add that to any
scoreboard players set #d tweaks.calc2 0
execute store result score #d tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:unluck"}].duration
effect clear @s minecraft:unluck
scoreboard players set #r tweaks.calc2 0
execute if data entity @s active_effects[{id:"minecraft:slowness"}] unless data entity @s active_effects[{id:"minecraft:slowness"}].amplifier store result score #r tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:slowness"}].duration
execute if data entity @s active_effects[{id:"minecraft:slowness",amplifier:0b}] store result score #r tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:slowness",amplifier:0b}].duration
scoreboard players operation #r tweaks.calc2 += #d tweaks.calc2
scoreboard players add #r tweaks.calc2 19
scoreboard players operation #r tweaks.calc2 /= #k20 tweaks.const
execute store result storage tweaks:food s int 1 run scoreboard players get #r tweaks.calc2
function tweaks:food/give_slow with storage tweaks:food
