tag @s add tweaks.seen
execute if data entity @s Item.components."minecraft:custom_data".returning run function tweaks:pearl/fire
