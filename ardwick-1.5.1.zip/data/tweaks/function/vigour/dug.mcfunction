# Pickaxe wear costs 2.5 vigour a point: half points carry over so none are lost
scoreboard players operation #d tweaks.calc2 *= #5 tweaks.const
scoreboard players operation @s tweaks.vhalf += #d tweaks.calc2
scoreboard players operation #h tweaks.calc2 = @s tweaks.vhalf
scoreboard players operation #h tweaks.calc2 /= #k2 tweaks.const
scoreboard players operation @s tweaks.vigour -= #h tweaks.calc2
scoreboard players operation @s tweaks.vhalf %= #k2 tweaks.const
scoreboard players set @s tweaks.hold 100
