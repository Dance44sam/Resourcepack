# Each tick of eating or drinking: note what is in hand and what effects are running
advancement revoke @s only tweaks:stack/using
execute unless score @s tweaks.pid matches 1.. run function tweaks:stack/id
execute store result storage tweaks:stack id int 1 run scoreboard players get @s tweaks.pid
function tweaks:stack/snap with storage tweaks:stack
