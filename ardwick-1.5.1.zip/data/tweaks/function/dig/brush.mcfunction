# A player has started brushing a suspicious block
advancement revoke @s only tweaks:dig/brush
scoreboard players set #rp tweaks.calc2 110
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:dig/ray
