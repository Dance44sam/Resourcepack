weather clear 600s
scoreboard players set #wtimer tweaks.year 600
