# Each time someone walks into an ancient city, Herobrine is due at once
advancement revoke @s only tweaks:herobrine/city
execute if entity @s[tag=tweaks.in_city] run return 0
tag @s add tweaks.in_city
scoreboard players set #hbdue tweaks.year 1
