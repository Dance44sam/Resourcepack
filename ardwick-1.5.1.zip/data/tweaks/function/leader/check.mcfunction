# Zombie leaders (vanilla's 2-5x health bonus) grow so their volume matches their health: scale (health / 20)^(1/3)
tag @s add tweaks.lead_seen
execute store result score #lh tweaks.calc2 run attribute @s minecraft:max_health get 1
execute if score #lh tweaks.calc2 matches 21.. run function tweaks:leader/grow
