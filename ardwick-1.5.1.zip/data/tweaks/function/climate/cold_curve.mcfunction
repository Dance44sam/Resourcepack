scoreboard players operation #x tweaks.calc2 = #ts tweaks.calc2
scoreboard players remove #x tweaks.calc2 18000
scoreboard players operation #x tweaks.calc2 *= #x tweaks.calc2
scoreboard players operation #x tweaks.calc2 /= #k163636 tweaks.calc2
scoreboard players set #ctime tweaks.cold 320
scoreboard players operation #ctime tweaks.cold -= #x tweaks.calc2
execute if score #ctime tweaks.cold matches ..99 run scoreboard players set #ctime tweaks.cold 100
