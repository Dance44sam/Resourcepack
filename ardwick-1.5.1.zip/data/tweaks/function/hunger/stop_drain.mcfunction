tag @s remove tweaks.draining
effect clear @s minecraft:hunger
