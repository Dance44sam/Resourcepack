# A joining player is shown the season rather than told it
scoreboard players operation @s tweaks.online = @s tweaks.leaves
execute at @s run function tweaks:clock/note
scoreboard players set @s tweaks.burst 40
