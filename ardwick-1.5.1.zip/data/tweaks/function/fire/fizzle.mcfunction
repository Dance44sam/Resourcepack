# Taking out one portal block collapses the whole portal
fill ~-1 ~-1 ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:nether_portal
particle minecraft:smoke ~ ~ ~ 0.3 0.4 0.3 0.02 20
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 0.8 1.2
