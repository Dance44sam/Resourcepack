# Held-back stack
$execute store result score #ovn tweaks.calc2 run data get storage tweaks:oversize pend.s$(slot)
$data remove storage tweaks:oversize pend.s$(slot)
$execute store result score #ovl tweaks.calc2 run data get entity @s Inventory[{Slot:$(slot)b}].components."minecraft:max_stack_size"
execute if score #ovl tweaks.calc2 matches ..0 run scoreboard players operation #ovl tweaks.calc2 = #ovn tweaks.calc2
scoreboard players operation #ovk tweaks.calc2 = #ovn tweaks.calc2
scoreboard players operation #ovk tweaks.calc2 < #ovl tweaks.calc2
scoreboard players operation #ove tweaks.calc2 = #ovn tweaks.calc2
scoreboard players operation #ove tweaks.calc2 -= #ovk tweaks.calc2
$data modify storage tweaks:oversize drop set from entity @s Inventory[{Slot:$(slot)b}]
execute store result storage tweaks:oversize k int 1 run scoreboard players get #ovk tweaks.calc2
$item modify entity @s container.$(slot) tweaks:oversize/set_k
execute if score #ove tweaks.calc2 matches 1.. run function tweaks:oversize/drop
