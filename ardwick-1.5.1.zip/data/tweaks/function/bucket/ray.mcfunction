execute if block ~ ~ ~ minecraft:lava[level=0] align xyz positioned ~0.5 ~0.5 ~0.5 run return run function tweaks:bucket/mark {t:"lava"}
execute if block ~ ~ ~ minecraft:lava_cauldron align xyz positioned ~0.5 ~0.5 ~0.5 run return run function tweaks:bucket/mark {t:"cauldron"}
execute if block ~ ~ ~ minecraft:water[level=0] run return 0
execute unless block ~ ~ ~ #tweaks:bucket_through run return 0
scoreboard players remove #bkt tweaks.calc2 1
execute if score #bkt tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:bucket/ray
