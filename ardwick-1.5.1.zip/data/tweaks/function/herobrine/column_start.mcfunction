scoreboard players set #hbcol tweaks.calc2 48
function tweaks:herobrine/column
