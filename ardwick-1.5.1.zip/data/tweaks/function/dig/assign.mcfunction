execute if data block ~ ~ ~ LootTable run return 0
execute if data block ~ ~ ~ item run return 0
# Which table: desert sand, river gravel or sand (with panned silver and gold), else gravel or sand by the block
execute if biome ~ ~ ~ minecraft:desert run return run data modify block ~ ~ ~ LootTable set value "tweaks:archaeology/desert"
execute if biome ~ ~ ~ #minecraft:is_river if block ~ ~ ~ minecraft:suspicious_gravel run return run data modify block ~ ~ ~ LootTable set value "tweaks:archaeology/river_gravel"
execute if biome ~ ~ ~ #minecraft:is_river run return run data modify block ~ ~ ~ LootTable set value "tweaks:archaeology/river_sand"
execute if block ~ ~ ~ minecraft:suspicious_gravel run return run data modify block ~ ~ ~ LootTable set value "tweaks:archaeology/gravel"
data modify block ~ ~ ~ LootTable set value "tweaks:archaeology/sand"
