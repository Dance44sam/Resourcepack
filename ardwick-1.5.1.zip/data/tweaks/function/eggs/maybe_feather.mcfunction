tag @s add tweaks.egg_checked
execute if predicate tweaks:coin_flip run item replace entity @s contents with minecraft:feather 1
tag @s remove tweaks.conv
