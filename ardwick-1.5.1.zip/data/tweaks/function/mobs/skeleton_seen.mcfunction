tag @s add tweaks.seen
# Only while the new moon is in the sky: half during the eclipse's pass, a quarter otherwise
execute if dimension minecraft:overworld if predicate tweaks:is_eclipse if predicate tweaks:coin_flip run function tweaks:mobs/to_wither
execute if dimension minecraft:overworld unless predicate tweaks:is_eclipse if predicate tweaks:is_new_moon if predicate tweaks:is_moon_up if predicate tweaks:one_in_four run function tweaks:mobs/to_wither
