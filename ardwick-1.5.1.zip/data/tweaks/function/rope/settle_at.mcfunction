# Far fence not loaded yet
$execute unless loaded $(x) $(y) $(z) run return 0
$execute unless block $(x) $(y) $(z) #minecraft:fences run return run function tweaks:rope/give_back
$data modify entity @s leash set value [I;$(x),$(y),$(z)]
tag @s remove tweaks.rope_owed
