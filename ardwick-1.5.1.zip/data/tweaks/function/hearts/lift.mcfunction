scoreboard players operation @s tweaks.hearts = @s tweaks.floor
function tweaks:hearts/apply
