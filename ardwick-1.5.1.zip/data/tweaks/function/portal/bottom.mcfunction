# Height of the opening, up to the obsidian above (at most 21)
scoreboard players set #ph tweaks.calc2 0
function tweaks:portal/measure_up
execute unless score #ph tweaks.calc2 matches 1..21 run return 0
execute store result storage tweaks:portal h int 1 run scoreboard players get #ph tweaks.calc2
execute if function tweaks:portal/try_x run return 1
function tweaks:portal/try_z
