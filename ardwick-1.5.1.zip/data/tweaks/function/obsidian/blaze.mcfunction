# Only where a blaze has room to rise without suffocating
execute unless block ~ ~1 ~ #tweaks:ray_through run return 0
execute unless block ~ ~2 ~ #tweaks:ray_through run return 0
summon minecraft:blaze ~ ~1 ~
particle minecraft:flame ~ ~1 ~ 0.3 0.4 0.3 0.05 30
particle minecraft:large_smoke ~ ~1 ~ 0.3 0.4 0.3 0.02 15
playsound minecraft:entity.blaze.shoot hostile @a ~ ~ ~ 1 0.8
