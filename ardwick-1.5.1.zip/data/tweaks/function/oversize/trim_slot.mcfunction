$item modify entity @s container.$(slot) tweaks:oversize/set_k
