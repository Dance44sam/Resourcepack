# Half as much health again, since a spider can't wear armour
attribute @s minecraft:max_health base set 24
data modify entity @s Health set value 24f
execute store result score #fx tweaks.calc2 run random value 1..8
execute if score #fx tweaks.calc2 matches 1 run effect give @s minecraft:speed infinite 0
execute if score #fx tweaks.calc2 matches 2 run effect give @s minecraft:strength infinite 0
execute if score #fx tweaks.calc2 matches 3 run effect give @s minecraft:regeneration infinite 0
execute if score #fx tweaks.calc2 matches 4 run effect give @s minecraft:resistance infinite 0
execute if score #fx tweaks.calc2 matches 5 run effect give @s minecraft:jump_boost infinite 1
execute if score #fx tweaks.calc2 matches 6 run effect give @s minecraft:invisibility infinite 0
execute if score #fx tweaks.calc2 matches 7 run effect give @s minecraft:weakness infinite 0
execute if score #fx tweaks.calc2 matches 8 run effect give @s minecraft:slowness infinite 0
