# A leaf 6 from the felled trunk, along its own branch
execute if score #leaves tweaks.calc2 matches 2000.. run return 0
setblock ~ ~ ~ minecraft:air destroy
scoreboard players add #leaves tweaks.calc2 1
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~-1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~ ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~ ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~-1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~ ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~ ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~1 ~ if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] run function tweaks:fell/leaf7
