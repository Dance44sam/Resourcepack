# Drops that appeared since last tick, lying where a crop just stood
$execute as @e[type=minecraft:item,tag=!tweaks.seen,distance=..8] if items entity @s contents $(seed) at @s align xyz if block ~ ~ ~ #tweaks:crop_room if block ~ ~-1 ~ $(ground) run function tweaks:crops/replant {crop:"$(crop)"}
