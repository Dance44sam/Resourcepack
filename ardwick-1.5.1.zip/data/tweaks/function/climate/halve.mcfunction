# Binary search on the clock: is the time in the lower half of #lo..#hi?
scoreboard players operation #mid tweaks.calc2 = #lo tweaks.calc2
scoreboard players operation #mid tweaks.calc2 += #hi tweaks.calc2
scoreboard players operation #mid tweaks.calc2 /= #two tweaks.cold
execute store result storage tweaks:climate q.lo int 1 run scoreboard players get #lo tweaks.calc2
execute store result storage tweaks:climate q.m int 1 run scoreboard players get #mid tweaks.calc2
function tweaks:climate/test with storage tweaks:climate q
scoreboard players operation #span tweaks.calc2 = #hi tweaks.calc2
scoreboard players operation #span tweaks.calc2 -= #lo tweaks.calc2
scoreboard players add #iter tweaks.calc2 1
execute if score #span tweaks.calc2 matches 24.. if score #iter tweaks.calc2 matches ..11 run function tweaks:climate/halve
