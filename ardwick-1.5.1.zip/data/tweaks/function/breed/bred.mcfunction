advancement revoke @s only tweaks:breed/bred
# The game announces a breeding before it sets the parents' cooldown or adds the baby
tag @s add tweaks.bred
schedule function tweaks:breed/apply 2t
