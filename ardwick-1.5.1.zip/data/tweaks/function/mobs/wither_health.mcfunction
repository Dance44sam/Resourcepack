# A wither skeleton is 80 health, however it came to be here
execute as @e[type=minecraft:wither_skeleton,tag=!tweaks.hp2] run function tweaks:mobs/harden
execute as @e[type=minecraft:blaze,tag=!tweaks.hp2] run function tweaks:mobs/harden_blaze
execute as @e[type=minecraft:ghast,tag=!tweaks.hp2] run function tweaks:mobs/harden_ghast
