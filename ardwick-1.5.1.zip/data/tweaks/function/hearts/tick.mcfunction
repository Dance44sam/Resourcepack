# New players start with the full 10 hearts
execute as @a unless score @s tweaks.hearts matches 1.. unless score #wsx tweaks.spx matches -2147483648..2147483647 at @s run function tweaks:bed/note_world
execute as @a unless score @s tweaks.hearts matches 1.. run scoreboard players set @s tweaks.hearts 10
execute as @a[scores={tweaks.deaths=1..}] run function tweaks:hearts/on_death
execute as @a[scores={tweaks.ega=1..}] run function tweaks:hearts/on_apple
execute as @a[scores={tweaks.ga=1..}] run function tweaks:hearts/on_apple
execute as @a run function tweaks:hearts/apply
execute as @a run function tweaks:hearts/floor
scoreboard players add #hclock tweaks.timer 1
execute if score #hclock tweaks.timer matches 20.. as @a run function tweaks:hearts/recount
execute if score #hclock tweaks.timer matches 20.. run function tweaks:herobrine/city_left
execute if score #hclock tweaks.timer matches 20.. run scoreboard players set #hclock tweaks.timer 0
