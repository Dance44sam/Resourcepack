# A mob that hurts a player never despawns (as if name-tagged), so the one that killed you
advancement revoke @s only tweaks:persist/hurt
execute on attacker if entity @s[type=!minecraft:player] run data merge entity @s {PersistenceRequired:1b}
