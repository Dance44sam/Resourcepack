# Monsters below sea level in the Overworld are stronger the deeper they spawn
execute as @e[type=#tweaks:depth_mobs,tag=!tweaks.depth] at @s run function tweaks:depth/apply
