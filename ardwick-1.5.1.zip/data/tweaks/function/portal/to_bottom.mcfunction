execute if block ~ ~-1 ~ minecraft:obsidian run return run function tweaks:portal/bottom
execute unless block ~ ~-1 ~ #tweaks:portal_space run return 0
scoreboard players remove #pn tweaks.calc2 1
execute if score #pn tweaks.calc2 matches 1.. positioned ~ ~-1 ~ run function tweaks:portal/to_bottom
