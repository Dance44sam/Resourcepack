# Each player gets a number, so several people eating or drinking at once keep separate
scoreboard players add #next tweaks.pid 1
scoreboard players operation @s tweaks.pid = #next tweaks.pid
