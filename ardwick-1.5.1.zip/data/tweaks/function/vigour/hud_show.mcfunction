scoreboard players set @s tweaks.hud_t 20
# The fill runs outward from the notch
scoreboard players operation #in tweaks.calc2 = #f tweaks.calc2
execute if score #in tweaks.calc2 > #k176 tweaks.const run scoreboard players set #in tweaks.calc2 176
scoreboard players operation #out tweaks.calc2 = #f tweaks.calc2
scoreboard players operation #out tweaks.calc2 -= #in tweaks.calc2
data modify storage tweaks:hud i set value {lo:0,li:0,ri:0,ro:0,flo:0,fli:0,fri:0,fro:0,p:"f"}
execute if score @s tweaks.fside matches 1 run data modify storage tweaks:hud i.p set value "h"
execute if score #s tweaks.calc2 matches ..-1 store result storage tweaks:hud i.li int 1 run scoreboard players get #in tweaks.calc2
execute if score #s tweaks.calc2 matches ..-1 store result storage tweaks:hud i.lo int 1 run scoreboard players get #out tweaks.calc2
execute if score #s tweaks.calc2 matches 1.. store result storage tweaks:hud i.ri int 1 run scoreboard players get #in tweaks.calc2
execute if score #s tweaks.calc2 matches 1.. store result storage tweaks:hud i.ro int 1 run scoreboard players get #out tweaks.calc2
scoreboard players operation #a tweaks.calc2 = #fr tweaks.calc2
execute if score #a tweaks.calc2 > #k180 tweaks.const run scoreboard players set #a tweaks.calc2 180
scoreboard players operation #b tweaks.calc2 = #fr tweaks.calc2
scoreboard players operation #b tweaks.calc2 -= #a tweaks.calc2
execute store result storage tweaks:hud i.fro int 1 run scoreboard players get #a tweaks.calc2
execute store result storage tweaks:hud i.fri int 1 run scoreboard players get #b tweaks.calc2
scoreboard players operation #a tweaks.calc2 = #fl tweaks.calc2
execute if score #a tweaks.calc2 > #k176 tweaks.const run scoreboard players set #a tweaks.calc2 176
scoreboard players operation #b tweaks.calc2 = #fl tweaks.calc2
scoreboard players operation #b tweaks.calc2 -= #a tweaks.calc2
execute store result storage tweaks:hud i.fli int 1 run scoreboard players get #a tweaks.calc2
execute store result storage tweaks:hud i.flo int 1 run scoreboard players get #b tweaks.calc2
function tweaks:vigour/hud_pick with storage tweaks:hud i
function tweaks:vigour/hud_send with storage tweaks:hud g
