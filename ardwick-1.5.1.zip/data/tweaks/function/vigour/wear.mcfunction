execute unless predicate tweaks:digging_tool run return run function tweaks:vigour/wear_reset
# The damage on the held tool, and which slot it came from. -1 means nothing to read.
scoreboard players set @s tweaks.dmg -1
scoreboard players set @s tweaks.slot -1
execute store result score @s tweaks.dmg run data get entity @s SelectedItem.components."minecraft:damage"
execute store result score @s tweaks.slot run data get entity @s SelectedItemSlot
scoreboard players operation #d tweaks.calc2 = @s tweaks.dmg
scoreboard players operation #d tweaks.calc2 -= @s tweaks.dmgprev
execute if predicate tweaks:digging_tool if score @s tweaks.dmg matches 0.. if score @s tweaks.dmgprev matches 0.. if score @s tweaks.slot = @s tweaks.slotprev if score #d tweaks.calc2 matches 1..4 run function tweaks:vigour/dug
scoreboard players operation @s tweaks.dmgprev = @s tweaks.dmg
scoreboard players operation @s tweaks.slotprev = @s tweaks.slot
