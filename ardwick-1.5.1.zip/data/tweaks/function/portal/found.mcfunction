# Down to the bottom of the opening
scoreboard players set #pn tweaks.calc2 22
function tweaks:portal/to_bottom
