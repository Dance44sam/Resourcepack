# Burnt down: the same campfire, facing the same way, now unlit
execute if block ~ ~ ~ minecraft:campfire[facing=north,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=north,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=north,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=north,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=south,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=south,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=south,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=south,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=east,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=east,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=east,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=east,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=west,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=west,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:campfire[facing=west,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:campfire[facing=west,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=north,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=north,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=north,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=north,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=south,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=south,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=south,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=south,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=east,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=east,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=east,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=east,signal_fire=false,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=west,signal_fire=true,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=west,signal_fire=true,lit=false,waterlogged=false]
execute if block ~ ~ ~ minecraft:soul_campfire[facing=west,signal_fire=false,lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[facing=west,signal_fire=false,lit=false,waterlogged=false]
particle minecraft:smoke ~ ~0.3 ~ 0.25 0.2 0.25 0.01 12
playsound minecraft:block.lava.extinguish block @a ~ ~ ~ 0.6 1.0
kill @s
