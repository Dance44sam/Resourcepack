# A brown or blue egg becomes the same number of ordinary eggs
$execute store result storage tweaks:egg n int 1 if items entity @s $(slot) #tweaks:coloured_eggs
$data modify storage tweaks:egg slot set value "$(slot)"
function tweaks:eggs/swap_n with storage tweaks:egg
