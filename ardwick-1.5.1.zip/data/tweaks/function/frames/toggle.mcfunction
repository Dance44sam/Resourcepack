# Undo what the shears did first. An empty frame took the shears: hand them back.
execute if items entity @s contents minecraft:shears unless items entity @a[tag=tweaks.shearer,limit=1] weapon.mainhand * run function tweaks:frames/give_back
execute unless entity @s[tag=tweaks.gave_back] if data entity @s Item run function tweaks:frames/unrotate
tag @s remove tweaks.gave_back
execute store success score #vis tweaks.calc2 if data entity @s {Invisible:1b}
execute if score #vis tweaks.calc2 matches 1 run data modify entity @s Invisible set value 0b
execute if score #vis tweaks.calc2 matches 0 run data modify entity @s Invisible set value 1b
playsound minecraft:entity.sheep.shear player @a ~ ~ ~ 0.6 1.3
execute as @a[tag=tweaks.shearer,limit=1] run function tweaks:frames/wear
