# Sack weight: 0.4% of base speed per filled slot across every sack carried, at most 40%
scoreboard players set #sh tweaks.calc2 0
execute if items entity @s container.0 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:0b}].components."minecraft:container"
execute if items entity @s container.0 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.1 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:1b}].components."minecraft:container"
execute if items entity @s container.1 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.2 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:2b}].components."minecraft:container"
execute if items entity @s container.2 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.3 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:3b}].components."minecraft:container"
execute if items entity @s container.3 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.4 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:4b}].components."minecraft:container"
execute if items entity @s container.4 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.5 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:5b}].components."minecraft:container"
execute if items entity @s container.5 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.6 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:6b}].components."minecraft:container"
execute if items entity @s container.6 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.7 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:7b}].components."minecraft:container"
execute if items entity @s container.7 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.8 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:8b}].components."minecraft:container"
execute if items entity @s container.8 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.9 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:9b}].components."minecraft:container"
execute if items entity @s container.9 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.10 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:10b}].components."minecraft:container"
execute if items entity @s container.10 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.11 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:11b}].components."minecraft:container"
execute if items entity @s container.11 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.12 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:12b}].components."minecraft:container"
execute if items entity @s container.12 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.13 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:13b}].components."minecraft:container"
execute if items entity @s container.13 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.14 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:14b}].components."minecraft:container"
execute if items entity @s container.14 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.15 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:15b}].components."minecraft:container"
execute if items entity @s container.15 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.16 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:16b}].components."minecraft:container"
execute if items entity @s container.16 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.17 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:17b}].components."minecraft:container"
execute if items entity @s container.17 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.18 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:18b}].components."minecraft:container"
execute if items entity @s container.18 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.19 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:19b}].components."minecraft:container"
execute if items entity @s container.19 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.20 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:20b}].components."minecraft:container"
execute if items entity @s container.20 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.21 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:21b}].components."minecraft:container"
execute if items entity @s container.21 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.22 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:22b}].components."minecraft:container"
execute if items entity @s container.22 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.23 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:23b}].components."minecraft:container"
execute if items entity @s container.23 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.24 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:24b}].components."minecraft:container"
execute if items entity @s container.24 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.25 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:25b}].components."minecraft:container"
execute if items entity @s container.25 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.26 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:26b}].components."minecraft:container"
execute if items entity @s container.26 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.27 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:27b}].components."minecraft:container"
execute if items entity @s container.27 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.28 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:28b}].components."minecraft:container"
execute if items entity @s container.28 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.29 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:29b}].components."minecraft:container"
execute if items entity @s container.29 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.30 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:30b}].components."minecraft:container"
execute if items entity @s container.30 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.31 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:31b}].components."minecraft:container"
execute if items entity @s container.31 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.32 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:32b}].components."minecraft:container"
execute if items entity @s container.32 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.33 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:33b}].components."minecraft:container"
execute if items entity @s container.33 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.34 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:34b}].components."minecraft:container"
execute if items entity @s container.34 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s container.35 #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s Inventory[{Slot:35b}].components."minecraft:container"
execute if items entity @s container.35 #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if items entity @s weapon.offhand #minecraft:shulker_boxes store result score #n tweaks.calc2 run data get entity @s equipment.offhand.components."minecraft:container"
execute if items entity @s weapon.offhand #minecraft:shulker_boxes run scoreboard players operation #sh tweaks.calc2 += #n tweaks.calc2
execute if score #sh tweaks.calc2 matches 101.. run scoreboard players set #sh tweaks.calc2 100
function tweaks:shulker/clear
execute if score #sh tweaks.calc2 matches 1.. run function tweaks:shulker/apply
