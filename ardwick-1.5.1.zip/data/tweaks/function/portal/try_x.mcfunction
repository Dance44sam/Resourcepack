# One wide: obsidian on both sides here. Two wide: open on one side, obsidian beyond it.
execute if block ~-1 ~ ~ minecraft:obsidian if block ~1 ~ ~ minecraft:obsidian run return run function tweaks:portal/check {ax:"x",w:1,off:0}
execute if block ~-1 ~ ~ minecraft:obsidian if block ~1 ~ ~ #tweaks:portal_space if block ~2 ~ ~ minecraft:obsidian run return run function tweaks:portal/check {ax:"x",w:2,off:0}
execute if block ~1 ~ ~ minecraft:obsidian if block ~-1 ~ ~ #tweaks:portal_space if block ~-2 ~ ~ minecraft:obsidian positioned ~-1 ~ ~ run return run function tweaks:portal/check {ax:"x",w:2,off:0}
return fail
