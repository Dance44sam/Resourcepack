# Full health costs nothing; every point of health missing is 1% slower
execute store result score @s tweaks.calc run data get entity @s Health 1
scoreboard players set @s tweaks.vit 20
scoreboard players operation @s tweaks.vit -= @s tweaks.calc
execute store result storage tweaks:vitality amount double -0.01 run scoreboard players get @s tweaks.vit
attribute @s minecraft:movement_speed modifier remove tweaks:vitality
function tweaks:combat/vitality_apply with storage tweaks:vitality
scoreboard players operation @s tweaks.hp_prev = @s tweaks.hp
