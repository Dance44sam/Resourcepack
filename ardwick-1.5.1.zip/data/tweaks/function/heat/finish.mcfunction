# Wet, the heat bites half as hard
execute if score @s tweaks.wet matches 1.. run scoreboard players operation #gain tweaks.heat /= #two tweaks.cold
function tweaks:heat/clothing
scoreboard players operation #gain tweaks.heat -= #hdrift tweaks.heat
scoreboard players operation @s tweaks.hrem += #gain tweaks.heat
scoreboard players operation #q tweaks.calc2 = @s tweaks.hrem
scoreboard players operation #q tweaks.calc2 /= #k10 tweaks.calc2
scoreboard players operation @s tweaks.heat += #q tweaks.calc2
scoreboard players operation @s tweaks.hrem %= #k10 tweaks.calc2
