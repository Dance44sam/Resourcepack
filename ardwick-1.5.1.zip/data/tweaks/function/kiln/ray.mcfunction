execute if block ~ ~ ~ minecraft:furnace align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.kiln,distance=..0.5] run return run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.kiln"]}
execute if block ~ ~ ~ minecraft:furnace run return 0
scoreboard players remove #kray tweaks.calc2 1
execute if score #kray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:kiln/ray
