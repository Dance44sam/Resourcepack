function tweaks:herobrine/clear_light
tp @e[tag=tweaks.hb] ~ -10000 ~
tp @e[tag=tweaks.hb_eye] ~ -10000 ~
kill @e[tag=tweaks.hb]
kill @e[tag=tweaks.hb_eye]
tag @a remove tweaks.hb_target
kill @e[type=minecraft:marker,tag=tweaks.hb_shrine]
