# Once a second: a tracked brewing stand checks the potions sitting in it, so brewing earns
execute unless block ~ ~ ~ minecraft:brewing_stand run return run kill @s
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:awkward"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/awkward brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_ff:1b}}}] run advancement grant @a[distance=..8] only tweaks:brewing/feather_falling brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:swiftness"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/swiftness brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:long_swiftness"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/swiftness brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:strong_swiftness"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/swiftness brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_brew:"haste"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/haste brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_brew:"haste_ii_long"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/haste brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:strong_swiftness"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/glowstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:strong_strength"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/glowstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:strong_leaping"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/glowstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:potion_contents":{potion:"minecraft:strong_regeneration"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/glowstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_brew:"ii_long"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/glowstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_brew:"ii_long"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/redstone brewed
execute if data block ~ ~ ~ Items[{components:{"minecraft:custom_data":{tweaks_brew:"haste_ii_long"}}}] run advancement grant @a[distance=..8] only tweaks:brewing/redstone brewed
execute if data block ~ ~ ~ Items[{id:"minecraft:experience_bottle"}] run advancement grant @a[distance=..8] only tweaks:brewing/bottle_o_vigour brewed
execute if data block ~ ~ ~ Items[{id:"minecraft:dragon_breath"}] run advancement grant @a[distance=..8] only tweaks:brewing/dragons_breath brewed
