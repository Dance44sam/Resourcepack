data modify entity @s Item.id set value "minecraft:prismarine_shard"
particle minecraft:bubble ~ ~0.2 ~ 0.2 0.2 0.2 0.05 12
playsound minecraft:block.amethyst_block.chime block @a ~ ~ ~ 0.8 0.7
advancement grant @a[distance=..8] only tweaks:prismarine made
tag @s remove tweaks.conv
