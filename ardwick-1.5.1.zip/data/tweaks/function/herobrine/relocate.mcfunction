execute align xyz positioned ~0.5 ~ ~0.5 run tp @e[type=minecraft:mannequin,tag=tweaks.hb,limit=1] ~ ~ ~
tag @e[type=minecraft:mannequin,tag=tweaks.hb] add tweaks.hb_placed
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:air run setblock ~ ~ ~ minecraft:light[level=4]
