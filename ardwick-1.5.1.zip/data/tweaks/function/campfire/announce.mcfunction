tellraw @s {"text":"You will wake here.","color":"gray","italic":true}
playsound minecraft:block.campfire.crackle player @s ~ ~ ~ 0.6 1.4
scoreboard players operation @s tweaks.sx = @s tweaks.px
scoreboard players operation @s tweaks.sz = @s tweaks.pz
advancement grant @s only tweaks:comfort_of_fire
