# One 16-block cube; an unloaded one simply fails on its own
fill ~ ~ ~ ~15 ~15 ~15 minecraft:sculk_shrieker[can_summon=false,waterlogged=false] replace minecraft:sculk_shrieker[can_summon=true,waterlogged=false]
fill ~ ~ ~ ~15 ~15 ~15 minecraft:sculk_shrieker[can_summon=false,waterlogged=true] replace minecraft:sculk_shrieker[can_summon=true,waterlogged=true]
scoreboard players remove #qy tweaks.calc2 1
execute if score #qy tweaks.calc2 matches 1.. positioned ~ ~16 ~ run function tweaks:warden/qy
