playsound minecraft:block.campfire.crackle player @s ~ ~ ~ 0.7 1.0
