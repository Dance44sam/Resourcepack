execute store result storage tweaks:bed x int 1 run scoreboard players get #wsx tweaks.spx
execute store result storage tweaks:bed y int 1 run scoreboard players get #wsy tweaks.spx
execute store result storage tweaks:bed z int 1 run scoreboard players get #wsz tweaks.spx
data modify storage tweaks:bed dim set value "minecraft:overworld"
function tweaks:bed/set with storage tweaks:bed
