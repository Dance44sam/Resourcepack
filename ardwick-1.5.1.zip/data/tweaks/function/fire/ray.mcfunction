execute if block ~ ~ ~ minecraft:nether_portal run return run function tweaks:fire/fizzle
scoreboard players remove #ray tweaks.calc2 1
execute if score #ray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:fire/ray
