execute if block ~ ~ ~ minecraft:lava[level=0] if score #obn tweaks.calc2 matches ..199 positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.ob_watch,distance=..0.4] run function tweaks:obsidian/watch_here
scoreboard players remove #sz tweaks.calc2 1
execute if score #sz tweaks.calc2 matches 1.. positioned ~ ~ ~1 run function tweaks:obsidian/sz
