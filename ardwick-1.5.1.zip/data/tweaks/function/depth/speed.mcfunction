$attribute @s minecraft:movement_speed modifier add tweaks:depth $(s) add_multiplied_base
