# The pearl never flies: it breaks where it is thrown
particle minecraft:portal ~ ~ ~ 0.3 0.3 0.3 0.2 60
playsound minecraft:item.chorus_fruit.teleport player @a ~ ~ ~ 1 0.7
tag @a remove tweaks.pearl_owner
execute on owner run tag @s add tweaks.pearl_owner
execute unless entity @a[tag=tweaks.pearl_owner] run tag @p[distance=..8] add tweaks.pearl_owner
execute as @a[tag=tweaks.pearl_owner,limit=1] run function tweaks:pearl/send
tag @a remove tweaks.pearl_owner
kill @s
