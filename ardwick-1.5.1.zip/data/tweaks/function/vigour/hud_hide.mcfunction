# Clear the bar once on mounting; the marker makes it redraw the moment the player dismounts
title @s actionbar ""
scoreboard players set @s tweaks.hud_t -1000
