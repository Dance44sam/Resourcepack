# It catches fire on one open face chosen at random (every open face equally likely), then
scoreboard players set #nbo tweaks.calc2 0
execute if block ~ ~1 ~ #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if block ~1 ~ ~ #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if block ~-1 ~ ~ #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if block ~ ~ ~1 #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if block ~ ~ ~-1 #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if block ~ ~-1 ~ #minecraft:air run scoreboard players add #nbo tweaks.calc2 1
execute if score #nbo tweaks.calc2 matches 0 run return 0
scoreboard players remove #nbo tweaks.calc2 1
execute store result storage tweaks:nether_burn max int 1 run scoreboard players get #nbo tweaks.calc2
function tweaks:nether_burn/pick with storage tweaks:nether_burn
