execute if score @s tweaks.spx matches -2147483648..2147483647 run function tweaks:pearl/go
execute unless score @s tweaks.spx matches -2147483648..2147483647 run function tweaks:pearl/refuse
