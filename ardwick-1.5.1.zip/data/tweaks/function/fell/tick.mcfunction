# Tree felling: only with an axe, only in survival or adventure
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function tweaks:fell/player
