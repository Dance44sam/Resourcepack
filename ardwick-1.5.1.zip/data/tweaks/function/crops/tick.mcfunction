# A crop broken with a hoe replants itself from its own drop
execute as @a[scores={tweaks.br_wheat=1..}] at @s if items entity @s weapon.mainhand #minecraft:hoes run function tweaks:crops/broke {seed:"minecraft:wheat_seeds",crop:"minecraft:wheat",ground:"minecraft:farmland"}
execute as @a[scores={tweaks.br_carrots=1..}] at @s if items entity @s weapon.mainhand #minecraft:hoes run function tweaks:crops/broke {seed:"minecraft:carrot",crop:"minecraft:carrots",ground:"minecraft:farmland"}
execute as @a[scores={tweaks.br_potatoes=1..}] at @s if items entity @s weapon.mainhand #minecraft:hoes run function tweaks:crops/broke {seed:"minecraft:potato",crop:"minecraft:potatoes",ground:"minecraft:farmland"}
execute as @a[scores={tweaks.br_beetroots=1..}] at @s if items entity @s weapon.mainhand #minecraft:hoes run function tweaks:crops/broke {seed:"minecraft:beetroot_seeds",crop:"minecraft:beetroots",ground:"minecraft:farmland"}
scoreboard players reset @a tweaks.br_wheat
scoreboard players reset @a tweaks.br_carrots
scoreboard players reset @a tweaks.br_potatoes
scoreboard players reset @a tweaks.br_beetroots
