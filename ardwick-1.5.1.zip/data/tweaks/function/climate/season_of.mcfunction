# Day #d of the year -> cold's season #cv in tenths (300 at midsummer, day 3, rising 50 a
scoreboard players operation #a tweaks.calc2 = #d tweaks.calc2
scoreboard players remove #a tweaks.calc2 3
execute if score #a tweaks.calc2 matches ..-1 run scoreboard players operation #a tweaks.calc2 *= #neg1 tweaks.const
execute if score #a tweaks.calc2 matches 15.. run function tweaks:climate/wrap
scoreboard players operation #cv tweaks.calc2 = #a tweaks.calc2
scoreboard players operation #cv tweaks.calc2 *= #k50 tweaks.calc2
scoreboard players add #cv tweaks.calc2 300
scoreboard players operation #hv tweaks.calc2 = #a tweaks.calc2
scoreboard players operation #hv tweaks.calc2 *= #k100 tweaks.calc2
scoreboard players set #h100 tweaks.calc2 1000
scoreboard players operation #h100 tweaks.calc2 -= #hv tweaks.calc2
scoreboard players operation #hv tweaks.calc2 = #h100 tweaks.calc2
execute if score #hv tweaks.calc2 matches ..-1 run scoreboard players set #hv tweaks.calc2 0
