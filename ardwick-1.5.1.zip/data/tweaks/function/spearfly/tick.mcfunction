# Thrown tridents are invisible (resource pack), so each one is drawn by an item display
execute as @e[type=minecraft:trident,tag=!tweaks.sf] at @s run function tweaks:spearfly/start
tag @e[type=minecraft:item_display,tag=tweaks.sf_disp] remove tweaks.sf_ok
execute as @e[type=minecraft:trident,tag=tweaks.sf] at @s run function tweaks:spearfly/follow
kill @e[type=minecraft:item_display,tag=tweaks.sf_disp,tag=!tweaks.sf_ok]
