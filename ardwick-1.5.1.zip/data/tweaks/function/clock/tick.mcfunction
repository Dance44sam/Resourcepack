tag @a remove tweaks.clock_prev
tag @a[tag=tweaks.clock] add tweaks.clock_prev
tag @a remove tweaks.clock
execute as @a if predicate tweaks:holding_clock run tag @s add tweaks.clock
# One note as the clock is raised
execute as @a[tag=tweaks.clock,tag=!tweaks.clock_prev] at @s run function tweaks:clock/note
scoreboard players remove @a[scores={tweaks.burst=1..}] tweaks.burst 1
tag @a[scores={tweaks.burst=1..}] add tweaks.clock
scoreboard players add #clocktimer tweaks.year 1
execute if score #clocktimer tweaks.year matches 8.. run function tweaks:clock/drift
