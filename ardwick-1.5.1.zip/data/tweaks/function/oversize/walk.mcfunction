# One inventory entry at a time
execute unless data storage tweaks:oversize inv[0] run return 0
execute store result score #ovn tweaks.calc2 run data get storage tweaks:oversize inv[0].count
execute store result score #ovl tweaks.calc2 run data get storage tweaks:oversize inv[0].components."minecraft:max_stack_size"
execute if score #ovl tweaks.calc2 matches 1.. if score #ovn tweaks.calc2 > #ovl tweaks.calc2 run function tweaks:oversize/trim
data remove storage tweaks:oversize inv[0]
function tweaks:oversize/walk
