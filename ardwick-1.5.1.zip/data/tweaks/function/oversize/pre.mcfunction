# Before the converters
execute if items entity @s container.* #tweaks:food[!minecraft:custom_data~{ardwick_food_v16:1b},!minecraft:custom_data~{tweaks_pasty:1b},!minecraft:custom_data~{tweaks_cooked_carrot:1b}] run function tweaks:oversize/hold_slots
execute if items entity @s container.* minecraft:beetroot[minecraft:custom_data~{tweaks_cooked_carrot:1b},!minecraft:custom_data~{ardwick_food_v16:1b}] run function tweaks:oversize/hold_slots
execute if items entity @s container.* #tweaks:stack_16[!minecraft:max_stack_size=16] run function tweaks:oversize/hold_slots
execute if items entity @s container.* #tweaks:stack_1[!minecraft:max_stack_size=1] run function tweaks:oversize/hold_slots
