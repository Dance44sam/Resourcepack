tag @s add tweaks.hp2
attribute @s minecraft:max_health base set 40
data modify entity @s Health set value 40.0f
