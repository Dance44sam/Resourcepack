# There is no command to wake a sleeper, but moving one does it
execute at @s run tp @s ~ ~ ~
execute unless entity @s[tag=tweaks.abed_prev] run tellraw @s {"text":"You aren't tired enough to sleep.","color":"gray","italic":true}
