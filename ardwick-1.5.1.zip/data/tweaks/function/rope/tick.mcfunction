# Knots count their age, so a knot that has only just appeared (an animal tied this moment)
scoreboard players add @e[type=minecraft:leash_knot] tweaks.knot_age 1
scoreboard players add @a[tag=tweaks.rope_busy] tweaks.rope_t 1
tag @a[tag=tweaks.rope_busy,scores={tweaks.rope_t=3..}] remove tweaks.rope_busy
scoreboard players add #rope_lc tweaks.timer 1
execute if score #rope_lc tweaks.timer matches 5.. as @e[type=minecraft:frog,tag=tweaks.rope,tag=!tweaks.rope_owed] unless data entity @s leash at @s run function tweaks:rope/lost
execute if score #rope_lc tweaks.timer matches 5.. run scoreboard players set #rope_lc tweaks.timer 0
execute if score #rope_clock tweaks.timer matches 20.. as @e[type=minecraft:frog,tag=tweaks.rope] at @s run function tweaks:rope/check
scoreboard players add #rope_clock tweaks.timer 1
execute if score #rope_clock tweaks.timer matches 21.. run scoreboard players set #rope_clock tweaks.timer 0
