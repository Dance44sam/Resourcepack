advancement revoke @s only tweaks:frames/shear
# Find the frame under the crosshair
tag @s add tweaks.shearer
scoreboard players set #ray tweaks.calc2 60
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:frames/ray
tag @s remove tweaks.shearer
