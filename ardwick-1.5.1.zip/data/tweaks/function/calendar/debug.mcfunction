# Debug: how long this world has run under Ardwick, by the pack's own calendar (/function
function tweaks:seasons/update
scoreboard players operation #dbg_year tweaks.calc2 = #days tweaks.year
scoreboard players operation #dbg_year tweaks.calc2 /= #28 tweaks.year
scoreboard players add #dbg_year tweaks.calc2 1
scoreboard players operation #dbg_day tweaks.calc2 = #day tweaks.year
scoreboard players add #dbg_day tweaks.calc2 1
tellraw @s ["Days played: ",{"score":{"name":"#days","objective":"tweaks.year"}}]
tellraw @s ["Year ",{"score":{"name":"#dbg_year","objective":"tweaks.calc2"}},", day ",{"score":{"name":"#dbg_day","objective":"tweaks.calc2"}}," of 28"]
execute if score #day tweaks.year matches 0..6 run tellraw @s "Season: summer"
execute if score #day tweaks.year matches 7..13 run tellraw @s "Season: autumn"
execute if score #day tweaks.year matches 14..20 run tellraw @s "Season: winter"
execute if score #day tweaks.year matches 21..27 run tellraw @s "Season: spring"
