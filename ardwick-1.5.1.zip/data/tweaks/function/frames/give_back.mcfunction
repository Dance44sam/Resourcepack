item replace entity @a[tag=tweaks.shearer,limit=1] weapon.mainhand from entity @s contents
data remove entity @s Item
tag @s add tweaks.gave_back
