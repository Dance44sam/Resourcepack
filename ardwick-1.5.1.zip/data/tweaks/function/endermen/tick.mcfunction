# Endermen are tougher: 80 health, set once when each first appears
execute as @e[type=minecraft:enderman,tag=!tweaks.hp2] run function tweaks:endermen/harden
