$data modify storage tweaks:stack work set from storage tweaks:stack table."$(base)"
