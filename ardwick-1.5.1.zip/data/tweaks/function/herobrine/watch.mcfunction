scoreboard players add #hbage tweaks.timer 1
execute unless entity @a[tag=tweaks.hb_target] run return run function tweaks:herobrine/vanish
execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s unless entity @a[tag=tweaks.hb_target,distance=..96] run return run function tweaks:herobrine/vanish
execute if score #hbage tweaks.timer matches 2400.. unless entity @e[tag=tweaks.hb_seen] unless entity @e[tag=tweaks.hb_called] run return run function tweaks:herobrine/vanish
execute if score #hbage tweaks.timer matches 6000.. unless entity @e[tag=tweaks.hb_seen] run return run function tweaks:herobrine/vanish
execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s facing entity @a[tag=tweaks.hb_target,limit=1] eyes rotated ~ 0 run tp @s ~ ~ ~ ~ ~
execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s rotated as @s positioned ^0.125 ^ ^0.26 run tp @e[tag=tweaks.hb_eye_l,limit=1] ~ ~1.71875 ~ ~ 0
execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s rotated as @s positioned ^-0.125 ^ ^0.26 run tp @e[tag=tweaks.hb_eye_r,limit=1] ~ ~1.71875 ~ ~ 0
# Come within 32 blocks: a moment's blindness, and he is gone
execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s if entity @a[tag=tweaks.hb_target,distance=..32] run return run function tweaks:herobrine/blind
execute as @a[tag=tweaks.hb_target] if items entity @s weapon.mainhand #tweaks:ranged at @s anchored eyes facing entity @e[type=minecraft:mannequin,tag=tweaks.hb,limit=1] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.15] run return run function tweaks:herobrine/blind
scoreboard players set #hbseen tweaks.calc2 0
execute as @a[tag=tweaks.hb_target] at @s anchored eyes facing entity @e[type=minecraft:mannequin,tag=tweaks.hb,limit=1] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.8] run scoreboard players set #hbseen tweaks.calc2 1
execute if score #hbseen tweaks.calc2 matches 1 run return run tag @e[type=minecraft:mannequin,tag=tweaks.hb] add tweaks.hb_seen
execute if entity @e[tag=tweaks.hb_seen,tag=tweaks.hb_moved] run return run function tweaks:herobrine/vanish
execute if entity @e[tag=tweaks.hb_seen] run function tweaks:herobrine/move
