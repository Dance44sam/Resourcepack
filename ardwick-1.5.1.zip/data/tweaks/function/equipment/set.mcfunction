tag @s add tweaks.equip_checked
execute at @s if dimension minecraft:overworld run function tweaks:equipment/ungild
# Near an upgraded spawner
execute at @s if entity @e[type=minecraft:marker,tag=tweaks.spawner,distance=..6] run function tweaks:spawner/gear
data modify entity @s drop_chances set value {mainhand:0.17f,offhand:0.17f,head:0.17f,chest:0.17f,legs:0.17f,feet:0.17f}
execute if items entity @s weapon.mainhand minecraft:trident run data modify entity @s drop_chances.mainhand set value 2.0f
execute if items entity @s weapon.offhand minecraft:trident run data modify entity @s drop_chances.offhand set value 2.0f
execute if entity @s[type=#minecraft:skeletons] if items entity @s weapon.mainhand minecraft:bow run data remove entity @s drop_chances.mainhand
execute if entity @s[type=minecraft:piglin] run data remove entity @s drop_chances.mainhand
execute if entity @s[type=minecraft:zombified_piglin] run data remove entity @s drop_chances.mainhand
execute if entity @s[type=minecraft:wither_skeleton] run data modify entity @s drop_chances.mainhand set value 0.0f
execute if items entity @s weapon.mainhand *[minecraft:max_damage] unless items entity @s weapon.mainhand minecraft:trident run item modify entity @s weapon.mainhand tweaks:equipment/worn
execute if items entity @s weapon.offhand *[minecraft:max_damage] unless items entity @s weapon.offhand minecraft:trident run item modify entity @s weapon.offhand tweaks:equipment/worn
execute if items entity @s armor.head *[minecraft:max_damage] run item modify entity @s armor.head tweaks:equipment/worn
execute if items entity @s armor.chest *[minecraft:max_damage] run item modify entity @s armor.chest tweaks:equipment/worn
execute if items entity @s armor.legs *[minecraft:max_damage] run item modify entity @s armor.legs tweaks:equipment/worn
execute if items entity @s armor.feet *[minecraft:max_damage] run item modify entity @s armor.feet tweaks:equipment/worn
function tweaks:copper/player
execute if items entity @s armor.head #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.head tweaks:armor/specialty
execute if items entity @s armor.chest #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.chest tweaks:armor/specialty
execute if items entity @s armor.legs #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.legs tweaks:armor/specialty
execute if items entity @s armor.feet #tweaks:armor[!minecraft:custom_data~{tweaks_spec:6b}] run item modify entity @s armor.feet tweaks:armor/specialty
