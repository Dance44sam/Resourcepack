execute if block ~ ~ ~ #tweaks:suspicious align xyz run return run function tweaks:dig/assign
execute unless block ~ ~ ~ #tweaks:place_through run return 0
scoreboard players remove #rp tweaks.calc2 1
execute if score #rp tweaks.calc2 matches 1.. positioned ^ ^ ^0.05 run function tweaks:dig/ray
