# Spring, rolled out of 10000: rain 1.47% per spell
execute if score #roll tweaks.year matches 1..9853 run function tweaks:seasons/weather/clear_short
execute if score #roll tweaks.year matches 9854..10000 run function tweaks:seasons/weather/rain_short
