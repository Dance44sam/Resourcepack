tag @s remove tweaks.gentle
tag @s remove tweaks.gentle2
attribute @s minecraft:follow_range modifier remove tweaks:gentle
