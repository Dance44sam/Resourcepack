tellraw @s {"text":"Nothing calls you back.","color":"gray","italic":true}
give @s minecraft:ender_pearl[minecraft:custom_data={returning:1b},minecraft:item_name='"Pearl of Returning"',minecraft:item_model="minecraft:pearl_of_returning",minecraft:enchantment_glint_override=true]
