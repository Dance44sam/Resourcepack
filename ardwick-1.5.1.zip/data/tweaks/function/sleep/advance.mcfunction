# Sleepers with allowance left (Z) against non-spectators in the Overworld (W): time runs 1 + 20 x Z/W a tick
execute store result score #z tweaks.sum if entity @a[tag=tweaks.abed,scores={tweaks.sum=..11999}]
execute in minecraft:overworld store result score #w tweaks.sum if entity @a[gamemode=!spectator,distance=0..]
execute if score #w tweaks.sum < #z tweaks.sum run scoreboard players operation #w tweaks.sum = #z tweaks.sum
scoreboard players operation #t tweaks.sum = #z tweaks.sum
scoreboard players operation #t tweaks.sum *= #k20 tweaks.const
scoreboard players operation #acc tweaks.sum += #t tweaks.sum
scoreboard players operation #adv tweaks.sum = #acc tweaks.sum
scoreboard players operation #adv tweaks.sum /= #w tweaks.sum
scoreboard players operation #t tweaks.sum = #adv tweaks.sum
scoreboard players operation #t tweaks.sum *= #w tweaks.sum
scoreboard players operation #acc tweaks.sum -= #t tweaks.sum
scoreboard players set #room tweaks.sum 12000
scoreboard players operation #room tweaks.sum -= #world tweaks.sum
execute if score #adv tweaks.sum > #room tweaks.sum run scoreboard players operation #adv tweaks.sum = #room tweaks.sum
execute store result storage tweaks:sleep adv int 1 run scoreboard players get #adv tweaks.sum
execute if score #adv tweaks.sum matches 1.. run function tweaks:sleep/time_add with storage tweaks:sleep
execute if score #bucket tweaks.sum matches 0 run scoreboard players operation #world tweaks.b0 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 1 run scoreboard players operation #world tweaks.b1 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 2 run scoreboard players operation #world tweaks.b2 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 3 run scoreboard players operation #world tweaks.b3 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 4 run scoreboard players operation #world tweaks.b4 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 5 run scoreboard players operation #world tweaks.b5 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 6 run scoreboard players operation #world tweaks.b6 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 7 run scoreboard players operation #world tweaks.b7 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 8 run scoreboard players operation #world tweaks.b8 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 9 run scoreboard players operation #world tweaks.b9 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 10 run scoreboard players operation #world tweaks.b10 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 11 run scoreboard players operation #world tweaks.b11 += #adv tweaks.sum
execute if score #bucket tweaks.sum matches 0 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b0 20
execute if score #bucket tweaks.sum matches 1 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b1 20
execute if score #bucket tweaks.sum matches 2 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b2 20
execute if score #bucket tweaks.sum matches 3 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b3 20
execute if score #bucket tweaks.sum matches 4 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b4 20
execute if score #bucket tweaks.sum matches 5 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b5 20
execute if score #bucket tweaks.sum matches 6 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b6 20
execute if score #bucket tweaks.sum matches 7 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b7 20
execute if score #bucket tweaks.sum matches 8 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b8 20
execute if score #bucket tweaks.sum matches 9 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b9 20
execute if score #bucket tweaks.sum matches 10 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b10 20
execute if score #bucket tweaks.sum matches 11 run scoreboard players add @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.b11 20
scoreboard players remove @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] tweaks.vigour 1
