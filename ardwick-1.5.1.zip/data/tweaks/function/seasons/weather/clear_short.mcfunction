weather clear 300s
scoreboard players set #wtimer tweaks.year 300
