# Gold is a Nether metal in Ardwick
execute if items entity @s armor.head minecraft:golden_helmet run loot replace entity @s armor.head loot tweaks:bronze_gear/helmet
execute if items entity @s armor.chest minecraft:golden_chestplate run loot replace entity @s armor.chest loot tweaks:bronze_gear/chestplate
execute if items entity @s armor.legs minecraft:golden_leggings run loot replace entity @s armor.legs loot tweaks:bronze_gear/leggings
execute if items entity @s armor.feet minecraft:golden_boots run loot replace entity @s armor.feet loot tweaks:bronze_gear/boots
execute if items entity @s weapon.mainhand minecraft:golden_sword run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/sword
execute if items entity @s weapon.offhand minecraft:golden_sword run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/sword
execute if items entity @s weapon.mainhand minecraft:golden_axe run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/axe
execute if items entity @s weapon.offhand minecraft:golden_axe run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/axe
execute if items entity @s weapon.mainhand minecraft:golden_pickaxe run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/pickaxe
execute if items entity @s weapon.offhand minecraft:golden_pickaxe run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/pickaxe
execute if items entity @s weapon.mainhand minecraft:golden_shovel run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/shovel
execute if items entity @s weapon.offhand minecraft:golden_shovel run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/shovel
execute if items entity @s weapon.mainhand minecraft:golden_hoe run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/hoe
execute if items entity @s weapon.offhand minecraft:golden_hoe run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/hoe
execute if items entity @s weapon.mainhand minecraft:golden_spear run loot replace entity @s weapon.mainhand loot tweaks:bronze_gear/spear
execute if items entity @s weapon.offhand minecraft:golden_spear run loot replace entity @s weapon.offhand loot tweaks:bronze_gear/spear
