execute unless block ~ ~ ~ minecraft:smoker run return run kill @s
execute if block ~ ~ ~ minecraft:smoker[facing=north,lit=true] if predicate tweaks:kiln_puff run particle minecraft:flame ~ ~-0.3 ~-0.52 0.07 0.06 0 0 1
execute if block ~ ~ ~ minecraft:smoker[facing=south,lit=true] if predicate tweaks:kiln_puff run particle minecraft:flame ~ ~-0.3 ~0.52 0.07 0.06 0 0 1
execute if block ~ ~ ~ minecraft:smoker[facing=west,lit=true] if predicate tweaks:kiln_puff run particle minecraft:flame ~-0.52 ~-0.3 ~ 0 0.06 0.07 0 1
execute if block ~ ~ ~ minecraft:smoker[facing=east,lit=true] if predicate tweaks:kiln_puff run particle minecraft:flame ~0.52 ~-0.3 ~ 0 0.06 0.07 0 1
