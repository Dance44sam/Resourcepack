# Parents start vanilla's 5-minute cooldown (Age 6000) and babies a 20-minute childhood
scoreboard players set #age tweaks.calc2 0
execute store result score #age tweaks.calc2 run data get entity @s Age
execute if score #age tweaks.calc2 matches 5990..6000 run function tweaks:breed/stamp_parent
execute if score #age tweaks.calc2 matches -24000..-23990 run function tweaks:breed/stamp_baby
