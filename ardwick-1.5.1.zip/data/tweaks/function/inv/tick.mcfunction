# Safety sweep every 2 seconds, for changes the inventory trigger can miss (such as worn
scoreboard players add #invclock tweaks.timer 1
execute if score #invclock tweaks.timer matches 40.. as @a run function tweaks:inv/convert
execute if score #invclock tweaks.timer matches 40.. run function tweaks:body/mounts
execute if score #invclock tweaks.timer matches 40.. run scoreboard players set #invclock tweaks.timer 0
