# To The Point's throw goes to the thrower
tag @a remove tweaks.sf_thrower
execute on owner run tag @s add tweaks.sf_thrower
execute unless entity @a[tag=tweaks.sf_thrower] run tag @p[distance=..4] add tweaks.sf_thrower
advancement grant @a[tag=tweaks.sf_thrower] only tweaks:to_the_point thrown
tag @a remove tweaks.sf_thrower
