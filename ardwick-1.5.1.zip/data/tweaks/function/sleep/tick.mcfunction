# Who was in a bed last tick, and who is now? A sleeper lies in the bed block, so only they are read
tag @a remove tweaks.abed_prev
tag @a[tag=tweaks.abed] add tweaks.abed_prev
tag @a remove tweaks.abed
execute as @a[tag=!tweaks.abed] at @s if block ~ ~ ~ #minecraft:beds if data entity @s sleeping_pos run tag @s add tweaks.abed
function tweaks:sleep/clock
execute as @a run function tweaks:sleep/sum
function tweaks:sleep/world_sum
execute if score #world tweaks.sum matches ..11999 if entity @a[tag=tweaks.abed,scores={tweaks.sum=..11999}] run function tweaks:sleep/advance
execute as @a[tag=tweaks.abed,scores={tweaks.sum=12000..}] run function tweaks:sleep/rouse
execute if score #world tweaks.sum matches 12000.. as @a[tag=tweaks.abed] run function tweaks:sleep/rouse
