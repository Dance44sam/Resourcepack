# No fall damage while it lasts
attribute @s minecraft:fall_damage_multiplier modifier remove tweaks:feather_falling
attribute @s minecraft:fall_damage_multiplier modifier add tweaks:feather_falling -1 add_multiplied_total
