# Becomes a frog four days on
scoreboard players operation @s tweaks.due = #days tweaks.year
scoreboard players add @s tweaks.due 4
tag @s add tweaks.wait_tadpole
