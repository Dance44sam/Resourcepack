# A fresh stack of 2-8 that no player threw (mob and small block drops) splits into single
execute if entity @s[tag=tweaks.seen] run return 0
execute if data entity @s Thrower run return 0
execute store result score #sc tweaks.calc2 run data get entity @s Item.count
execute unless score #sc tweaks.calc2 matches 2..8 run return 0
data modify entity @s Item.count set value 1
function tweaks:split/hold
scoreboard players remove #sc tweaks.calc2 1
function tweaks:split/copy
