execute if block ~ ~ ~ minecraft:brewing_stand align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.brewstand,distance=..0.5] run return run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.brewstand"]}
execute if block ~ ~ ~ minecraft:brewing_stand run return 0
scoreboard players remove #bray tweaks.calc2 1
execute if score #bray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:brewstand/ray
