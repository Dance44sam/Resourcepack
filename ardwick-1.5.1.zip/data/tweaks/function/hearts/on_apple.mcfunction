execute if score @s tweaks.hearts matches ..9 run scoreboard players add @s tweaks.hearts 1
scoreboard players set @s tweaks.ega 0
scoreboard players set @s tweaks.ga 0
