execute unless block ~ ~ ~ #tweaks:ray_through run return run function tweaks:fell/hit
scoreboard players remove #ray tweaks.calc2 1
execute if score #ray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:fell/ray
