tag @s add tweaks.hp2
attribute @s minecraft:max_health base set 20
data modify entity @s Health set value 20.0f
