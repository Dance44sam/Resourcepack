# After the converters
execute if data storage tweaks:oversize pend run function tweaks:oversize/restore_all
data modify storage tweaks:oversize inv set from entity @s Inventory
function tweaks:oversize/walk
data remove storage tweaks:oversize inv
