$effect give @s minecraft:regeneration $(s) 0 true
