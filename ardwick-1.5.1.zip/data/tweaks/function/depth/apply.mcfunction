tag @s add tweaks.depth
execute unless dimension minecraft:overworld run return 0
# Depth below y 63, from 0 at sea level to 127 at the world floor (y -64)
execute store result score #dd tweaks.calc2 run data get entity @s Pos[1]
scoreboard players set #dm tweaks.calc2 63
scoreboard players operation #dm tweaks.calc2 -= #dd tweaks.calc2
execute if score #dm tweaks.calc2 matches ..0 run return 0
execute if score #dm tweaks.calc2 matches 128.. run scoreboard players set #dm tweaks.calc2 127
execute if entity @s[type=#tweaks:depth_runners] run function tweaks:depth/runner
execute if entity @s[type=#tweaks:depth_archers] run function tweaks:depth/archer
execute if entity @s[type=minecraft:creeper] run function tweaks:depth/creeper
