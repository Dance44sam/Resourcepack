execute as @e[type=#tweaks:zombie_leaders,tag=!tweaks.lead_seen] run function tweaks:leader/check
