scoreboard players remove @s tweaks.heat 300
# Heard once as the cool takes hold, not every second
execute if score @s tweaks.heat matches 2100.. unless entity @s[tag=tweaks.cooling] run playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.4 1.4
tag @s add tweaks.cooling
