execute unless block ~ ~ ~ #minecraft:campfires[lit=true] run return run kill @s
# Netherrack anywhere in the ten blocks below keeps it burning, for good
execute if block ~ ~-1 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-2 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-3 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-4 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-5 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-6 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-7 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-8 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-9 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
execute if block ~ ~-10 ~ #tweaks:eternal_fuel run return run advancement grant @a[distance=..8] only tweaks:eternal_flame
scoreboard players add @s tweaks.burn 20
execute if score @s tweaks.burn matches 24000.. run function tweaks:campfire/burn_out
