scoreboard players set #qy tweaks.calc2 4
function tweaks:warden/qy
scoreboard players remove #qz tweaks.calc2 1
execute if score #qz tweaks.calc2 matches 1.. positioned ~ ~ ~16 run function tweaks:warden/qz
