$effect give @s $(id) $(sec) $(amplifier)
