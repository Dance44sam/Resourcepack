advancement grant @s only tweaks:heartbreak
scoreboard players remove @s tweaks.hearts 1
# Never below the floor, which eases down as milestones are reached
execute if score @s tweaks.hearts < @s tweaks.floor run scoreboard players operation @s tweaks.hearts = @s tweaks.floor
execute if score @s tweaks.hearts matches ..1 run scoreboard players set @s tweaks.hearts 1
scoreboard players set @s tweaks.deaths 0
scoreboard players reset @s tweaks.v_m
scoreboard players reset @s tweaks.hp_prev
# Waking as if from a bad dream: vigour starts at its lowest and recovers as you move
scoreboard players set @s tweaks.vigour -300
