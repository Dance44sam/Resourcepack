# Under open sky in a hot place (heat/overworld). Nothing builds while any cold remains.
execute if score @s tweaks.cold matches 1.. run return 0
scoreboard players operation #gain tweaks.heat = #gross tweaks.heat
function tweaks:heat/finish
