# This rope's lead has just come off and been dropped.
execute if entity @a[distance=..8,predicate=tweaks:holding_shears] run return run kill @s
execute unless entity @s[tag=tweaks.rope_known] run return run kill @s
execute unless block ~ ~ ~ #minecraft:fences run return run kill @s
execute as @n[type=minecraft:item,distance=..2] if items entity @s contents minecraft:lead run item modify entity @s contents tweaks:rope/use_one
tag @s add tweaks.rope_owed
function tweaks:rope/settle
