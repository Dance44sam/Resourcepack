advancement revoke @s only tweaks:herobrine/shrine
# The shrine is lit: he comes now, night or day, if he is not already here
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb] run return 0
scoreboard players set #hbshrine tweaks.calc2 1
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:herobrine/shrine_ray_start
execute at @s run function tweaks:herobrine/try
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb] run playsound minecraft:ambient.cave ambient @s ~ ~ ~ 1 1
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb] run tag @e[type=minecraft:mannequin,tag=tweaks.hb] add tweaks.hb_called
