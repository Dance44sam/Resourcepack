# Along z: 32 cubes of 16, each 4 cubes high
scoreboard players set #qz tweaks.calc2 32
function tweaks:warden/qz
