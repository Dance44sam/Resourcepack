# Hoglins leave gold-wearers alone
team join tweaks.gilded @e[type=minecraft:hoglin,team=]
team leave @e[type=minecraft:zoglin,team=tweaks.gilded]
execute as @a[team=] if items entity @s armor.* #minecraft:piglin_safe_armor run team join tweaks.gilded @s
execute as @a[team=tweaks.gilded] unless items entity @s armor.* #minecraft:piglin_safe_armor run team leave @s
