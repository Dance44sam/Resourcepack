execute store result storage tweaks:rope p.x int 1 run scoreboard players get @s tweaks.rkx
execute store result storage tweaks:rope p.y int 1 run scoreboard players get @s tweaks.rky
execute store result storage tweaks:rope p.z int 1 run scoreboard players get @s tweaks.rkz
function tweaks:rope/settle_at with storage tweaks:rope p
