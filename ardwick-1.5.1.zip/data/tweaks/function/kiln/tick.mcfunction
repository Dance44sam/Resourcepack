# Every 10 ticks: a lit Mud Kiln sometimes puffs smoke from its flue, just as the Bloomery
scoreboard players add #kclock tweaks.timer 1
execute if score #kclock tweaks.timer matches 10.. as @e[type=minecraft:marker,tag=tweaks.kiln] at @s run function tweaks:kiln/check
execute if score #kclock tweaks.timer matches 10.. run scoreboard players set #kclock tweaks.timer 0
