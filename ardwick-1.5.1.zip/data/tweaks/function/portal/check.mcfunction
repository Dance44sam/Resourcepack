# Vanilla already lights 2-wide openings 3 or more tall
$execute if score #ph tweaks.calc2 matches 3.. if score #w$(w) tweaks.const matches 2 run return fail
$data modify storage tweaks:portal ax set value "$(ax)"
$data modify storage tweaks:portal w set value $(w)
scoreboard players operation #prow tweaks.calc2 = #ph tweaks.calc2
execute unless function tweaks:portal/rows_ok run return fail
function tweaks:portal/fill with storage tweaks:portal
return 1
