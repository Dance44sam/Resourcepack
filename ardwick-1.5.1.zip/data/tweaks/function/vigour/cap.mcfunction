# Frost is cold (or heat) in vigour points
scoreboard players operation #t tweaks.calc2 = @s tweaks.cold
scoreboard players operation #t tweaks.calc2 += @s tweaks.heat
scoreboard players operation #t tweaks.calc2 /= #k14 tweaks.const
scoreboard players add @s tweaks.frost 0
execute if score @s tweaks.heat matches 1.. run scoreboard players set @s tweaks.fside 1
execute if score @s tweaks.cold matches 1.. run scoreboard players set @s tweaks.fside 0
scoreboard players add @s tweaks.ftgt 0
execute unless score #t tweaks.calc2 = @s tweaks.ftgt run function tweaks:vigour/glide_start
scoreboard players add @s tweaks.fph 1
execute if score @s tweaks.fph matches 21.. run scoreboard players set @s tweaks.fph 20
scoreboard players operation #g tweaks.calc2 = @s tweaks.ftgt
scoreboard players operation #g tweaks.calc2 -= @s tweaks.fprev
scoreboard players operation #g tweaks.calc2 *= @s tweaks.fph
scoreboard players operation #g tweaks.calc2 /= #k20 tweaks.const
scoreboard players operation @s tweaks.frost = @s tweaks.fprev
scoreboard players operation @s tweaks.frost += #g tweaks.calc2
execute if score @s tweaks.frost matches 1.. run function tweaks:vigour/clamp
