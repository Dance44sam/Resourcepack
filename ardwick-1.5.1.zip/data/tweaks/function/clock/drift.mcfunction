scoreboard players set #clocktimer tweaks.year 0
# What the year looks like, shown only to a hand holding a clock
execute as @a[tag=tweaks.clock] at @s if score #day tweaks.year matches 0..6 run particle minecraft:spore_blossom_air ~ ~1.2 ~ 0.7 0.6 0.7 0 2
execute as @a[tag=tweaks.clock] at @s if score #day tweaks.year matches 7..13 run particle minecraft:pale_oak_leaves ~ ~1.2 ~ 0.7 0.6 0.7 0 2
execute as @a[tag=tweaks.clock] at @s if score #day tweaks.year matches 14..20 run particle minecraft:snowflake ~ ~1.2 ~ 0.7 0.6 0.7 0 2
execute as @a[tag=tweaks.clock] at @s if score #day tweaks.year matches 21..27 run particle minecraft:cherry_leaves ~ ~1.2 ~ 0.7 0.6 0.7 0 2
