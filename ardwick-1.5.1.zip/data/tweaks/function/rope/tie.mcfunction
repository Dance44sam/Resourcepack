# Start a rope at this fence
execute if entity @e[type=minecraft:frog,tag=tweaks.rope,distance=..0.6] run return 0
execute if entity @e[type=minecraft:leash_knot,distance=..1] unless entity @e[type=minecraft:leash_knot,distance=..1,scores={tweaks.knot_age=21..}] run return 0
summon minecraft:frog ~ ~-0.425 ~-0.2 {Tags:["tweaks.rope","tweaks.rope4","tweaks.rope_new"],Rotation:[0f,0f],NoAI:1b,Silent:1b,Invulnerable:1b,NoGravity:1b,PersistenceRequired:1b,DeathLootTable:"minecraft:empty",active_effects:[{id:"minecraft:invisibility",duration:-1,amplifier:0,ambient:1b,show_particles:0b,show_icon:0b}]}
data modify entity @n[type=minecraft:frog,tag=tweaks.rope_new,distance=..1] leash.UUID set from entity @s UUID
tag @e[type=minecraft:frog,tag=tweaks.rope_new] remove tweaks.rope_new
execute unless entity @e[type=minecraft:leash_knot,distance=..0.5] run summon minecraft:leash_knot ~ ~ ~
playsound minecraft:entity.leash_knot.place block @a ~ ~ ~ 1 1
execute if entity @s[gamemode=creative] run return 0
execute if items entity @s weapon.mainhand minecraft:lead run return run item modify entity @s weapon.mainhand tweaks:rope/use_one
item modify entity @s weapon.offhand tweaks:rope/use_one
