weather thunder 240s
scoreboard players set #wtimer tweaks.year 240
