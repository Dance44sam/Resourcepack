execute if score #days tweaks.year >= @s tweaks.due run return run data modify entity @s Age set value 23999
# Not yet: keep it a tadpole, and undo any slimeballs it has been fed
data modify entity @s Age set value 0
