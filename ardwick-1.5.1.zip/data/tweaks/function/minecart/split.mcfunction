# A broken minecart carrying a block comes apart
data modify entity @s Item.id set value "minecraft:minecart"
$summon minecraft:item ~ ~0.2 ~ {Item:{id:"minecraft:$(block)",count:1},PickupDelay:10s,Tags:["tweaks.seen"]}
tag @s remove tweaks.conv
