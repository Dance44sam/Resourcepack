# Conversions that only need doing once per item entity (re-run when the pack changes the item)
execute if items entity @s contents minecraft:lava_bucket run data modify entity @s Item.id set value "minecraft:bucket"
execute if items entity @s contents #tweaks:food[!minecraft:custom_data~{ardwick_food_v16:1b},!minecraft:custom_data~{tweaks_pasty:1b},!minecraft:custom_data~{tweaks_cooked_carrot:1b}] run item modify entity @s contents tweaks:food/convert
execute if items entity @s contents minecraft:beetroot[minecraft:custom_data~{tweaks_cooked_carrot:1b},!minecraft:custom_data~{ardwick_food_v16:1b}] run item modify entity @s contents tweaks:food/cooked_carrot_update
execute if items entity @s contents minecraft:compass[!minecraft:lodestone_tracker,!minecraft:custom_name] run item modify entity @s contents tweaks:compass/north
execute if items entity @s contents minecraft:compass[!minecraft:lodestone_tracker,minecraft:custom_name] run item modify entity @s contents tweaks:compass/north_named
execute if items entity @s contents minecraft:lead[!minecraft:custom_data~{tweaks_rope:1b}] run item modify entity @s contents tweaks:rope/lead
execute if items entity @s contents #tweaks:disguises[!minecraft:custom_data~{tweaks_disguise:1b}] run item modify entity @s contents tweaks:disguise/label
execute if items entity @s contents #tweaks:stack_16[!minecraft:max_stack_size=16] run item modify entity @s contents tweaks:seeds/stack
execute if items entity @s contents #tweaks:stack_3[!minecraft:max_stack_size=3] run item modify entity @s contents tweaks:potion/stack
execute if items entity @s contents #tweaks:stack_1[!minecraft:max_stack_size=1] run item modify entity @s contents tweaks:stack/one
execute if items entity @s contents #tweaks:glints[!minecraft:enchantment_glint_override=false] run item modify entity @s contents tweaks:glint/off
execute if items entity @s contents #tweaks:glint_restored[minecraft:enchantment_glint_override=false] run item modify entity @s contents tweaks:glint/restore
execute if items entity @s contents minecraft:blue_dye[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents minecraft:green_dye[minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents #tweaks:inert_eggs[minecraft:entity_data] run item modify entity @s contents tweaks:egg_inert
execute if items entity @s contents minecraft:ravager_spawn_egg[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents minecraft:elder_guardian_spawn_egg[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents minecraft:vindicator_spawn_egg[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents minecraft:skeleton_horse_spawn_egg[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
execute if items entity @s contents minecraft:piglin_brute_spawn_egg[!minecraft:provides_trim_material] run item modify entity @s contents tweaks:dye/trim
tag @s add tweaks.conv
