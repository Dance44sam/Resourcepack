# One log of the trunk
summon minecraft:marker ~ ~ ~ {Tags:["tweaks.fell"]}
scoreboard players add #count tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~1 ~ ~ #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~-1 ~ ~ #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~ ~1 ~ #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~ ~-1 ~ #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~ ~ ~1 #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #natural tweaks.calc2 matches 0 if block ~ ~ ~-1 #minecraft:leaves[persistent=false] run scoreboard players set #natural tweaks.calc2 1
execute if score #count tweaks.calc2 matches 256.. run return 0
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~-1 ~ ~ if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~-1 ~ ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~ ~ ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~ ~ ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~ ~1 ~ if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~ ~1 ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~ ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~ ~ if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~ ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~1 ~ if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #tweaks:tree_logs unless entity @e[type=minecraft:marker,tag=tweaks.fell,distance=..0.5] run function tweaks:fell/visit
