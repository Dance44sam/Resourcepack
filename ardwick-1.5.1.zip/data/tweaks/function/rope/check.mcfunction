# A rope waiting for its far fence's chunk to load (rope/lost) tries again
execute if entity @s[tag=tweaks.rope_owed] run return run function tweaks:rope/settle
execute unless data entity @s leash run return run kill @s
execute unless block ~ ~ ~ #minecraft:fences run return run kill @s
execute unless entity @s[tag=tweaks.rope4] run return run function tweaks:rope/recentre
execute align xyz positioned ~0.5 ~0.55 ~0.5 unless entity @e[type=minecraft:leash_knot,distance=..0.5] run summon minecraft:leash_knot ~ ~ ~
execute if data entity @s leash[0] run function tweaks:rope/remember
