tag @s remove tweaks.husk_hit
# The husk's Hunger goes (a Hunger the pack applies to drain extra food is left alone)
execute unless entity @s[tag=tweaks.draining] run effect clear @s minecraft:hunger
execute store result score #hd tweaks.calc2 run difficulty
execute if score #hd tweaks.calc2 matches 1 run effect give @s minecraft:poison 2 0
execute if score #hd tweaks.calc2 matches 2 run effect give @s minecraft:poison 4 0
execute if score #hd tweaks.calc2 matches 3 run effect give @s minecraft:poison 8 0
