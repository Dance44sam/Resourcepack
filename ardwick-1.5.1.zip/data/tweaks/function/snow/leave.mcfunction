attribute @s minecraft:movement_speed modifier remove tweaks:snow
tag @s remove tweaks.on_snow
