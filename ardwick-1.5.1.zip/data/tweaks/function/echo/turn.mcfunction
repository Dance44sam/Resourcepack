data modify entity @s Item.id set value "minecraft:echo_shard"
particle minecraft:squid_ink ~ ~0.2 ~ 0.25 0.15 0.25 0.02 24
particle minecraft:sculk_soul ~ ~0.3 ~ 0.2 0.2 0.2 0.02 6
playsound minecraft:entity.warden.heartbeat hostile @a ~ ~ ~ 1.2 0.8
playsound minecraft:block.sculk_shrieker.shriek hostile @a ~ ~ ~ 0.35 0.6
advancement grant @a[distance=..8] only tweaks:echo_shard made
tag @s remove tweaks.conv
