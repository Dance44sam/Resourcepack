# Debug (/function tweaks:shulker/debug)
function tweaks:shulker/weigh
tellraw @s ["Filled sack slots counted: ",{"score":{"name":"#sh","objective":"tweaks.calc2"}}," (0.4% slower each, at most 100)"]
tellraw @s ["Filled slots in the sack in your first hotbar slot: ",{"nbt":"Inventory[{Slot:0b}].components.\"minecraft:container\"","entity":"@s"}]
execute store result score #dbg tweaks.calc2 run attribute @s minecraft:movement_speed modifier value get tweaks:shulker_weight 1000
tellraw @s ["Sack slowdown now applied (thousandths of base speed): ",{"score":{"name":"#dbg","objective":"tweaks.calc2"}}]
