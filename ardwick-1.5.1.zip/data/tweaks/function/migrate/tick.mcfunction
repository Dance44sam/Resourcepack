# Seasonal migration
execute as @e[type=minecraft:zombie,tag=!tweaks.mig] at @s run function tweaks:migrate/zombie
execute as @e[type=minecraft:skeleton,tag=!tweaks.mig] at @s run function tweaks:migrate/skeleton
