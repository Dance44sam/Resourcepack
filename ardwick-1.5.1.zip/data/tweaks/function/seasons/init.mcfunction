scoreboard objectives add tweaks.year dummy
scoreboard players set #28 tweaks.year 28
scoreboard objectives add tweaks.online dummy
scoreboard objectives add tweaks.leaves minecraft.custom:minecraft.leave_game
# "add 0" creates these without overwriting a value carried over from last session
scoreboard players add #day tweaks.year 0
scoreboard players add #wtimer tweaks.year 0
scoreboard players add #days tweaks.year 0
execute unless score #hbday tweaks.year matches -2147483648.. run scoreboard players operation #hbday tweaks.year = #days tweaks.year
scoreboard players add #hbdue tweaks.year 0
scoreboard players add #peace tweaks.year 0
