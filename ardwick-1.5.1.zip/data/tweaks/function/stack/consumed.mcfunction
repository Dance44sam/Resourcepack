# Finished: every effect the item gives that was already running at the same strength gets
advancement revoke @s only tweaks:stack/consumed
execute unless score @s tweaks.pid matches 1.. run return 0
execute store result storage tweaks:stack id int 1 run scoreboard players get @s tweaks.pid
function tweaks:stack/gather with storage tweaks:stack
