# The first player to arrive in an Overworld marks where the world began, so a bed can't
execute unless dimension minecraft:overworld run return 0
execute store result score #wsx tweaks.spx run data get entity @s Pos[0] 1
execute store result score #wsy tweaks.spx run data get entity @s Pos[1] 1
execute store result score #wsz tweaks.spx run data get entity @s Pos[2] 1
