# The skeleton leaves nothing behind: what replaces it is the wither skeleton
data merge entity @s {DeathLootTable:"minecraft:empty"}
item replace entity @s weapon.mainhand with air
item replace entity @s weapon.offhand with air
item replace entity @s armor.head with air
item replace entity @s armor.chest with air
item replace entity @s armor.legs with air
item replace entity @s armor.feet with air
summon minecraft:wither_skeleton ~ ~ ~ {Tags:["tweaks.hardy","tweaks.hp2","tweaks.newly_risen"],attributes:[{id:"minecraft:max_health",base:80}],Health:80.0f}
execute as @e[type=minecraft:wither_skeleton,tag=tweaks.newly_risen] run function tweaks:mobs/arm_wither
kill @s
