tag @s add tweaks.draining
effect give @s minecraft:hunger 1 255 true
