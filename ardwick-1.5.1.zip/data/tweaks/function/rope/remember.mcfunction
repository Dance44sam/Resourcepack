execute store result score @s tweaks.rkx run data get entity @s leash[0]
execute store result score @s tweaks.rky run data get entity @s leash[1]
execute store result score @s tweaks.rkz run data get entity @s leash[2]
tag @s add tweaks.rope_known
