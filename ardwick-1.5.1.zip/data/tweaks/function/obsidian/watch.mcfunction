# Ten seconds for the water to arrive
scoreboard players add @s tweaks.ob_age 1
execute if block ~ ~ ~ minecraft:obsidian run return run function tweaks:obsidian/formed
execute unless block ~ ~ ~ minecraft:lava run return run kill @s
execute if score @s tweaks.ob_age matches 200.. run kill @s
