# No axe: drop any slowdown and forget the tree
execute unless items entity @s weapon.mainhand #minecraft:axes run return run function tweaks:fell/forget
execute if score @s tweaks.fell_n matches 2.. run function tweaks:fell/check_broken
scoreboard players set #ray tweaks.calc2 45
scoreboard players set #hit tweaks.calc2 0
execute anchored eyes positioned ^ ^ ^ run function tweaks:fell/ray
execute if score #hit tweaks.calc2 matches 0 run function tweaks:fell/forget
