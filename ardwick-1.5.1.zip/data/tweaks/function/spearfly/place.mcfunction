# Position from the trident
tp @s ~ ~ ~
execute store result entity @s Rotation[0] float -0.001 run data get entity @e[type=minecraft:trident,tag=tweaks.sf_cur,limit=1] Rotation[0] 1000
execute store result entity @s Rotation[1] float -0.001 run data get entity @e[type=minecraft:trident,tag=tweaks.sf_cur,limit=1] Rotation[1] 1000
tag @s add tweaks.sf_ok
