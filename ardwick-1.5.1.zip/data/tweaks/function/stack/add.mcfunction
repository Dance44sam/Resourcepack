# The healing and slowness carriers are the food system's own business, and already add up
execute if data storage tweaks:stack e{id:"minecraft:unluck"} run return 0
$execute if data storage tweaks:stack e{id:"minecraft:luck"} if data storage tweaks:stack p$(pid).item.components."minecraft:food" run return 0
scoreboard players set #prior tweaks.calc2 0
$execute if score #zero tweaks.calc2 matches 0 store result score #prior tweaks.calc2 run data get storage tweaks:stack p$(pid).fx[{id:"$(id)",amplifier:$(amplifier)b}].duration
$execute if score #prior tweaks.calc2 matches 0 if data storage tweaks:stack e{amplifier:0} unless data storage tweaks:stack p$(pid).fx[{id:"$(id)"}].amplifier store result score #prior tweaks.calc2 run data get storage tweaks:stack p$(pid).fx[{id:"$(id)"}].duration
execute unless score #prior tweaks.calc2 matches 1.. run return 0
$scoreboard players set #total tweaks.calc2 $(duration)
scoreboard players operation #total tweaks.calc2 += #prior tweaks.calc2
scoreboard players add #total tweaks.calc2 19
scoreboard players operation #total tweaks.calc2 /= #k20 tweaks.const
execute store result storage tweaks:stack e.sec int 1 run scoreboard players get #total tweaks.calc2
function tweaks:stack/give with storage tweaks:stack e
