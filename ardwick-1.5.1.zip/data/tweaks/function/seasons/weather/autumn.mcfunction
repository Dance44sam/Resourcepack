# Autumn, rolled out of 10000: rain 1.11%, thunder 1.11% per spell
execute if score #roll tweaks.year matches 1..9778 run function tweaks:seasons/weather/clear_short
execute if score #roll tweaks.year matches 9779..9889 run function tweaks:seasons/weather/rain_long
execute if score #roll tweaks.year matches 9890..10000 run function tweaks:seasons/weather/thunder_long
