execute store result storage tweaks:pearl x int 1 run scoreboard players get @s tweaks.spx
execute store result storage tweaks:pearl y int 1 run scoreboard players get @s tweaks.spy
execute store result storage tweaks:pearl z int 1 run scoreboard players get @s tweaks.spz
data modify storage tweaks:pearl dim set value "minecraft:overworld"
execute if score @s tweaks.sdim matches 1 run data modify storage tweaks:pearl dim set value "minecraft:the_nether"
execute if score @s tweaks.sdim matches 2 run data modify storage tweaks:pearl dim set value "minecraft:the_end"
function tweaks:pearl/tp with storage tweaks:pearl
# The star outlasts the pearl, and arrives with you
execute at @s run summon minecraft:item ~ ~0.2 ~ {Item:{id:"minecraft:nether_star",count:1}}
execute at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.5 0.3 0.2 60
execute at @s run playsound minecraft:block.campfire.crackle player @s ~ ~ ~ 0.8 1.2
