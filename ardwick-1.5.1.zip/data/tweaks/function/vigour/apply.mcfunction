function tweaks:vigour/curve
scoreboard players remove #m tweaks.calc2 1000
# Same speed and damage as last tick: the modifiers already in place are right
execute if score #m tweaks.calc2 = @s tweaks.v_m if score #dmg tweaks.calc2 = @s tweaks.v_d run return 0
scoreboard players operation @s tweaks.v_m = #m tweaks.calc2
scoreboard players operation @s tweaks.v_d = #dmg tweaks.calc2
attribute @s minecraft:movement_speed modifier remove tweaks:vigour
attribute @s minecraft:block_break_speed modifier remove tweaks:vigour
attribute @s minecraft:attack_speed modifier remove tweaks:vigour
attribute @s minecraft:attack_damage modifier remove tweaks:vigour
execute store result storage tweaks:vigour amount double 0.001 run scoreboard players get #m tweaks.calc2
execute store result storage tweaks:vigour dmg double 0.001 run scoreboard players get #dmg tweaks.calc2
execute unless score #m tweaks.calc2 matches 0 run function tweaks:vigour/set_speed with storage tweaks:vigour
execute if score #dmg tweaks.calc2 matches 1.. run function tweaks:vigour/set_damage with storage tweaks:vigour
