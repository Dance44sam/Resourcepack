tag @s add tweaks.dough
# Changing the id keeps the stack size, unlike replacing the item
data modify entity @s Item.id set value "minecraft:wandering_trader_spawn_egg"
item modify entity @s contents tweaks:egg_inert
playsound minecraft:entity.generic.splash player @a ~ ~ ~ 0.4 1.4
tag @s remove tweaks.conv
