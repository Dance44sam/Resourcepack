$title @s actionbar {"text":"$(lo)$(li)$(ri)$(ro)$(flo)$(fli)$(fri)$(fro)","font":"tweaks:vigour","color":"white","shadow_color":0}
