# A flammable block, TNT or a campfire was just placed in the Nether
advancement revoke @s only tweaks:nether_burn/placed
scoreboard players set #nb tweaks.calc2 110
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:nether_burn/ray
