# Each mob is looked at once, the moment it appears
execute as @e[type=#tweaks:skeleton_kinds,tag=!tweaks.seen] at @s run function tweaks:mobs/skeleton_seen
execute as @e[type=#minecraft:zombies,tag=!tweaks.seen,nbt={IsBaby:1b}] run function tweaks:mobs/baby_zombie
execute as @e[type=minecraft:creeper,tag=!tweaks.seen] run function tweaks:mobs/creeper_seen
