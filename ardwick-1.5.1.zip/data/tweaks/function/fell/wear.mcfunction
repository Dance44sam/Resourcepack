scoreboard players set #d tweaks.calc2 0
execute store result score #d tweaks.calc2 run data get entity @s SelectedItem.components."minecraft:damage"
scoreboard players operation #d tweaks.calc2 += #count tweaks.calc2
scoreboard players remove #d tweaks.calc2 1
scoreboard players set #max tweaks.calc2 0
execute if items entity @s weapon.mainhand minecraft:wooden_axe run scoreboard players set #max tweaks.calc2 59
execute if items entity @s weapon.mainhand minecraft:golden_axe run scoreboard players set #max tweaks.calc2 32
execute if items entity @s weapon.mainhand minecraft:stone_axe run scoreboard players set #max tweaks.calc2 131
execute if items entity @s weapon.mainhand minecraft:copper_axe run scoreboard players set #max tweaks.calc2 190
execute if items entity @s weapon.mainhand minecraft:iron_axe run scoreboard players set #max tweaks.calc2 250
execute if items entity @s weapon.mainhand minecraft:diamond_axe run scoreboard players set #max tweaks.calc2 1561
execute if items entity @s weapon.mainhand minecraft:netherite_axe run scoreboard players set #max tweaks.calc2 2031
# An axe that carries its own durability (bronze, rose gold) is judged by that, not by its
execute store result score #own tweaks.calc2 run data get entity @s SelectedItem.components."minecraft:max_damage"
execute if score #own tweaks.calc2 matches 1.. run scoreboard players operation #max tweaks.calc2 = #own tweaks.calc2
execute if score #max tweaks.calc2 matches 1.. if score #d tweaks.calc2 >= #max tweaks.calc2 run return run function tweaks:frames/snap
execute store result storage tweaks:fell d int 1 run scoreboard players get #d tweaks.calc2
function tweaks:fell/set_damage with storage tweaks:fell
