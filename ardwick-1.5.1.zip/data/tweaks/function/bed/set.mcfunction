$execute in $(dim) run spawnpoint @s $(x) $(y) $(z)
