# 5% slower while walking on snow layers, unless wearing leather boots ("+1 Snow Speed")
tag @a remove tweaks.snow_now
execute as @a at @s unless items entity @s armor.feet minecraft:leather_boots if block ~ ~ ~ minecraft:snow run tag @s add tweaks.snow_now
execute as @a at @s unless items entity @s armor.feet minecraft:leather_boots if block ~ ~-0.05 ~ minecraft:snow[layers=8] run tag @s add tweaks.snow_now
execute as @a[tag=tweaks.snow_now,tag=!tweaks.on_snow] run function tweaks:snow/enter
execute as @a[tag=!tweaks.snow_now,tag=tweaks.on_snow] run function tweaks:snow/leave
