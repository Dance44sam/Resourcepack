# A Mud Kiln was placed
advancement revoke @s only tweaks:kiln/placed
scoreboard players set #kray tweaks.calc2 60
execute anchored eyes positioned ^ ^ ^ run function tweaks:kiln/ray
