execute align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=tweaks.burning,distance=..0.4] run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.burning"]}
