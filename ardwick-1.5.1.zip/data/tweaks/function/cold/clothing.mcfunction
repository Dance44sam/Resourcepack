# Clothing changes how fast the cold bites, in eighths
scoreboard players set #wear tweaks.cold 8
execute if items entity @s armor.head minecraft:leather_helmet run scoreboard players remove #wear tweaks.cold 2
execute if items entity @s armor.head minecraft:golden_helmet[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 2
execute if items entity @s armor.head minecraft:golden_helmet[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 1
execute if items entity @s armor.chest minecraft:leather_chestplate run scoreboard players remove #wear tweaks.cold 2
execute if items entity @s armor.chest minecraft:golden_chestplate[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 2
execute if items entity @s armor.chest minecraft:golden_chestplate[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 1
execute if items entity @s armor.legs minecraft:leather_leggings run scoreboard players remove #wear tweaks.cold 2
execute if items entity @s armor.legs minecraft:golden_leggings[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 2
execute if items entity @s armor.legs minecraft:golden_leggings[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 1
execute if items entity @s armor.feet minecraft:leather_boots run scoreboard players remove #wear tweaks.cold 2
execute if items entity @s armor.feet minecraft:golden_boots[!minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 2
execute if items entity @s armor.feet minecraft:golden_boots[minecraft:custom_data~{tweaks_alloy:"rose_gold"}] run scoreboard players add #wear tweaks.cold 1
execute if score #gain tweaks.cold matches ..0 run return 0
scoreboard players operation #gain tweaks.cold *= #wear tweaks.cold
scoreboard players operation #gain tweaks.cold /= #eight tweaks.heat
