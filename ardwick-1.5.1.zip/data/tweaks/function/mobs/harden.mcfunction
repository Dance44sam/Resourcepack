tag @s add tweaks.hardy
tag @s add tweaks.hp2
attribute @s minecraft:max_health base set 80
data modify entity @s Health set value 80.0f
