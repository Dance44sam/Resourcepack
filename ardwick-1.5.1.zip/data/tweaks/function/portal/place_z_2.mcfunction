setblock ~ ~ ~ minecraft:nether_portal[axis=z] strict
setblock ~ ~ ~1 minecraft:nether_portal[axis=z] strict
scoreboard players remove #prow tweaks.calc2 1
execute if score #prow tweaks.calc2 matches 1.. positioned ~ ~1 ~ run function tweaks:portal/place_z_2
