scoreboard players operation #hbday tweaks.year = #days tweaks.year
execute store result score #hbroll tweaks.calc2 run random value 1..7
execute if score #hbroll tweaks.calc2 matches 1 run scoreboard players set #hbdue tweaks.year 1
