# Once a second for every campfire with a burn under way
execute as @e[type=minecraft:marker,tag=tweaks.burning] at @s run function tweaks:campfire/burn_age
