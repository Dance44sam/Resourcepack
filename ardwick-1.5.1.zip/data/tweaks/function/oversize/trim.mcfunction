# Worked out and copied before the slot is changed
execute store result storage tweaks:oversize t.slot int 1 run data get storage tweaks:oversize inv[0].Slot
execute store result storage tweaks:oversize k int 1 run scoreboard players get #ovl tweaks.calc2
scoreboard players operation #ove tweaks.calc2 = #ovn tweaks.calc2
scoreboard players operation #ove tweaks.calc2 -= #ovl tweaks.calc2
data modify storage tweaks:oversize drop set from storage tweaks:oversize inv[0]
function tweaks:oversize/trim_slot with storage tweaks:oversize t
function tweaks:oversize/drop
