# Walking wears positive vigour down at half the rate
execute if score #vpar tweaks.timer matches 0 if score @s tweaks.vigour matches 1.. run scoreboard players remove @s tweaks.vigour 1
execute if score @s tweaks.vigour matches ..-1 run scoreboard players add @s tweaks.vigour 1
