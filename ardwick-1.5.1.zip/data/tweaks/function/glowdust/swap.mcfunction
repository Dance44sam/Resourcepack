$execute store result storage tweaks:glowdust n int 1 if items entity @s $(slot) minecraft:glowstone_dust
$data modify storage tweaks:glowdust slot set value "$(slot)"
function tweaks:glowdust/swap_n with storage tweaks:glowdust
