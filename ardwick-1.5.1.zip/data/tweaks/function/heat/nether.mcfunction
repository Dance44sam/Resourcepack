# The Nether has no sky, day or season
execute if score @s tweaks.cold matches 1.. run return 0
scoreboard players set #gain tweaks.heat 0
execute if predicate tweaks:heat/bn20 run scoreboard players set #gain tweaks.heat 200
execute if predicate tweaks:heat/bn25 run scoreboard players set #gain tweaks.heat 250
function tweaks:heat/finish
