# One in 28 new obsidian blocks lets a blaze out of the cooling lava
execute if predicate tweaks:one_in_28 run function tweaks:obsidian/blaze
kill @s
