execute store result score #dt tweaks.calc2 run data get entity @s DeathTime
execute unless score #dt tweaks.calc2 matches 1.. run return 0
tag @s add tweaks.w_fallen
execute align xyz run summon minecraft:marker ~ ~ ~ {Tags:["tweaks.quiet"]}
