tag @s remove tweaks.newly_risen
item replace entity @s weapon.mainhand with minecraft:stone_sword
