# A fire dries you as well as warms you
scoreboard players set @s tweaks.wet 0
scoreboard players remove @s tweaks.cold 300
execute if score @s tweaks.cold matches 2100.. unless entity @s[tag=tweaks.thawing] run function tweaks:cold/thaw
tag @s add tweaks.thawing
