# A soul campfire cools rather than warms: resting by one clears heat, not cold
tag @s add tweaks.soulcamp
effect give @s minecraft:regeneration 4 1 true
execute if score @s tweaks.heat matches ..2099 run function tweaks:campfire/rest
