execute if predicate tweaks:one_in_28 run function tweaks:obsidian/blaze
