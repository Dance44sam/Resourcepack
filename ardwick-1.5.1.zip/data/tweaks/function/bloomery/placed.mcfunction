# A Bloomery was placed: mark it, so its flames can be drawn (as the Mud Kiln's are by the game)
advancement revoke @s only tweaks:bloomery/placed
scoreboard players set #bray tweaks.calc2 60
execute anchored eyes positioned ^ ^ ^ run function tweaks:bloomery/ray
