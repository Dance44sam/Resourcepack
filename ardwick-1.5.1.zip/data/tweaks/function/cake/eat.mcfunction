effect give @s minecraft:luck 5 0 true
effect give @s minecraft:unluck 5 0 true
scoreboard players remove @s tweaks.cake 1
execute if score @s tweaks.cake matches 1.. run function tweaks:cake/eat
