# A new appearance, or the jump nearer
execute if score #hbmode tweaks.calc2 matches 1 run return run function tweaks:herobrine/relocate
function tweaks:herobrine/appear
