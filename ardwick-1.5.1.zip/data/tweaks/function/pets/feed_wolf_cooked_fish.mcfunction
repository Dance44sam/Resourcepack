advancement revoke @s only tweaks:pets/wolf_cooked_fish
execute at @s as @e[type=#tweaks:pets,distance=..6,sort=nearest,limit=1] run function tweaks:pets/heal_2
