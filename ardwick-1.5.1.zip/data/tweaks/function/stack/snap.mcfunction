$data remove storage tweaks:stack p$(id)
$data modify storage tweaks:stack p$(id).fx set from entity @s active_effects
$execute if items entity @s weapon.mainhand #tweaks:stackable run data modify storage tweaks:stack p$(id).item set from entity @s SelectedItem
$execute unless items entity @s weapon.mainhand #tweaks:stackable run data modify storage tweaks:stack p$(id).item set from entity @s equipment.offhand
