# Hand back #ove items of the stack in storage drop, at most one full stack (#ovl) per item
scoreboard players operation #ovc tweaks.calc2 = #ove tweaks.calc2
scoreboard players operation #ovc tweaks.calc2 < #ovl tweaks.calc2
execute store result storage tweaks:oversize drop.count int 1 run scoreboard players get #ovc tweaks.calc2
data remove storage tweaks:oversize drop.Slot
execute at @s run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:stone",count:1},PickupDelay:0s,Tags:["tweaks.ovs"]}
execute at @s run data modify entity @n[type=minecraft:item,tag=tweaks.ovs,distance=..1] Item set from storage tweaks:oversize drop
execute at @s run tag @n[type=minecraft:item,tag=tweaks.ovs,distance=..1] remove tweaks.ovs
scoreboard players operation #ove tweaks.calc2 -= #ovc tweaks.calc2
execute if score #ove tweaks.calc2 matches 1.. run function tweaks:oversize/drop
