# Night skipped by the whole world in the last day (at most 12,000 ticks, however many sleep)
scoreboard players set #world tweaks.sum 0
scoreboard players operation #world tweaks.sum += #world tweaks.b0
scoreboard players operation #world tweaks.sum += #world tweaks.b1
scoreboard players operation #world tweaks.sum += #world tweaks.b2
scoreboard players operation #world tweaks.sum += #world tweaks.b3
scoreboard players operation #world tweaks.sum += #world tweaks.b4
scoreboard players operation #world tweaks.sum += #world tweaks.b5
scoreboard players operation #world tweaks.sum += #world tweaks.b6
scoreboard players operation #world tweaks.sum += #world tweaks.b7
scoreboard players operation #world tweaks.sum += #world tweaks.b8
scoreboard players operation #world tweaks.sum += #world tweaks.b9
scoreboard players operation #world tweaks.sum += #world tweaks.b10
scoreboard players operation #world tweaks.sum += #world tweaks.b11
