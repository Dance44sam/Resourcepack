$attribute @s minecraft:movement_speed modifier add tweaks:vigour $(amount) add_multiplied_total
$attribute @s minecraft:block_break_speed modifier add tweaks:vigour $(amount) add_multiplied_total
$attribute @s minecraft:attack_speed modifier add tweaks:vigour $(amount) add_multiplied_total
