execute store result storage tweaks:hb dist int 1 run random value 34..48
execute store result score #hbside tweaks.calc2 run random value 0..1
execute if score #hbside tweaks.calc2 matches 0 store result storage tweaks:hb yaw int 1 run random value 70..110
execute if score #hbside tweaks.calc2 matches 1 store result storage tweaks:hb yaw int 1 run random value 250..290
function tweaks:herobrine/aim with storage tweaks:hb
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb,tag=tweaks.hb_placed] run return 0
scoreboard players remove #hbtries tweaks.calc2 1
execute if score #hbtries tweaks.calc2 matches 1.. run function tweaks:herobrine/move_spot
