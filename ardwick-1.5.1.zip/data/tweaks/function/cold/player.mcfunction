# Wet through: water at your feet or head. It dries in ten seconds. Rain does not count.
scoreboard players add @s tweaks.wet 0
execute if score @s tweaks.wet matches 1.. run scoreboard players remove @s tweaks.wet 1
execute if block ~ ~ ~ minecraft:water run scoreboard players set @s tweaks.wet 10
execute if block ~ ~1 ~ minecraft:water run scoreboard players set @s tweaks.wet 10
tag @s remove tweaks.heated
execute unless dimension minecraft:the_nether unless entity @s[tag=tweaks.warmed] run function tweaks:cold/heat
execute if dimension minecraft:the_nether run scoreboard players remove @s tweaks.cold 600
execute unless dimension minecraft:the_nether if entity @s[tag=tweaks.warmed] run function tweaks:cold/warm
execute unless dimension minecraft:the_nether if entity @s[tag=tweaks.heated] run function tweaks:cold/warm
execute unless entity @s[tag=tweaks.warmed] unless entity @s[tag=tweaks.heated] run tag @s remove tweaks.thawing
execute unless dimension minecraft:the_nether unless entity @s[tag=tweaks.warmed] unless entity @s[tag=tweaks.heated] run function tweaks:cold/weather
execute unless dimension minecraft:the_nether unless predicate tweaks:open_sky unless entity @s[tag=tweaks.warmed] unless entity @s[tag=tweaks.heated] run scoreboard players remove @s tweaks.cold 4
execute if score @s tweaks.cold matches ..0 run scoreboard players set @s tweaks.cold 0
execute if score @s tweaks.cold matches 8401.. run scoreboard players set @s tweaks.cold 8400
function tweaks:heat/player
