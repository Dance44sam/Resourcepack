# No digging tool in hand: forget the last one, so the next is measured afresh
scoreboard players set @s tweaks.dmgprev -1
scoreboard players set @s tweaks.slotprev -1
