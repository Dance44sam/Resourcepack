tag @s add tweaks.seen
attribute @s minecraft:max_health base set 10
