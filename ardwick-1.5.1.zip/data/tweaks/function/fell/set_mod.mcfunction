$attribute @s minecraft:block_break_speed modifier add tweaks:fell $(amount) add_multiplied_total
