execute unless block ~ ~ ~ minecraft:furnace run return run kill @s
execute if block ~ ~ ~ minecraft:furnace[lit=true] if predicate tweaks:kiln_puff run particle minecraft:smoke ~ ~0.6 ~ 0 0 0 0 1
