# Food applies a one-tick luck effect whose length is its healing. Add that to whatever
scoreboard players set #d tweaks.calc2 0
execute store result score #d tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:luck"}].duration
effect clear @s minecraft:luck
scoreboard players set #r tweaks.calc2 0
execute if data entity @s active_effects[{id:"minecraft:regeneration"}] unless data entity @s active_effects[{id:"minecraft:regeneration"}].amplifier store result score #r tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:regeneration"}].duration
execute if data entity @s active_effects[{id:"minecraft:regeneration",amplifier:0b}] store result score #r tweaks.calc2 run data get entity @s active_effects[{id:"minecraft:regeneration",amplifier:0b}].duration
scoreboard players operation #r tweaks.calc2 += #d tweaks.calc2
scoreboard players add #r tweaks.calc2 19
scoreboard players operation #r tweaks.calc2 /= #k20 tweaks.const
execute store result storage tweaks:food s int 1 run scoreboard players get #r tweaks.calc2
function tweaks:food/give with storage tweaks:food
