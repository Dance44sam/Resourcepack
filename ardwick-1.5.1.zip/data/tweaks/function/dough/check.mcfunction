execute if block ~ ~ ~ minecraft:water run function tweaks:dough/soak
execute if block ~ ~ ~ minecraft:water_cauldron run function tweaks:dough/soak
