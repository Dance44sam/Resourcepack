# Off to the player's side, out of view, 34 to 48 blocks away
tag @e[type=minecraft:mannequin,tag=tweaks.hb] remove tweaks.hb_seen
tag @e[type=minecraft:mannequin,tag=tweaks.hb] add tweaks.hb_moved
function tweaks:herobrine/clear_light
scoreboard players set #hbmode tweaks.calc2 1
scoreboard players set #hbtries tweaks.calc2 8
execute as @a[tag=tweaks.hb_target,limit=1] at @s run function tweaks:herobrine/move_spot
scoreboard players set #hbmode tweaks.calc2 0
execute if entity @e[type=minecraft:mannequin,tag=tweaks.hb,tag=!tweaks.hb_placed] run function tweaks:herobrine/vanish
tag @e[type=minecraft:mannequin,tag=tweaks.hb] remove tweaks.hb_placed
execute as @e[type=minecraft:marker,tag=tweaks.hb_shrine] at @s if block ~ ~ ~ minecraft:fire run setblock ~ ~ ~ minecraft:air
kill @e[type=minecraft:marker,tag=tweaks.hb_shrine]
