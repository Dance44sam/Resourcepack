execute if score @s tweaks.fell_on matches 1 run attribute @s minecraft:block_break_speed modifier remove tweaks:fell
scoreboard players set @s tweaks.fell_on 0
