# Runs at the bottom row of the opening and builds upward
scoreboard players operation #prow tweaks.calc2 = #ph tweaks.calc2
$function tweaks:portal/place_$(ax)_$(w)
playsound minecraft:block.portal.trigger block @a ~ ~ ~ 0.6 1.4
