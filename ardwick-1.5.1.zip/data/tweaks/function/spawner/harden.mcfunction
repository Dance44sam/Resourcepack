attribute @s minecraft:block_break_speed modifier add tweaks:spawner -0.9 add_multiplied_total
scoreboard players set @s tweaks.sp_hard 1
