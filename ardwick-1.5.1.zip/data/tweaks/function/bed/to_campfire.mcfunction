execute store result storage tweaks:bed x int 1 run scoreboard players get @s tweaks.spx
execute store result storage tweaks:bed y int 1 run scoreboard players get @s tweaks.spy
execute store result storage tweaks:bed z int 1 run scoreboard players get @s tweaks.spz
data modify storage tweaks:bed dim set value "minecraft:overworld"
execute if score @s tweaks.sdim matches 1 run data modify storage tweaks:bed dim set value "minecraft:the_nether"
execute if score @s tweaks.sdim matches 2 run data modify storage tweaks:bed dim set value "minecraft:the_end"
function tweaks:bed/set with storage tweaks:bed
