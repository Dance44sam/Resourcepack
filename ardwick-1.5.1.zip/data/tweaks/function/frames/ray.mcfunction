execute as @e[type=#tweaks:item_frames,distance=..0.6,sort=nearest,limit=1] at @s run return run function tweaks:frames/toggle
scoreboard players remove #ray tweaks.calc2 1
execute if score #ray tweaks.calc2 matches 1.. positioned ^ ^ ^0.1 run function tweaks:frames/ray
