# (9L*L - 325L + 4440) / 2
scoreboard players operation @s tweaks.calc2 *= #9 tweaks.const
scoreboard players operation @s tweaks.calc3 = @s tweaks.xplv
scoreboard players operation @s tweaks.calc3 *= #325 tweaks.const
scoreboard players operation @s tweaks.calc2 -= @s tweaks.calc3
scoreboard players operation @s tweaks.calc2 += #4440 tweaks.const
scoreboard players operation @s tweaks.calc2 /= #2 tweaks.const
