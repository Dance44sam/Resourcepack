# Heat, the mirror of cold
scoreboard players add @s tweaks.heat 0
execute if entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run return run scoreboard players set @s tweaks.heat 0
tag @s remove tweaks.cooled
execute if score @s tweaks.wet matches 10 run tag @s add tweaks.cooled
execute if entity @s[tag=tweaks.soulcamp] run tag @s add tweaks.cooled
execute unless entity @s[tag=tweaks.cooled] run function tweaks:heat/cool_check
execute if entity @s[tag=tweaks.cooled] run function tweaks:heat/cool
execute unless entity @s[tag=tweaks.cooled] run tag @s remove tweaks.cooling
execute unless entity @s[tag=tweaks.cooled] if dimension minecraft:the_nether run function tweaks:heat/nether
execute unless entity @s[tag=tweaks.cooled] unless dimension minecraft:the_nether run function tweaks:heat/overworld
execute if score @s tweaks.heat matches ..0 run scoreboard players set @s tweaks.heat 0
execute if score @s tweaks.heat matches 8401.. run scoreboard players set @s tweaks.heat 8400
