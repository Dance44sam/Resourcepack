# The item's effects, three possible lists, each walked in turn
data remove storage tweaks:stack work
$data modify storage tweaks:stack work set from storage tweaks:stack p$(id).item.components."minecraft:potion_contents".custom_effects
function tweaks:stack/each
data remove storage tweaks:stack work
data remove storage tweaks:stack base
$data modify storage tweaks:stack base set from storage tweaks:stack p$(id).item.components."minecraft:potion_contents".potion
execute if data storage tweaks:stack base run function tweaks:stack/from_table with storage tweaks:stack
function tweaks:stack/each
data remove storage tweaks:stack work
$data modify storage tweaks:stack work set from storage tweaks:stack p$(id).item.components."minecraft:consumable".on_consume_effects[0].effects
function tweaks:stack/each
