execute as @e[type=minecraft:mannequin,tag=tweaks.hb] at @s if block ~ ~1 ~ minecraft:light run setblock ~ ~1 ~ minecraft:air
