# A small random push to scatter it, and no merging (never-despawn) for 40 ticks while it
execute store result entity @s Motion[0] double 0.01 run random value -12..12
execute store result entity @s Motion[2] double 0.01 run random value -12..12
data modify entity @s Motion[1] set value 0.2d
data modify entity @s PickupDelay set value 10s
data modify entity @s Age set value -32768s
tag @s add tweaks.split
tag @s add tweaks.seen
scoreboard players set @s tweaks.split_t 0
