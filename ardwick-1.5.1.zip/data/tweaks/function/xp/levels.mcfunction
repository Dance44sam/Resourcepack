# Total points needed to reach level L from zero (vanilla formula)
scoreboard players operation @s tweaks.calc2 = @s tweaks.xplv
scoreboard players operation @s tweaks.calc2 *= @s tweaks.xplv
execute if score @s tweaks.xplv matches ..16 run function tweaks:xp/levels_low
execute if score @s tweaks.xplv matches 17..31 run function tweaks:xp/levels_mid
execute if score @s tweaks.xplv matches 32.. run function tweaks:xp/levels_high
scoreboard players operation @s tweaks.xp += @s tweaks.calc2
