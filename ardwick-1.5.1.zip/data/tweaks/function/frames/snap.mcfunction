item replace entity @s weapon.mainhand with minecraft:air
playsound minecraft:entity.item.break player @a ~ ~ ~ 0.8 1.0
