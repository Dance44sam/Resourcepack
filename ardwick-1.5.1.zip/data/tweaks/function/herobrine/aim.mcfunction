$execute rotated ~$(yaw) 0 positioned ^ ^ ^$(dist) positioned ~ ~16 ~ run function tweaks:herobrine/column_start
