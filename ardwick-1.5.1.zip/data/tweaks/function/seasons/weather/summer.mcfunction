# Summer, rolled out of 10000: rain 1.76% per spell
execute if score #roll tweaks.year matches 1..9824 run function tweaks:seasons/weather/clear_long
execute if score #roll tweaks.year matches 9825..10000 run function tweaks:seasons/weather/rain_short
