advancement revoke @s only tweaks:fire/struck
# Striking Flints can start a fire, but not open the way to the Nether
scoreboard players set #ray tweaks.calc2 60
execute at @s anchored eyes positioned ^ ^ ^ run function tweaks:fire/ray
