# Count the connected trunk, and whether it grew leaves of its own
scoreboard players set #count tweaks.calc2 0
scoreboard players set #natural tweaks.calc2 0
function tweaks:fell/visit
kill @e[type=minecraft:marker,tag=tweaks.fell]
execute if score #natural tweaks.calc2 matches 0 run scoreboard players set #count tweaks.calc2 0
scoreboard players operation @s tweaks.fell_n = #count tweaks.calc2
