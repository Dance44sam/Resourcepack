# Runs on world load and every /reload
function tweaks:gamerules
scoreboard objectives add tweaks.food food
scoreboard objectives add tweaks.hp health
scoreboard objectives add tweaks.hp_prev dummy
scoreboard objectives add tweaks.v_m dummy
scoreboard objectives add tweaks.v_d dummy
function tweaks:hearts/init
function tweaks:ore_boost/init
function tweaks:rough_quartz/init
function tweaks:xp/init
scoreboard objectives add tweaks.timer dummy
scoreboard objectives add tweaks.px dummy
scoreboard objectives add tweaks.sx dummy
scoreboard objectives add tweaks.sz dummy
scoreboard objectives add tweaks.pz dummy
scoreboard objectives add tweaks.dx dummy
scoreboard objectives add tweaks.dz dummy
scoreboard objectives add tweaks.spx dummy
scoreboard objectives add tweaks.spy dummy
scoreboard objectives add tweaks.spz dummy
scoreboard objectives add tweaks.sdim dummy
scoreboard objectives add tweaks.b0 dummy
scoreboard objectives add tweaks.b1 dummy
scoreboard objectives add tweaks.b2 dummy
scoreboard objectives add tweaks.b3 dummy
scoreboard objectives add tweaks.b4 dummy
scoreboard objectives add tweaks.b5 dummy
scoreboard objectives add tweaks.b6 dummy
scoreboard objectives add tweaks.b7 dummy
scoreboard objectives add tweaks.b8 dummy
scoreboard objectives add tweaks.b9 dummy
scoreboard objectives add tweaks.b10 dummy
scoreboard objectives add tweaks.b11 dummy
scoreboard objectives add tweaks.sum dummy
scoreboard objectives add tweaks.burst dummy
scoreboard objectives add tweaks.cold dummy
scoreboard objectives add tweaks.wet dummy
scoreboard objectives add tweaks.vigour dummy
scoreboard players set #neg1 tweaks.const -1
scoreboard players set #k20 tweaks.const 20
scoreboard objectives add tweaks.hold dummy
scoreboard objectives add tweaks.dmg dummy
scoreboard objectives add tweaks.dmgprev dummy
scoreboard objectives add tweaks.slot dummy
scoreboard objectives add tweaks.slotprev dummy
scoreboard objectives add tweaks.moved dummy
scoreboard objectives add tweaks.mv_walk minecraft.custom:minecraft.walk_one_cm
scoreboard objectives add tweaks.mv_sprint minecraft.custom:minecraft.sprint_one_cm
scoreboard objectives add tweaks.mv_crouch minecraft.custom:minecraft.crouch_one_cm
scoreboard objectives add tweaks.mv_swim minecraft.custom:minecraft.swim_one_cm
scoreboard objectives add tweaks.mv_wade minecraft.custom:minecraft.walk_on_water_one_cm
scoreboard objectives add tweaks.mv_under minecraft.custom:minecraft.walk_under_water_one_cm
scoreboard objectives add tweaks.mv_glide minecraft.custom:minecraft.aviate_one_cm
scoreboard objectives add tweaks.hud_step dummy
scoreboard objectives add tweaks.hud_t dummy
scoreboard players set #k300 tweaks.const 300
scoreboard players set #k150 tweaks.const 150
scoreboard players set #k356 tweaks.const 356
scoreboard players set #k176 tweaks.const 176
data modify storage tweaks:hud lo set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud li set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud ri set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud ro set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
scoreboard objectives add tweaks.frost dummy
scoreboard objectives add tweaks.hud_fk dummy
scoreboard players set #k14 tweaks.const 14
scoreboard players set #k20 tweaks.const 20
scoreboard players set #k180 tweaks.const 180
data modify storage tweaks:hud flo set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud fli set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud fri set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud fro set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
scoreboard players set #5 tweaks.const 5
scoreboard players set #two tweaks.cold 2
scoreboard players set #r10 tweaks.cold 10
scoreboard players set #r25 tweaks.cold 25
scoreboard players set #drift tweaks.cold 100
scoreboard players set #sleeprate tweaks.cold 20
scoreboard players set #hundred tweaks.cold 100
scoreboard players set #bucket tweaks.sum 0
scoreboard players set #was tweaks.sum 0
function tweaks:daylight
function tweaks:seasons/init
scoreboard objectives add tweaks.br_wheat minecraft.mined:minecraft.wheat
scoreboard objectives add tweaks.br_carrots minecraft.mined:minecraft.carrots
scoreboard objectives add tweaks.br_potatoes minecraft.mined:minecraft.potatoes
scoreboard objectives add tweaks.br_beetroots minecraft.mined:minecraft.beetroots
scoreboard players set #k8 tweaks.const 8
scoreboard objectives add tweaks.fell_n dummy
scoreboard objectives add tweaks.fell_on dummy
scoreboard objectives add tweaks.fell_x dummy
scoreboard objectives add tweaks.fell_y dummy
scoreboard objectives add tweaks.fell_z dummy
scoreboard objectives add tweaks.due dummy
schedule function tweaks:breed/check 100t replace
scoreboard objectives add tweaks.ob_water minecraft.used:minecraft.water_bucket
scoreboard objectives add tweaks.ob_lava minecraft.used:minecraft.lava_bucket
scoreboard objectives add tweaks.ob_age dummy
scoreboard objectives add tweaks.burn dummy
scoreboard objectives add tweaks.vhalf dummy
scoreboard players set #k2 tweaks.const 2
scoreboard objectives add tweaks.pasty dummy
scoreboard players set #k30 tweaks.const 30
scoreboard objectives add tweaks.deaths deathCount
team add tweaks.gilded
team modify tweaks.gilded friendlyFire true
team modify tweaks.gilded seeFriendlyInvisibles false
scoreboard objectives add tweaks.sp_hard dummy
scoreboard objectives add tweaks.ff dummy
scoreboard objectives add tweaks.pid dummy
function tweaks:stack/table
scoreboard players set #zero tweaks.calc2 0
scoreboard players set #w1 tweaks.const 1
scoreboard players set #w2 tweaks.const 2
scoreboard objectives add tweaks.cake minecraft.custom:minecraft.eat_cake_slice
scoreboard objectives add tweaks.split_t dummy
scoreboard objectives add tweaks.qprog dummy
scoreboard objectives add tweaks.bkt_used minecraft.used:minecraft.bucket
scoreboard objectives add tweaks.bkt_age dummy
kill @e[type=minecraft:marker,tag=tweaks.bkt]
scoreboard objectives add tweaks.fished minecraft.custom:minecraft.fish_caught
scoreboard players set #inv_busy tweaks.calc2 0
scoreboard players set #300 tweaks.calc2 300
scoreboard players set #127 tweaks.calc2 127
scoreboard players set #19 tweaks.calc2 19
scoreboard objectives add tweaks.rope_t dummy
scoreboard objectives add tweaks.knot_age dummy
scoreboard objectives add tweaks.rkx dummy
scoreboard objectives add tweaks.rky dummy
scoreboard objectives add tweaks.rkz dummy
scoreboard objectives add tweaks.heat dummy
scoreboard players set #h40 tweaks.heat 20
scoreboard players set #h15 tweaks.heat 8
scoreboard players set #hdrift tweaks.heat 60
scoreboard players set #eight tweaks.heat 8
data modify storage tweaks:hud hlo set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud hli set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud hri set value ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
data modify storage tweaks:hud hro set value ["切","度","拓","糖","宅","洞","暴","輻","行","降","見","廓","兀","嗀","﨎","﨏","塚","﨑","晴","﨓","﨔","凞","猪","益","礼","神","祥","福","靖","精","羽","﨟","蘒","﨡","諸","﨣","﨤","逸","都","﨧","﨨","﨩","飯","飼","館","鶴","郞","隷","侮","僧","免","勉","勤","卑","喝","嘆","器","塀","墨","層","屮","悔","慨","憎","懲","敏","既","暑","梅","海","渚","漢","煮","爫","琢","碑","社","祉","祈","祐","祖","祝","禍","禎","穀","突","節","練","縉","繁","署","者","臭","艹","艹","著","褐","視","謁","謹","賓","贈","辶","逸","難","響","頻","恵","𤋮","舘","﩮","﩯","並","况","全","侀","充","冀","勇","勺","喝","啕","喙","嗢","塚","墳","奄","奔","婢","嬨","廒","廙","彩","徭","惘","慎","愈","憎","慠","懲","戴","揄","搜","摒","敖","晴","朗","望","杖","歹","殺","流","滛","滋","漢","瀞","煮","瞧","爵","犯","猪","瑱","甆","画","瘝","瘟","益","盛","直","睊","着","磌","窱","節","类","絛","練","缾","者","荒","華"]
scoreboard objectives add tweaks.fprev dummy
scoreboard objectives add tweaks.ftgt dummy
scoreboard objectives add tweaks.fph dummy
scoreboard objectives add tweaks.fside dummy
scoreboard players set #k24000 tweaks.calc2 24000
scoreboard players set #k1800000 tweaks.calc2 1800000
scoreboard players set #k1636364 tweaks.calc2 1636364
scoreboard players set #k5 tweaks.calc2 5
scoreboard players set #k10 tweaks.calc2 10
scoreboard objectives add tweaks.hrem dummy
scoreboard objectives add tweaks.crem dummy
scoreboard players set #k100000 tweaks.calc2 100000
scoreboard players set #k180000 tweaks.calc2 180000
scoreboard players set #k163636 tweaks.calc2 163636
scoreboard players set #k50 tweaks.calc2 50
scoreboard players set #k100 tweaks.calc2 100
scoreboard players set #k1000 tweaks.calc2 1000
scoreboard players set #k700 tweaks.calc2 700
scoreboard objectives add tweaks.sfid dummy
# The world's own sleep record (sleep/world_sum), so it reads 0 before anyone has slept
scoreboard players add #world tweaks.b0 0
scoreboard players add #world tweaks.b1 0
scoreboard players add #world tweaks.b2 0
scoreboard players add #world tweaks.b3 0
scoreboard players add #world tweaks.b4 0
scoreboard players add #world tweaks.b5 0
scoreboard players add #world tweaks.b6 0
scoreboard players add #world tweaks.b7 0
scoreboard players add #world tweaks.b8 0
scoreboard players add #world tweaks.b9 0
scoreboard players add #world tweaks.b10 0
scoreboard players add #world tweaks.b11 0
scoreboard players add #acc tweaks.sum 0
