# Ground items near players: one-off conversions the first time, reactions to their surroundings every tick
execute if entity @s[tag=!tweaks.conv] run function tweaks:items/convert
execute if entity @s[tag=!tweaks.seen] unless data entity @s Thrower if items entity @s contents minecraft:chest_minecart run function tweaks:minecart/split {block:"chest"}
execute if entity @s[tag=!tweaks.seen] unless data entity @s Thrower if items entity @s contents minecraft:hopper_minecart run function tweaks:minecart/split {block:"hopper"}
execute if entity @s[tag=!tweaks.seen] unless data entity @s Thrower if items entity @s contents minecraft:furnace_minecart run function tweaks:minecart/split {block:"furnace"}
execute if entity @s[tag=!tweaks.seen] unless data entity @s Thrower if items entity @s contents minecraft:tnt_minecart run function tweaks:minecart/split {block:"tnt"}
function tweaks:split/check
execute if items entity @s contents minecraft:dirt if block ~ ~ ~ minecraft:water run function tweaks:mud/turn
execute if items entity @s contents #tweaks:concrete_powder if block ~ ~ ~ minecraft:water run function tweaks:concrete/set
execute if items entity @s contents minecraft:amethyst_shard if block ~ ~-0.3 ~ minecraft:sculk run function tweaks:echo/turn
execute if items entity @s contents minecraft:amethyst_shard if block ~ ~ ~ minecraft:water run function tweaks:prismarine/turn
execute if items entity @s contents minecraft:amethyst_shard if block ~ ~ ~ minecraft:soul_campfire[lit=true] run function tweaks:allay/call
execute if entity @s[tag=!tweaks.dough] if items entity @s contents minecraft:wheat run function tweaks:dough/check
execute if entity @s[tag=!tweaks.egg_checked] if items entity @s contents #tweaks:eggs run function tweaks:eggs/check_one
execute if items entity @s contents minecraft:leather[minecraft:custom_data] run function tweaks:leather/cured
