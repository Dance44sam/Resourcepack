scoreboard players set #w tweaks.calc2 28
scoreboard players operation #w tweaks.calc2 -= #a tweaks.calc2
scoreboard players operation #a tweaks.calc2 = #w tweaks.calc2
