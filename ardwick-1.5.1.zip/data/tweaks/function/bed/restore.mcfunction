# Beds don't set your spawn point in Ardwick
advancement revoke @s only tweaks:bed/slept
execute if score @s tweaks.spx matches -2147483648..2147483647 run return run function tweaks:bed/to_campfire
execute if score #wsx tweaks.spx matches -2147483648..2147483647 run function tweaks:bed/to_world
