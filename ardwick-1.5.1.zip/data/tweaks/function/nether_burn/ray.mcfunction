execute if block ~ ~ ~ #minecraft:campfires[lit=false] align xyz run return run function tweaks:nether_burn/campfire
execute if block ~ ~ ~ minecraft:tnt align xyz run return run function tweaks:nether_burn/tnt
execute if block ~ ~ ~ #tweaks:burns_in_nether align xyz run return run function tweaks:nether_burn/ignite
execute unless block ~ ~ ~ #tweaks:place_through run return 0
scoreboard players remove #nb tweaks.calc2 1
execute if score #nb tweaks.calc2 matches 1.. positioned ^ ^ ^0.05 run function tweaks:nether_burn/ray
