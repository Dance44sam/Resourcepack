tag @s add tweaks.gentle2
# Not quite 0: the game reads a follow range of exactly 0 as "no limit" when choosing
attribute @s minecraft:follow_range modifier remove tweaks:gentle
attribute @s minecraft:follow_range modifier add tweaks:gentle -0.999 add_multiplied_total
