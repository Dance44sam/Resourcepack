execute as @a run attribute @s minecraft:attack_speed base set 1024
# Vitality: the healthier you are, the quicker you move; worked out again only when health changes
execute as @a unless score @s tweaks.hp = @s tweaks.hp_prev run function tweaks:combat/vitality
