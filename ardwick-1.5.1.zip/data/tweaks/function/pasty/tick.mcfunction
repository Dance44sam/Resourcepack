scoreboard players remove @a[scores={tweaks.pasty=1..}] tweaks.pasty 1
