# Once a second: anyone who has left an ancient city can trigger it again next time
execute as @a[tag=tweaks.in_city] unless predicate tweaks:in_ancient_city run tag @s remove tweaks.in_city
