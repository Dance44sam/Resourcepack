# Split items get their normal despawn timer back after 40 ticks, and can merge again
scoreboard players add @e[type=minecraft:item,tag=tweaks.split] tweaks.split_t 1
execute as @e[type=minecraft:item,tag=tweaks.split,scores={tweaks.split_t=40..}] run function tweaks:split/release
